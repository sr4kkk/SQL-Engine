function normalizeList(list) {
  const out = [];
  const seen = new Set();
  for (const item of Array.isArray(list) ? list : []) {
    if (typeof item !== 'string') continue;
    const v = item.trim();
    if (!v) continue;
    const key = v.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(key);
  }
  return out;
}

const FUN_COMMANDS = normalizeList([
  'tapa','tapas','abraço','abraco','beijo','comer','esfaquear','estuprar','soco','morder','chutar','elogio',
  'feio','gay','corno','matar','zuar','gado', 'trancarnoporao',
  'ship','casal','casar','aceitarpedido','recusar','recusarPedido','recusarpedido','divorciar','separar','cancelarpedido','cancelarcasar','parideal','porao',  'ppt','duelo','quiz','adivinhar','jogov','jogodavelha','amar',
  'unir',
  'roletarussa','corrida','testegif',
  
  'perfilcasal','dr','trair','vidente','adotar','deserdar','familia','meusfilhos','desadotar','emancipar','casados',
  'adotarfilho','aceitaradocao','recusaradocao', 'aceitarfamilia', 'toplindos', 'topfeios', 'rankgados',
  'rankgado','rankcorno','rankcornos','rankgay','rankgays','rankotaku','rankotakus','ranksigma','ranksigmas','rankbeta','rankbetas','rankcarioca','rankcariocas','rankbaiano','rankbaianos','ranksafado','ranksafados','ranksafada','ranksafadas','ranklouco','rankloucos','ranklouca','rankloucas','rankgostoso','rankgostosos','rankgostosa','rankgostosas', 'ranknazista', 'ranknazistas', 'rankcomunista', 'rankcomunistas', 'rankpau', 'rankpaus', 'rankbuceta', 'rankbucetas','rankcapitalista','rankcapitalistas', 'rankmortes', 'rankmortos',
  'chute','chutes',

]);


const AUDIO_COMMANDS = normalizeList([
  'yamete',
  'lolimusic',
  'quieto',
  'vitoriabolsonaro',
  'vitoriaadm',
  'bomdia',
  'bucetacional',
  'ferias',
  'maconha',
  'cha',
  'vitoriaconta1',
  'criatura',
  'encosta',
  'bandido',
  'risadinha',
  'vitoriacanta',
  'ara',
  'pipoquinha',
  'pipoquinha18',
  'fight',
  'pitu',
  'chora',
  'solinguica',
  'audio',
  'som',
]);


const STICKER_COMMANDS = normalizeList([
  'fig','f','crop','s',
  'nobg',
  'figtexto','fgtxt','figgif','srgb','toimg','togif','figdono',
  'scriador','rename','sballon',
  'figcrop',
  'scrop',

]);

const AUTOFIG_COMMANDS = normalizeList([
  'autofig',
]);

// Menus (core) — comandos que apenas exibem menus/submenus
// Obs: não roteia por categoria; serve como registro central e para auto-ajuda.
const MENU_COMMANDS = normalizeList([
  'menu',
  'menuprincipal',
  'help',
  'menuaudio',
  'menuadm',
  'menudono',
  'menubot',
  'menusticker',
  'menufigurinhas',
  'menurp',
  'menucassino',
  'menuutil',
  'menuutilidades',
  'colecionaveis',
  'brincadeiras',
  'menubrin',
  'menusims',
  'menuaventura',
  'menujogos',
  'menu18',
]);

const ADMIN_COMMANDS = normalizeList([
  'ban',
  'listanegra',
  'verlistanegra',
  'removerlistanegra',
  'arquivargrupo',
  'mute',
  'desmute',
  'deletarmsg',
  'autodeletmsg',
  'd',
  'limparstatus',
  'promover',
  'rebaixar',
  'antilink',
  'antistatus',
  'autobanstatus',
  'antiflood',
  'antifake',
  'antipalavra',
  'autoaceitar',
  'boasvindas',
  'setwelcome',
  'setregras',
  'regras',
  'linkgrp',
  'marcar',
  'marcartodos',
  'tagall',
  'tagadm',
  'status',
  'statusgrp',
  'upmsg',
  'desligarbot',
  'ligarbot',
  'monitorargrp',
  'revogarlink',
  'fechargrp',
  'abrirgrp',
  'agendagrp',
  'antifakeconfig',
  'modav',
  'modsims',
  'antilinkadm',
  'antilinkacoes',
  'antilinkentrada',
  'desligarbot',
  'ligarbot',
  'tagam',
  'getpic', 
  'eperfil',
  'inativos',
  'ativos',

]);

const OWNER_COMMANDS = normalizeList([
  'menudono',
  'menubot',
  'botmoney',
  'sairgrupo',
  'atualizarwhats',
  'limparchat',
  'limparghost',
  'logs',
  'logconsole',
  'extrairlog',
  'confirmar',
  'resetarbot',
  'reiniciarbot',
  'autoreiniciar',
  'limparlogs',
  'anunciar',
  'statusbot',
  'listagrupos',
  'sairgrupos',
  'debugmode',
  'recarregarconfig',
  'bloquearcomando',
  'desbloquearcomando',
  'bloquearcomandocategoria',
  'desbloquearcomandocategoria',
  'addowner',
  'delowner',
  'reloadcomandos',
  'backupdb',
  'listsugestoes',
  'listarideias',
  'pausabot',
  'pausarbot',
  'voltabot',
  'resetarperfil',
  'pvblock',
  'bloquearpv',
  'entrada',
  'aceitargrp',
  'aceitargrupo',
]);

const RP_OWNER_COMMANDS = normalizeList([
  'donotrabalhar','donoemprestimo','donosacar','donopix',
  'resetmoney','resetar','resetarall','resetargrupo','jobxpdono',
]);

const RP_COMMANDS = normalizeList([
  // Start
  'rp',
  'menurp',
  'meurp',
  'tutorialrp',
  'menuprisao',
  'pagarmulta',
  'advogado',
  'audiencia',
  'defender',
  'defesa',
  'reduzirpena',
  'negociarmulta',
  'reduzircrime',
  'menumercado',
  'ficha',
  'limparficha',
  'denunciar',
  'vigilancia',
  'inventario',
  'rankmenu',
  'meurank',
  'top',
  'profissoes',
  'profissao',
  'governo',
  'menuprofissoes',
  'trabalhar',
  'construir',
  'obras',
  'pedreiro',
  'menupedreiro',
  'diaria',
  'missao',
  'missaodiaria',
  'saldo',
  'banco',
  'depositar',
  'sacar',
  'escolherbanco',
  'setbanco',
  'meubanco',
  'menuinvestimo',
  'menuinvestimento',
  'investir',
  'emprestimo',
  'quitar',
  'quitemprestimo',
  'pagarparcela',
  'pix',
  'pagarfianca',
  'liberarfianca',
  'patrulha',
  'patrulhar',
  'menupolicia',
  'menupm',
  'delegacia',
  'oficina',
  'escritorio',
  'menuadv',
  'atender',
  'lojaadv',
  'lojadv',
  'compraradv',
  'depositarescritorio',
  'lojapm',
  'depositarpm',
  'lojapolicia',
  'hospital',
  'plantao',
  'missaomedico',
  'lojasaude',
  'comprarsaude',
  'comprarpm',
  'prender',
  'soltar',
  'fugir',
  'suborno',
  'aceitarsuborno',
  'recusarsuborno',
  'contraoferta',
  'aceitarcontraoferta',
  'cancelarsuborno',
  'loja',
  'menuloja',
  'colecionaveis',
  'drop',
  'pegar',
  'vendercolecionavel',
  'menuitem',
  'menuauto',
  'menucasa',
  'menurenda',
  'menuoficina',
  'lojaoficina',
  'menuagro',
    'agrotempo',
  'agrobonus',
  'agroconstruir',
  'comprarterra',
  'sementes',
  'fertilizante',
'agroloja',
  'agrobichos',
  'agrobicho',
  'agroup',
  'menuilegal',
  'comprar',
  'coletarrenda',
  'ilegalinfo',
  'minhailegal',
  'menusujo',
  'escondersujo',
  'melhorarbunker',
  'bunker',
  'aumentarbunker',
  'sacarsujo',
  'lavarsujo',
  'doleiro',
  'criarloja',
  'minhaloja',
  'vender',
  'listarvendas',
  'comprarjogador',
  'agro',
  'fazenda',
  'resumoagro',
  'agrocoletar',
  'agromodo',
  'plantar',
  'colher',
  'animais',
  'roubar',
  'invadirbanco',
  'hackbanco',
  'menuhacker',
  'hackerloja',
  'invadircasadamoeda',
  'donotrabalhar',
  'donoemprestimo',
  'donopix',
  'donosacar',
  'resetargrupo',
  'resetarall',
  'resetmoney',
  'jobxpdono',
  'agrovender',
  'agrodescarregar',
  'agrosilo',
  'lojamenu',

]);

const CASSINO_COMMANDS = normalizeList([
  'cassino',
  'cassinojogos',
  'menucassino',
  'cassinoinfo',
  'cassino-info',
  'cassinohoje',
  'cassinorank',
  'meucassino',
  'cassinoconquistas',
  'cassinobonus',
  // VIP (Cassino)
  'cashbackvip',
  'vipstats',
  'caracoroa',
  'cara-coroa',
  'cc',
  'roleta',
  'dados',
  'dado',
  'slot',
  'slots',
  'bicho',
  'blackjack',
  '21',
  'entrar',
  'parar',
  'bjcomprar',
  'crash',
  'parimpar',
  'par-impar',
  'apostarbomba',
  'bombas',
  'apostabcoletar',
  'dupla',
  'duplanada',
  'aposta',
  'apostar',
  'aceitaraposta',
  'jackpot',
  'entrarcassino',
  'sacarcassino',
  'cassinosaldo',
  // jogos em dupla
  'parperfeito',
  'cofreduplo',
  'caratraidor',
  'numero',
  'codigo',
  'escolha',
]);
// Evita drift: comandos de dono/owner não devem aparecer também na lista geral.
(() => {
  const ownerSet = new Set(RP_OWNER_COMMANDS);
  const filtered = [];
  for (const c of RP_COMMANDS) {
    if (!ownerSet.has(c)) filtered.push(c);
  }
  // Reatribui mantendo ordem do primeiro aparecimento
  RP_COMMANDS.length = 0;
  for (const c of filtered) RP_COMMANDS.push(c);
})();


const AVENTURA_COMMANDS = normalizeList([
  // Comandos Originais
  'aventura',
  'classe',
  'craft',
  'boss',
  'matarboss',
  'matarboos',
  'emporio',
  'adquirir',
  'liquidar',
  'trocaritem',
  'avperfil',
  'mochila',
  'bag',
  'leilao',
  'avmercado',
  'arena',
  'explorar',
  'avcacar',
  'avcaçar',
  'avatacar',
  'avfugir',
  'avusar',

  // BÚSSOLA / NAVEGAÇÃO
  'avmeu',
  'meuav',

  // REGIÃO / EVENTO / MAPA
  'avregiao',
  'avevento',
  'avmapa',
  'avpreparar',

  // PROGRESSO / STATUS
  'avconquistas',
  'avmissoes',
  'avhistorico',
  'avprestigio',
  'avtitulo',
  'avcofre',
  'guardargold',
  'roubargold',
  'enviargold',
  'avestilo',

  // QUALIDADE DE VIDA
  'avprecos',

  // EXPLORAÇÃO AVANÇADA
  'avexplorar',
  'avsemana',

  // EQUIPAMENTO
  'avkit',
  'avdesmontar',
  'avequip',

  // NOCTHARIA (DARK) — comandos novos
  'avexp',
  'avskill',
  'avdg',
  'avinv',
  'avrank',
  'avcorr',
  'avpurificar',
]);


const THE_SIMS_COMMANDS = normalizeList([
  'tscriar','tsnome','tssexo','tsaspiracao','tstraco','tcorpo','tpele','testilo','tsfinalizar','tscancelar',
  'tscriarfast','tsaleatorio',
  'tscatalogo',
  'tsentrar','tsperfil','tsdeletarperfil',
  'tsexercicio','tscorrida','tsacademia','tspularcorda','tsdieta','tsfritura','tscomer',
  'tscomprarterreno','tsconstruir','tsdecorar','tscontas','tscasa','tssujeira','tslimparcasa',
  'tsemprego','tstrabalhar','tsdemitir',
  'tsskills','tsestudar','tspraticar',
  'tsevento',
  'tsdormir','tsbanho','tsdiversao',
]);

const donoRP_COMMANDS = normalizeList([
  'donotempos',
  'donostatus',
  'donomult',
  'giveitem',
  'donotrem',
  'donocassino',
  'auditoriacassino',
  'cassinotema',
  'cassinomodo',
  'cassinoevento',
]);

// CHATBOT (offline)
const CHATBOT_COMMANDS = normalizeList([
  'palminha',
  'ensinar',
]);

// INTERNET (pesquisa / utilitários web)
const INTERNET_COMMANDS = normalizeList([
  'wiki',
  'google',
  'biblia',
  'pinterest',
  'shazam',
  'calc',
  'clima',
]);

const ADULTO_COMMANDS = normalizeList([
  'xvideos',
  'pornohub',
  'hentai',
  'hentaiteca',
]);

const ADULTO_CONFIG_COMMANDS = normalizeList([
  'ativar18',
  'desativar18'
]);

const RP_CASSINO_CONFIG_COMMANDS = normalizeList([
  'ativarrp',
]);


// Router helpers (SSOT) — evita comandos "soltos" no router.js
// Obs: mantém apenas o registro/lookup. O comportamento visível continua no router/handlers.
const CORE_TEST_COMMANDS = normalizeList(['crashtest']);

const MENU_MAIN_COMMANDS = normalizeList(['menu','menuprincipal','help']);
const MENU_STICKER_COMMANDS = normalizeList(['menusticker','menufigurinhas']);
const MENU_SIMS_COMMANDS = normalizeList(['menusims']);
const MENU_AVENTURA_COMMANDS = normalizeList(['menuaventura']);
const MENU_BRINCADEIRAS_COMMANDS = normalizeList(['brincadeiras','menubrin']);
const MENU_RP_COMMANDS = normalizeList(['menurp']);
const MENU_CASSINO_COMMANDS = normalizeList(['menucassino']);
const MENU_ADMIN_COMMANDS = normalizeList(['menuadm']);
const MENU_AUDIO_COMMANDS = normalizeList(['menuaudio']);
const MENU_UTILIDADES_COMMANDS = normalizeList(['menuutil','menuutilidades']);

const MENU_JOGOS_COMMANDS = normalizeList(['menujogos']);

// Ferramentas de áudio (ffmpeg)
// Obs: inclui "audio" (alias) — tem precedência no router para não conflitar com bricadeiraAudio.
const AUDIO_TOOLS_COMMANDS = normalizeList([
  'converter',
  'criaraudio',
  'acelerar',
  'lento',
  'volume',
  'cortar',
  'grave',
  'agudo',
  'eco',
  'robot',
  'chipmunk',
  'vozcrianca',
  'vozmonstro',
  'normalizar',
  'removerruido',
  'audio',
  'juntar',
]);

const CHANGELOG_COMMANDS = normalizeList(['changelog','novidades']);
const SUGESTOES_COMMANDS = normalizeList(['sugestao','sugestão','dica','ideia']);
const DOWNLOAD_COMMANDS = normalizeList(['ytmp3','yt','play','ytaudio','ytvideo','ytproxima', 'insta', 'instagram', 'ig', 'reels', 'tiktok', 'tt',
  'ytsim',
]);

const SIMPLE_PING_COMMANDS = normalizeList(['ping']);
const SIMPLE_RVISU_COMMANDS = normalizeList(['rvisu']);
const SIMPLE_INFO_COMMANDS = normalizeList(['info']);
const SIMPLE_GRPCONT_COMMANDS = normalizeList(['grpcont']);
const SIMPLE_TOTALCMD_COMMANDS = normalizeList(['totalcmd']);
const SIMPLE_RESGATAR_COMMANDS = normalizeList(['resgatar']);


const PROFILE_RESET_COMMANDS = normalizeList(['resetarmeuperfil']);
const PROFILE_MAIN_COMMANDS = normalizeList(['perfil','meuperfil']);
const PROFILE_TRANSFER_COMMANDS = normalizeList(['transferirperfil']);
const PROFILE_CONFIRMAR_COMMANDS = normalizeList(['confirmar']);

const ADMIN_REBAIXAR_COMMANDS = normalizeList(['rebaixar']);

// Aliases de módulo (arquivo) por comando (evita hardcode no router)
const COMMAND_MODULE_ALIAS = {
  // utilitários
  'novidades': 'changelog',

  // sugestões
  'sugestao': 'sugestoes',
  'sugestão': 'sugestoes',
  'dica': 'sugestoes',
  'ideia': 'sugestoes',

  // download
  'ytmp3': 'download',
  'yt': 'download',
  'play': 'download',
  'ytaudio': 'download',
  'ytvideo': 'download',
  'ytproxima': 'download',
  'ytsim': 'download',

// ADICIONE ISTO AQUI:
  'ig': 'insta',      // Quem digitar !ig usa o arquivo insta.js
  'reels': 'insta',   // Quem digitar !reels usa o arquivo insta.js
  'instagram': 'insta', // Quem digitar !instagram usa o arquivo insta.js
  'tt': 'tiktok',
  // RP (compat -> oficial)
  'menurp': 'menurp',
  'rpmenu': 'menurp',
};

// RP onboarding
// Atalho oficial: !rp (RP fica reservado para Aventura)
const RP_START_COMMANDS = normalizeList(['rp']);
const RP_ONBOARDING_EXTRA_COMMANDS = normalizeList(['resgatar']);

// Sticker (sub-handlers)
const RANDOM_FIG_COMMANDS = normalizeList(['randomfig', 'randomfigimg', 'randomfigif']);
const STICKER_METHOD_MAP = {
  'figtexto':   { fn: 'handleFigTexto', mode: 'args' },
  'fgtxt':      { fn: 'handleFgTxt', mode: 'args' },
  'figgif':     { fn: 'fromTextGif', mode: 'joinText' },
  'srgb':       { fn: 'handleSRgb', mode: 'args' },
  'attp':       { fn: 'handleSRgb', mode: 'args' },
  'toimg':      { fn: 'toImage', mode: 'none' },
  'togif':      { fn: 'toGif', mode: 'none' },
  'figdono':    { fn: 'setFigOwner', mode: 'args' },
  'scriador':   { fn: 'handleScriador', mode: 'args' },
  'rename':     { fn: 'handleScriador', mode: 'args' },
  'sballon':    { fn: 'handleSBallon', mode: 'args' },
};

// Owner — comandos que gerenciam bloqueios (apenas dono)
const OWNER_MANAGE_BLOCK_COMMANDS = normalizeList([
  'bloquearcomando', 'desbloquearcomando',
  'bloquearcomandocategoria', 'desbloquearcomandocategoria',
]);

// Cassino — alias de compatibilidade
const CASSINO_ALIAS_MAP = {};

// BJ Mesa intercept (compat)
const BJ_MESA_INTERCEPT_COMMANDS = normalizeList(['comprar']);
const BJ_MESA_BUY_ACTION_CMD = 'bjcomprar';

// Auto-ajuda (comando errado -> comando certo)
const AUTOHELP_EXTRA_KNOWN = normalizeList([
  'menu', 'menuprincipal', 'help', 'menu18',
  'menuadm',
  'menusticker', 'menufigurinhas',
  'menusims',
  'brincadeiras', 'menubrin',
  'changelog', 'novidades',
  'meuperfil',
  'ping', 'rvisu', 'info', 'donotempos', 'grpcont',
  'sugestao', 'sugestão', 'dica', 'ideia',
  'ytmp3', 'yt', 'play', 'ytaudio', 'ytvideo', 'ytproxima',
  'randomfig', 'randomfigimg', 'randomfigif',
]);

const AUTOHELP_USAGE_MAP = {
  // owner
  'sairgrupo': 'sairgrupo',
  'atualizarwhats': 'atualizarwhats',
  'limparchat': 'limparchat pv | limparchat grupos | limparchat tudo',
  'logs': 'logs',
  'confirmar': 'confirmar <código>',
  'pvblock': 'pvblock on | pvblock off | pvblock status',
  'entrada': 'entrada on | entrada off | entrada status',
  'aceitargrp': 'entrada on | entrada off | entrada status',

  // segurança
  'sairgrupos': 'sairgrupos all | sairgrupos <nome>',

  // comuns
  'listagrupos': 'listagrupos [semadmin|parados|top]',
  'debugmode': 'debugmode on | debugmode off',
  'bloquearcomando': 'bloquearcomando <comando> [outro...]',
  'desbloquearcomando': 'desbloquearcomando <comando> [outro...]',
  'bloquearcomandocategoria': 'bloquearcomandocategoria <categoria>',
  'desbloquearcomandocategoria': 'desbloquearcomandocategoria <categoria>',
  'addowner': 'addowner 55XXXXXXXXXXX (ou marque/responda)',
  'delowner': 'delowner 55XXXXXXXXXXX (ou marque/responda)',
};

// evita resposta dupla quando o pipeline de XP trata esse cmd por fora
const AUTOHELP_IGNORED_UNKNOWN_IN_GROUP = normalizeList(['contador']);

module.exports = {
  MENU_COMMANDS,
  FUN_COMMANDS,
  AUDIO_COMMANDS,
  AUTOFIG_COMMANDS,
  STICKER_COMMANDS,
  ADMIN_COMMANDS,
  OWNER_COMMANDS,
  CASSINO_COMMANDS,
  RP_OWNER_COMMANDS,
  RP_COMMANDS,
  THE_SIMS_COMMANDS,
  donoRP_COMMANDS,  
  INTERNET_COMMANDS,
  CHATBOT_COMMANDS,
  AVENTURA_COMMANDS,
  ADULTO_COMMANDS,
  ADULTO_CONFIG_COMMANDS,
  RP_CASSINO_CONFIG_COMMANDS,

  // Router helpers
  CORE_TEST_COMMANDS,
  MENU_MAIN_COMMANDS,
  MENU_STICKER_COMMANDS,
  MENU_SIMS_COMMANDS,
  MENU_AVENTURA_COMMANDS,
  MENU_BRINCADEIRAS_COMMANDS,
  MENU_RP_COMMANDS,
  MENU_CASSINO_COMMANDS,
  MENU_ADMIN_COMMANDS,
  MENU_AUDIO_COMMANDS,
  MENU_UTILIDADES_COMMANDS,
  MENU_JOGOS_COMMANDS,
  AUDIO_TOOLS_COMMANDS,
  CHANGELOG_COMMANDS,
  SUGESTOES_COMMANDS,
  DOWNLOAD_COMMANDS,
  SIMPLE_PING_COMMANDS,
  SIMPLE_RVISU_COMMANDS,
  SIMPLE_INFO_COMMANDS,
  SIMPLE_GRPCONT_COMMANDS,
  SIMPLE_TOTALCMD_COMMANDS,
  SIMPLE_RESGATAR_COMMANDS,
  RP_START_COMMANDS,
  RP_ONBOARDING_EXTRA_COMMANDS,
  RANDOM_FIG_COMMANDS,
  STICKER_METHOD_MAP,
  OWNER_MANAGE_BLOCK_COMMANDS,
  CASSINO_ALIAS_MAP,
  BJ_MESA_INTERCEPT_COMMANDS,
  BJ_MESA_BUY_ACTION_CMD,
  AUTOHELP_EXTRA_KNOWN,
  AUTOHELP_USAGE_MAP,
  AUTOHELP_IGNORED_UNKNOWN_IN_GROUP,

  PROFILE_RESET_COMMANDS,
  PROFILE_MAIN_COMMANDS,
  PROFILE_TRANSFER_COMMANDS,
  PROFILE_CONFIRMAR_COMMANDS,
  ADMIN_REBAIXAR_COMMANDS,
  COMMAND_MODULE_ALIAS,
};
  