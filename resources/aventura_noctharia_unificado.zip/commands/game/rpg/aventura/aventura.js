// commands/game/rpg/aventura/aventura.js
// Aventura (Version 2.0)
// Inclui: Bosses, Craft, Classes, Leilão Global, Arena PvP, Exploração.

const whatsappSafe = require('../../../../core/whatsappSafe');
const money = require('../../../../core/game/money');

const avtempos = require('./core/avtempo');
const aventuraStore = require('./core/storeAventura');
const regioes = require('./aventuraRegioes');
const raidRewards = require('./aventuraRaidRewards');
const aventuraPainelUI = require('./ui/aventuraPainel');
// =========================
// PERSISTÊNCIA (SSOT no core do RPG)
// =========================
async function __loadStore() {
  return aventuraStore.load();
}

function __scheduleWrite() {
  aventuraStore.saveDebounced();
}

// =========================
// HELPERS GERAIS
// =========================
function normalizeJid(jid) {
  return String(jid || '').trim();
}

function getUserKey(ctx, msg) {
  try {
    // SSOT: ctx.number/ctx.jid
    if (ctx && ctx.number) return String(ctx.number);
    const from = msg?.author || msg?.from || msg?.key?.remoteJid;
    return normalizeJid(from);
  } catch (_) {
    return 'unknown';
  }
}

function getDisplayName(ctx, msg, extra = {}) {
  const name =
    (ctx && (ctx.requesterName || ctx.pushName || ctx.senderName)) ||
    (extra && (extra.requesterName || extra.pushName || extra.senderName)) ||
    (msg && (msg.pushName || msg.senderName)) ||
    null;

  if (name && String(name).trim()) return String(name).trim();

  // Fallback: usa número (identidade real) quando o nome não está disponível
  const num = (ctx && ctx.number) || null;
  if (num && String(num).trim()) return String(num).trim();

  const k = normalizeJid(msg?.author || msg?.from || msg?.key?.remoteJid);
  if (k && k !== 'unknown') return k;

  return 'Jogador';
}


async function getChatKey(msg) {
  try {
    const chat = await msg.getChat();
    return normalizeJid(chat?.id?._serialized || chat?.id || msg?.from);
  } catch (_) {
    return normalizeJid(msg?.from);
  }
}

function dateKeyNow() {
  try {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const da = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${da}`;
  } catch (_) {
    return '0000-00-00';
  }
}

function weekKeyNow() {
  try {
    const d = new Date();
    // ISO-ish week key (ano-Wxx)
    const tmp = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    const dayNum = tmp.getUTCDay() || 7;
    tmp.setUTCDate(tmp.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(tmp.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((tmp - yearStart) / 86400000) + 1) / 7);
    const w = String(weekNo).padStart(2, '0');
    return `${tmp.getUTCFullYear()}-W${w}`;
  } catch (_) {
    return '0000-W00';
  }
}

function fmtGold(n) {
  const v = Number(n) || 0;
  return v.toLocaleString('pt-BR');
}

function parseGoldAmount(raw, available = null) {
  const src = String(raw || '').trim();
  if (!src) return 0;

  const lower = src.toLowerCase();
  const hasAvailable = available !== null && available !== undefined && Number.isFinite(Number(available));
  const avail = Math.max(0, Math.floor(Number(available) || 0));

  if (hasAvailable && (lower === 'tudo' || lower === 'all' || lower === 'max')) return avail;
  if (hasAvailable && (lower === 'metade' || lower === 'half')) return Math.floor(avail / 2);

  const parsed = (money && typeof money.parseMoneyInputBR === 'function')
    ? money.parseMoneyInputBR(src)
    : Number(src);

  const value = Math.max(0, Math.floor(Number(parsed) || 0));
  if (!hasAvailable) return value;
  return Math.min(avail, value);
}

function hpBar(cur, max, size = 10) {
  const m = Math.max(1, Number(max) || 1);
  const c = Math.max(0, Math.min(m, Number(cur) || 0));
  const filled = Math.max(0, Math.min(size, Math.round((c / m) * size)));
  const empty = Math.max(0, size - filled);
  return '[' + '█'.repeat(filled) + '░'.repeat(empty) + `] ${c}/${m}`;
}


// =========================
// SISTEMAS LEVES (Energia / Fama / Relíquias / Região)
// =========================
function ensureEnergia(user) {
  // Compat: mantém chamadas antigas, mas delega para o SSOT (core/avtempo.js)
  if (avtempos && typeof avtempos.ensureEnergyState === 'function') {
    return avtempos.ensureEnergyState(user);
  }

  // fallback defensivo (não deveria acontecer)
  if (!user.energia || typeof user.energia !== 'object') user.energia = { cur: 10, max: 10, lastAt: 0 };
  return user.energia;
}

function energiaNextMs(user) {
  if (avtempos && typeof avtempos.energyNextMs === 'function') {
    return avtempos.energyNextMs(user);
  }
  return 0;
}

function energiaGastaPara(enc) {
  if (enc && enc.isElite) return 2;
  return 1;
}

function temEnergia(user, custo) {
  const e = ensureEnergia(user);
  return (Number(e.cur || 0) >= Number(custo || 0));
}

function gastarEnergia(user, custo) {
  const e = ensureEnergia(user);
  const c = Math.max(0, Number(custo || 0));
  if (e.cur < c) return false;
  e.cur = Math.max(0, e.cur - c);
  if (!e.lastAt) e.lastAt = Date.now();
  return true;
}

function isRegiaoEventAtivo(user) {
  const endsAt = Number(user?.regionEvent?.endsAt || 0);
  return endsAt > Date.now();
}

function regiaoEventLeft(user) {
  const endsAt = Number(user?.regionEvent?.endsAt || 0);
  const rem = endsAt - Date.now();
  return rem > 0 ? rem : 0;
}

function bumpRegiaoProgress(user, regionKey, add) {
  // Compat: mantém assinatura usada no arquivo, mas a SSOT do mapa agora é aventuraRegioes.
  // - 1 marco por vez (evita spam)
  // - Ao fechar 100%: reseta e ativa evento regional curto
  const b = regioes.setBiome(user, regionKey);
  const out = regioes.applyProgress(user, add);

  if (out && out.milestoneHit && out.milestone && out.milestone.reward) {
    const rw = out.milestone.reward;
    if (rw.gold) user.gold = (Number(user.gold) || 0) + Math.max(0, Number(rw.gold) || 0);
    if (rw.energy) {
      // energia extra (sem comando novo)
      const e = ensureEnergia(user);
      e.cur = Math.min(e.max, Number(e.cur || 0) + Math.max(0, Number(rw.energy) || 0));
    }
    if (rw.lootBoostNext) regioes.addBuff(user, 'lootBoostNext', Number(rw.lootBoostNext) || 0);
    if (rw.eliteBoostNext) regioes.addBuff(user, 'eliteBoostNext', Number(rw.eliteBoostNext) || 0);
  }

  if (out && out.completed) {
    const dur = Number(avtempos.CD.regionEvent || (10 * 60 * 1000));
    user.regionEvent = { endsAt: Date.now() + dur, key: b.key };
    return true;
  }
  return false;
}

function ensureRegiaoContrato(user) {
  const reg = getRegiao(user);
  const biomeState = regioes.ensureBiomeState(user);
  const biomeProg = clamp(Number(biomeState?.progress || 0), 0, 100);
  const nextMilestone = regioes.getNextMilestone(user);

  // contratos (garante no painel sem flood)
  const dayKey = dateKeyNow();
  const cur = user.regionContract;

  // ===== Streak (por bioma) =====
  if (!user.regionStreak || typeof user.regionStreak !== 'object') {
    user.regionStreak = { lastDayKey: null, lastDoneDayKey: null, value: 0, regionKey: reg.key };
  }
  const st = user.regionStreak;

  // Se virou o dia: atualiza streak
  if (st.lastDayKey && st.lastDayKey !== dayKey) {
    const okYesterday = (st.lastDoneDayKey && st.lastDoneDayKey === st.lastDayKey && st.regionKey === reg.key);
    st.value = okYesterday ? Math.min(7, (Number(st.value) || 0) + 1) : 0;
  }
  st.lastDayKey = dayKey;
  st.regionKey = reg.key;

  // 1 por dia (por bioma atual)
  if (cur && cur.dayKey === dayKey && cur.regionKey === reg.key) return cur;

  const seed = makeStableSeedFromParts(user.__key, 'regiaoContrato', reg.key, dayKey);
  const goal = randInt(2, 4, seed);

  const baseGold = 180 + (goal * 70) + (Math.max(0, (Number(user.lvl || 1) - 1)) * 18);
  const streakMul = 1 + (clamp(Number(st.value) || 0, 0, 7) * 0.08);
  const rewardGold = Math.floor(baseGold * streakMul);

  user.regionContract = {
    dayKey,
    regionKey: reg.key,
    title: `Contrato — ${reg.name}`,
    desc: `Derrote ${goal} criatura(s) em ${reg.name}.`,
    goal,
    progress: 0,
    done: false,
    claimed: false,
    streak: clamp(Number(st.value) || 0, 0, 7),
    rewardGold,
  };
  return user.regionContract;
}

function ensureRegiaoContratoSemanal(user) {
  const reg = getRegiao(user);
  const wKey = weekKeyNow();
  const cur = user.regionWeekly;

  if (cur && cur.weekKey === wKey && cur.regionKey === reg.key) return cur;

  const seed = makeStableSeedFromParts(user.__key, 'regiaoSemanal', reg.key, wKey);
  const goal = randInt(10, 16, seed);
  const rewardGold = 1200 + (goal * 80) + (Math.max(0, (Number(user.lvl || 1) - 1)) * 35);

  user.regionWeekly = {
    weekKey: wKey,
    regionKey: reg.key,
    title: `Contrato Difícil — ${reg.name}`,
    desc: `Derrote ${goal} criatura(s) em ${reg.name} (semana).`,
    goal,
    progress: 0,
    done: false,
    claimed: false,
    rewardGold,
  };
  return user.regionWeekly;
}

function getRelicAtiva(user) {
  // escolhe a melhor relíquia do tipo DROP_ no inventário (sem comando extra)
  const inv = user.inv || {};
  const candidates = [];
  for (const [id, qty] of Object.entries(inv)) {
    if ((Number(qty) || 0) <= 0) continue;
    if (!String(id).startsWith('DROP_')) continue;
    const it = ITEM[id] || {};
    const rar = String(it.rarity || 'comum').toLowerCase();
    const score = (rar === 'mitico') ? 4 : (rar === 'epico') ? 3 : (rar === 'raro') ? 2 : 1;
    candidates.push({ id, score, rar });
  }
  candidates.sort((a, b) => b.score - a.score);
  return candidates[0] || null;
}

function relicBonus(user) {
  const r = getRelicAtiva(user);
  if (!r) return { hp: 0, goldMul: 1 };
  if (r.rar === 'mitico') return { hp: 35, goldMul: 1.07 };
  if (r.rar === 'epico') return { hp: 25, goldMul: 1.05 };
  if (r.rar === 'raro') return { hp: 15, goldMul: 1.03 };
  return { hp: 8, goldMul: 1.01 };
}

function clamp(n, a, b) {
  n = Number(n) || 0;
  return Math.max(a, Math.min(b, n));
}

function pickBySeed(seedStr, list) {
  const s = String(seedStr || '');
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const idx = Math.abs(h) % list.length;
  return list[idx];
}

function randInt(min, max, seedObj) {
  // seedObj: { v }
  seedObj.v = Math.imul(seedObj.v ^ 0x9e3779b9, 0x85ebca6b);
  const x = (seedObj.v >>> 0) / 0xffffffff;
  return Math.floor(min + x * (max - min + 1));
}

function makeStableSeedFromParts(...parts) {
  // Seed estável e auditável (determinístico).
  // Retorna objeto { v } para uso em randInt.
  let v = 0x811c9dc5;
  const s = parts.map(p => String(p ?? '')).join('|');
  for (let i = 0; i < s.length; i++) {
    v ^= s.charCodeAt(i);
    v = Math.imul(v, 16777619);
  }
  return { v: (v >>> 0) || 1 };
}

function upsertEffect(list, eff) {
  if (!Array.isArray(list) || !eff || !eff.key) return;
  const k = String(eff.key);
  const idx = list.findIndex(e => e && e.key === k);
  if (idx >= 0) list.splice(idx, 1);
  list.push(eff);
}

function makeMarketUid(store) {
  const set = new Set((store?.market || []).map(m => String(m.uid)));
  for (let i = 0; i < 25; i++) {
    const a = Date.now().toString(36).slice(-6);
    const b = Math.floor(Math.random() * 46656).toString(36).padStart(3, '0'); // 36^3
    const uid = (a + b).toUpperCase();
    if (!set.has(uid)) return uid;
  }
  // fallback bem improvável
  return (Date.now().toString(36) + Math.random().toString(36).slice(2, 6)).toUpperCase();
}

function safeNumFromArgs(v) {
  const n = Number(String(v || '').replace(/[^\d]/g, ''));
  return Number.isFinite(n) ? n : 0;
}

// =========================
// CATÁLOGO ITENS (BÁSICO)
// =========================
const ITEM = {
  POT_PEQ: { name: 'Poção Pequena', desc: 'Cura 50 HP', price: 90, trade: true, rarity: 'comum' },
  POT_MED: { name: 'Poção Média', desc: 'Cura 120 HP', price: 220, trade: true, rarity: 'comum' },
  POT_GRA: { name: 'Poção Grande', desc: 'Cura 250 HP', price: 450, trade: true, rarity: 'comum' },
  POT_SORTE: { name: 'Poção da Sorte', desc: '+10% loot por 10 lutas (+2% crit)', price: 650, trade: true, rarity: 'raro' },

  // Noctharia (DARK) — suporte ao up
  POT_SOMBRA: { name: 'Poção de Sombra', desc: 'Cura 50 HP (Noctharia)', price: 0, trade: false, rarity: 'comum' },
  POT_ABISSAL: { name: 'Elixir Abissal', desc: '-8% corrupção (Noctharia)', price: 0, trade: false, rarity: 'raro' },

  MAT_FERRO: { name: 'Ferro Bruto', desc: 'Material de craft', price: 15, trade: true, rarity: 'comum' },
  MAT_COURO: { name: 'Couro', desc: 'Material de craft', price: 18, trade: true, rarity: 'comum' },
  MAT_ERVA: { name: 'Erva', desc: 'Material de alquimia', price: 10, trade: true, rarity: 'comum' },
  MAT_ESS: { name: 'Essência', desc: 'Material raro', price: 120, trade: true, rarity: 'raro' },
  MAT_CRISTAL: { name: 'Cristal', desc: 'Material muito raro', price: 260, trade: true, rarity: 'epico' },

  // Drops especiais

  MAT_PRESA: { name: 'Presas', desc: 'Material de craft', price: 22, trade: true, rarity: 'comum' },
  MAT_COURO_RES: { name: 'Couro Resistente', desc: 'Material de craft', price: 35, trade: true, rarity: 'comum' },
  MAT_FRAGMENTO: { name: 'Fragmento Antigo', desc: 'Fragmento mágico antigo', price: 95, trade: true, rarity: 'raro' },
  MAT_ESS_INST: { name: 'Essência Instável', desc: 'Essência rara e volátil', price: 160, trade: true, rarity: 'raro' },
  MAT_RELIQ: { name: 'Relíquia Quebrada', desc: 'Relíquia danificada para forjas especiais', price: 240, trade: true, rarity: 'epico' },

  DROP_ESPADA: { name: 'Espada Ancestral', desc: 'Arma lendária', price: 2500, trade: true, rarity: 'mitico' },
  DROP_ANEL: { name: 'Anel Arcano', desc: 'Acessório mágico', price: 1900, trade: true, rarity: 'epico' },
  DROP_ESCAMA_RARA: { name: 'Escama Rara', desc: 'Componente raro', price: 900, trade: true, rarity: 'raro' },
  DROP_ESS_SOMBRA: { name: 'Essência Sombria', desc: 'Componente sombrio', price: 1200, trade: true, rarity: 'epico' },
  // Equipamentos forjáveis
  ARMA_LAMINA_BRUTA: { name: 'Lâmina Bruta', desc: 'Arma simples para iniciantes', price: 350, trade: true, rarity: 'comum' },
  ARM_COURO_LEVE: { name: 'Armadura de Couro Leve', desc: 'Proteção básica de caçador', price: 420, trade: true, rarity: 'comum' },
  ACC_TALISMA_ANTIGO: { name: 'Talismã Antigo', desc: 'Acessório com energia ancestral', price: 1600, trade: true, rarity: 'epico' },

};

function itemName(itemId) {
  const raw = String(itemId || '').trim();
  const known = ITEM[raw]?.name;
  if (known) return known;

  // evita “vazar” tokens internos tipo: magic_xxx__
  if (/^magic_[a-z0-9]+__+$/i.test(raw)) return '✨ Magia Desconhecida';

  return raw;
}

function rarityLabel(r) {
  const k = String(r || '').toLowerCase().trim();
  if (k === 'mitico') return '🟠 Mítico';
  if (k === 'epico') return '🟣 Épico';
  if (k === 'raro') return '🔵 Raro';
  return '⚪ Comum';
}

function itemCategory(itemId) {
  const id = String(itemId || '').trim();
  if (!id) return 'Material';
  if (id.startsWith('POT_')) return 'Poção';
  if (id.startsWith('DROP_')) return 'Relíquia';
  if (id.startsWith('ARMA_')) return 'Arma';
  if (id.startsWith('ARM_')) return 'Armadura';
  if (id.startsWith('ACC_')) return 'Acessório';
  if (id.startsWith('MAT_')) return 'Material';
  return 'Artefato';
}

function lootLine(itemId, qty) {
  const rar = rarityLabel(ITEM[itemId]?.rarity || 'comum');
  const cat = itemCategory(itemId);
  const q = Number(qty) || 1;
  return `• ${itemName(itemId)} x${q} — ${rar} • ${cat}`;
}

function lootCelebration(itemId) {
  const r = String(ITEM[itemId]?.rarity || '').toLowerCase();
  if (r === 'mitico') return '🌟 Um achado digno de canções antigas!';
  if (r === 'epico') return '✨ Você sentiu o peso de um tesouro raro nas mãos.';
  if (r === 'raro') return '🔷 Um espólio incomum apareceu no seu caminho.';
  return '';
}

function nextObjectiveHint(prefix, user) {
  const L = Math.max(1, Number(user?.lvl) || 1);
  if (L < 3) return `➡️ Próximo passo: *${prefix}avcacar* até Nv.3 (ameaças maiores).`;
  if (L < 5) return `➡️ Próximo passo: alterne *${prefix}avcacar* e *${prefix}avexp* para juntar materiais.`;
  if (L < 6) return `➡️ Próximo passo: use *${prefix}craft* para fortalecer seu kit e chegue ao Nv.6.`;
  return `➡️ Próximo passo: *${prefix}boss* e depois *${prefix}matarboss* para o teste final.`;
}


function normTxt(v) {
  return String(v || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

function findItemIdByInput(input) {
  const raw = String(input || '').trim();
  if (!raw) return null;
  if (ITEM[raw]) return raw;
  const q = normTxt(raw);
  // tenta por nome
  for (const [id, it] of Object.entries(ITEM)) {
    if (!it) continue;
    const n = normTxt(it.name);
    if (n === q) return id;
  }
  // tenta por "contém"
  for (const [id, it] of Object.entries(ITEM)) {
    if (!it) continue;
    const n = normTxt(it.name);
    if (n.includes(q)) return id;
  }
  return null;
}


// =========================
// CLASSES
// =========================
const CLASSES = [
  {
    key: 'guerreiro',
    name: 'Guerreiro',
    passive: '+10% defesa',
    h1: { name: 'Golpe Pesado', cd: 3, type: 'atk', mult: 1.35 },
    h2: { name: 'Postura Firme', cd: 5, type: 'def', reduce: 0.40, turns: 2 },
  },
  {
    key: 'ladino',
    name: 'Ladino',
    passive: '+10% loot',
    h1: { name: 'Fumaça', cd: 4, type: 'evade', charges: 2 },
    h2: { name: 'Ataque Furtivo', cd: 5, type: 'atk', mult: 1.55, requires: 'distr' },
  },
  {
    key: 'mago',
    name: 'Mago',
    passive: '+5% crítico',
    h1: { name: 'Bola de Fogo', cd: 3, type: 'dot', burnPct: 0.06, turns: 2, dmgMult: 1.05 },
    h2: { name: 'Congelar', cd: 5, type: 'debuff', freezeTurns: 1 },
  },
  {
    key: 'clerigo',
    name: 'Clérigo',
    passive: '+5% cura',
    h1: { name: 'Cura', cd: 3, type: 'heal', healPct: 0.30 },
    h2: { name: 'Benção', cd: 6, type: 'buff', dmgUp: 0.15, turns: 2 },
  },
  {
    key: 'barbaro',
    name: 'Bárbaro',
    passive: '+10% ataque',
    h1: { name: 'Fúria', cd: 5, type: 'buff', dmgUp: 0.20, takeMore: 0.20, turns: 2 },
    h2: { name: 'Esmagar', cd: 4, type: 'atk', mult: 1.45 },
  },
  {
    key: 'alquimista',
    name: 'Alquimista',
    passive: '+1 Poção em loot (10%)',
    h1: { name: 'Veneno', cd: 3, type: 'dot', bleedPct: 0.06, turns: 2, dmgMult: 1.0 },
    h2: { name: 'Purificar', cd: 5, type: 'heal_cleanse', healPct: 0.20 },
  },
  {
    key: 'necromante',
    name: 'Necromante',
    passive: '+5% drenagem',
    h1: { name: 'Maldição', cd: 4, type: 'debuff', curseTurns: 2 },
    h2: { name: 'Servo', cd: 6, type: 'pet', petPct: 0.15, turns: 3 },
  }
];

function classByKey(k) {
  const key = String(k || '').toLowerCase().trim();
  return CLASSES.find(c => c.key === key) || null;
}

// =========================
// BOSSES
// =========================
const BOSSES = [
  { id: 'goblin_chefe', name: 'Chefe Goblin', hp: 180, atk: 18, drops: [{ itemId: 'MAT_FERRO', chance: 0.50, min: 2, max: 6 }, { itemId: 'MAT_COURO', chance: 0.35, min: 1, max: 3 }] },
  { id: 'lobo_alpha', name: 'Lobo Alpha', hp: 210, atk: 20, drops: [{ itemId: 'MAT_COURO', chance: 0.55, min: 2, max: 5 }, { itemId: 'MAT_ERVA', chance: 0.25, min: 1, max: 3 }] },
  { id: 'mago_sombrio', name: 'Mago Sombrio', hp: 260, atk: 24, drops: [{ itemId: 'MAT_ESS', chance: 0.20, min: 1, max: 1 }, { itemId: 'DROP_ANEL', chance: 0.10, min: 1, max: 1 }], bossEffect: { curseChance: 0.18 } },
  { id: 'dragao_jovem', name: 'Dragão Jovem', hp: 320, atk: 28, drops: [{ itemId: 'DROP_ESCAMA_RARA', chance: 0.25, min: 1, max: 1 }, { itemId: 'MAT_CRISTAL', chance: 0.35, min: 1, max: 1 }], bossEffect: { burnChance: 0.22 } },
  { id: 'suserano_vampiro', name: 'Suserano Vampiro', hp: 460, atk: 32, drops: [{ itemId: 'DROP_ESS_SOMBRA', chance: 0.25, min: 1, max: 1 }, { itemId: 'DROP_ANEL', chance: 0.18, min: 1, max: 1 }], bossEffect: { bleedChance: 0.18 } },
  { id: 'reliquia_antiga', name: 'Relíquia Antiga', hp: 520, atk: 36, drops: [{ itemId: 'DROP_ESPADA', chance: 0.12, min: 1, max: 1 }, { itemId: 'MAT_CRISTAL', chance: 0.35, min: 1, max: 2 }], bossEffect: { freezeChance: 0.16 } },
];

function bossById(id) {
  const k = String(id || '').trim();
  return BOSSES.find(b => b.id === k) || BOSSES[0];
}

function pickBossOfDay(dateKey) {
  return pickBySeed(`bossdia:${dateKey}`, BOSSES);
}

function pickGlobalBoss(dateKey) {
  const list = BOSSES.slice().reverse();
  return pickBySeed(`bossglobal:${dateKey}`, list);
}
// =========================
// NOCTHARIA (DARK) — BOSS GLOBAL
// =========================
const DARK_GLOBAL_BOSS = {
  id: 'leviata_nox',
  name: 'Leviatã de NØX',
  hp: 120000,
  atk: 42,
  drops: [
    { itemId: 'MAT_FRAG_DIVINO', chance: 0.22, min: 1, max: 2 },
    { itemId: 'MAT_FRAG_ABISSAL', chance: 0.65, min: 2, max: 6 },
    { itemId: 'ARMA_ESPADA_ABISSAL', chance: 0.04, min: 1, max: 1 },
  ]
};

function ensureDarkGlobalBoss(store) {
  const today = dateKeyNow();
  if (!store.darkGlobalBoss || store.darkGlobalBoss.date !== today) {
    store.darkGlobalBoss = {
      date: today,
      bossId: DARK_GLOBAL_BOSS.id,
      name: DARK_GLOBAL_BOSS.name,
      hpMax: DARK_GLOBAL_BOSS.hp,
      hp: DARK_GLOBAL_BOSS.hp
    };
    __scheduleWrite();
  }
  return store.darkGlobalBoss;
}

function computeDarkBaseStats(user) {
  const lvl = Math.max(1, Number(user.dark?.stats?.lvl) || 1);
  const hp = 130 + (lvl - 1) * 12;
  const atk = 20 + (lvl - 1) * 2.4;
  const def = 7 + (lvl - 1) * 1.3;
  return { hp, atk, def };
}

function ensureDarkBattle(user, boss) {
  if (!user.dark) user.dark = {};
  if (user.dark.battle && user.dark.battle.bossId === boss.id) return user.dark.battle;
  const st = computeDarkBaseStats(user);
  user.dark.battle = {
    bossId: boss.id,
    bossName: boss.name,
    bossHp: boss.hp,
    bossHpMax: boss.hp,
    playerHp: st.hp,
    playerHpMax: st.hp,
    turn: 0,
    seed: { v: 0xdeadbeef ^ Date.now() },
    cds: { h1: 0, h2: 0 },
    pEff: [],
    bEff: [],
  };
  return user.dark.battle;
}

function darkRollDrops(user, boss, seed) {
  const drops = [];
  for (const d of (boss.drops || [])) {
    const chance = clamp(Number(d.chance || 0), 0, 0.95);
    if (randInt(1, 1000, seed) / 1000 <= chance) {
      drops.push({ itemId: d.itemId, qty: randInt(d.min || 1, d.max || 1, seed) });
    }
  }
  return drops;
}


// =========================
// USER STATE
// =========================
function ensureUser(store, userKey) {
  if (!store.users[userKey]) {
    store.users[userKey] = {
      gold: 0,
      xp: 0,
      lvl: 1,
      classe: null,
      inv: {},
      equip: { weapon: null, armor: null, acc: null },
      buffs: { lootBattles: 0 },
      daily: {},
      weekly: {},
      battle: null,
      lastAttackAt: 0,
      // Novos campos
      arena: { wins: 0, losses: 0, points: 1000, lastMatch: 0 },
      lastExplore: 0,
      // Caça (progressão)
      encounter: null,
      battleLite: null,
      hunt: { streak: 0, best: 0 },
      lastHunt: 0,
      // Expansões
      region: 'floresta',
      estilo: 'equilibrado',
      titulo: null,
      prestigio: 0,
      cofre: 0,
      lastRobGoldAt: 0,
      feridoAte: 0,
energia: { cur: 10, max: 10, lastAt: 0 },
fama: 0,
elitePity: 0,
regionProgress: {},
regionContract: null,
regionEvent: { endsAt: 0, key: null },
relicAtiva: null,
      companheiro: null,
      conquistas: {},
      historico: [],
      jornada: { elite: 0, boss: 0 },
      missoes: { key: null, list: [] },
      season: { id: null, ouro: 0, arena: 0, boss: 0 }
    };

  }
  // Migração suave para users antigos que não tenham os novos campos
  const u = store.users[userKey];
  if (!u.arena) u.arena = { wins: 0, losses: 0, points: 1000, lastMatch: 0 };
  if (!u.lastExplore) u.lastExplore = 0;
  if (u.encounter === undefined) u.encounter = null;
  if (u.battleLite === undefined) u.battleLite = null;
  if (!u.hunt) u.hunt = { streak: 0, best: 0 };
  if (!u.lastHunt) u.lastHunt = 0;

  if (!u.region) u.region = 'floresta';
  if (!u.estilo) u.estilo = 'equilibrado';
  if (u.titulo === undefined) u.titulo = null;
  if (u.prestigio === undefined) u.prestigio = 0;
  if (u.cofre === undefined) u.cofre = 0;
  if (u.lastRobGoldAt === undefined) u.lastRobGoldAt = 0;
  if (!u.feridoAte) u.feridoAte = 0;
if (!u.energia || typeof u.energia !== 'object') u.energia = { cur: 10, max: 10, lastAt: 0 };
if (u.fama === undefined) u.fama = 0;
if (u.elitePity === undefined) u.elitePity = 0;
if (!u.regionProgress || typeof u.regionProgress !== 'object') u.regionProgress = {};
if (u.regionContract === undefined) u.regionContract = null;
if (!u.regionEvent || typeof u.regionEvent !== 'object') u.regionEvent = { endsAt: 0, key: null };
if (u.relicAtiva === undefined) u.relicAtiva = null;
  if (u.companheiro === undefined) u.companheiro = null;
  if (!u.conquistas || typeof u.conquistas !== 'object') u.conquistas = {};
  if (!Array.isArray(u.historico)) u.historico = [];
  if (!u.jornada || typeof u.jornada !== 'object') u.jornada = { elite: 0, boss: 0 };
  if (!u.missoes || typeof u.missoes !== 'object') u.missoes = { key: null, list: [] };
  if (!u.season || typeof u.season !== 'object') u.season = { id: null, ouro: 0, arena: 0, boss: 0 };

  return u;
}

function getUserIfExists(store, userKey) {
  const u = store && store.users ? store.users[userKey] : null;
  if (!u) return null;
  // Migração suave para users antigos que não tenham os novos campos
  if (!u.arena) u.arena = { wins: 0, losses: 0, points: 1000, lastMatch: 0 };
  if (!u.lastExplore) u.lastExplore = 0;
  if (u.encounter === undefined) u.encounter = null;
  if (u.battleLite === undefined) u.battleLite = null;
  if (!u.hunt) u.hunt = { streak: 0, best: 0 };
  if (!u.lastHunt) u.lastHunt = 0;
  return u;
}


function invGet(user, itemId) { return Number(user.inv?.[itemId] || 0) || 0; }
function invAdd(user, itemId, qty) {
  if (!user.inv) user.inv = {};
  const cur = invGet(user, itemId);
  const next = cur + (Number(qty) || 0);
  if (next <= 0) delete user.inv[itemId];
  else user.inv[itemId] = next;
}
function invHas(user, itemId, qty) {
  return invGet(user, itemId) >= (Number(qty) || 0);
}

// =========================
// DARK INVENTÁRIO (Noctharia) — isolado do RP
// =========================
function darkInvGet(user, itemId) { return Number(user.dark?.inv?.[itemId] || 0) || 0; }
function darkInvAdd(user, itemId, qty) {
  if (!user.dark) user.dark = {};
  if (!user.dark.inv) user.dark.inv = {};
  const cur = darkInvGet(user, itemId);
  const next = cur + (Number(qty) || 0);
  if (next <= 0) delete user.dark.inv[itemId];
  else user.dark.inv[itemId] = next;
}
function darkInvHas(user, itemId, qty) {
  return darkInvGet(user, itemId) >= (Number(qty) || 0);
}

// =========================
// DARK CRAFT (Noctharia)
// =========================
// Nota: as receitas podem ser expandidas no futuro.
// Mantemos um default seguro para evitar ReferenceError.
const DARK_RECIPES = [];

function darkRecipeById(rid) {
  const id = String(rid || '').trim();
  if (!id) return null;
  return (DARK_RECIPES || []).find(r => String(r.id) === id) || null;
}

function ensureBattle(user, boss) {
  if (user.battle && user.battle.bossId === boss.id) return user.battle;
  user.battle = {
    bossId: boss.id,
    bossName: boss.name,
    bossHp: boss.hp,
    bossHpMax: boss.hp,
    playerHp: computeBaseStats(user).hp,
    playerHpMax: computeBaseStats(user).hp,
    turn: 0,
    seed: { v: 0xdeadbeef ^ Date.now() },
    cds: { h1: 0, h2: 0 },
    pEff: [],
    bEff: [],
  };
  return user.battle;
}

// =========================
// STATS / PROGRESS
// =========================
function computeBaseStats(user) {
  const lvl = Math.max(1, Number(user.lvl) || 1);
  const eNow = ensureEnergia(user);
  const energiaZero = (Number(eNow.cur || 0) <= 0);
  const regEvtLeft = regiaoEventLeft(user);
  const regEvtAtivo = regEvtLeft > 0;
  const hp = 120 + (lvl - 1) * 10;
  const atk = 18 + (lvl - 1) * 2.2;
  const def = 6 + (lvl - 1) * 1.2;
  const cls = classByKey(user.classe);
  let hp2 = hp, atk2 = atk, def2 = def;
  const pr = Math.max(0, Math.min(10, Number(user.prestigio) || 0));
  if (pr > 0) {
    hp2 = Math.round(hp2 * (1 + pr * 0.02));
    atk2 = atk2 * (1 + pr * 0.01);
    def2 = def2 * (1 + pr * 0.01);
  }
  if (cls?.key === 'barbaro') atk2 = Math.round(atk2 * 1.10);
  if (cls?.key === 'guerreiro') def2 = Math.round(def2 * 1.10);
  const rb = relicBonus(user);
  hp2 = Math.max(1, Math.round(hp2 + (rb.hp || 0)));
  return { hp: hp2, atk: atk2, def: def2 };
}

function needXpForLevel(lvl) {
  const L = Math.max(1, Number(lvl) || 1);
  const x = (L - 1);
  // Curva leve: early game rápido, late game mais longo.
  return 100 + x * 70 + x * x * 6;
}

function maybeLevelUp(user) {
  let leveled = 0;
  while (user.xp >= needXpForLevel(user.lvl)) {
    user.xp -= needXpForLevel(user.lvl);
    user.lvl += 1;
    leveled++;
  }
  return leveled;
}

// =========================
// COMBATE
// =========================
function effTick(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  for (const e of list) {
    if (!e) continue;
    const t = Number(e.turns || 0) - 1;
    if (t > 0) out.push({ ...e, turns: t });
  }
  return out;
}

function findEff(list, key) {
  if (!Array.isArray(list)) return null;
  return list.find(e => e && e.key === key) || null;
}

function applyDotOnTurn(battle) {
  let log = [];
  const burn = findEff(battle.bEff, 'burn');
  if (burn) {
    const dmg = Math.max(1, Math.round((burn.pct || 0.06) * battle.bossHpMax));
    battle.bossHp = Math.max(0, battle.bossHp - dmg);
    log.push(`🔥 Chamas no inimigo: -${dmg}`);
  }
  const pBurn = findEff(battle.pEff, 'burn');
  if (pBurn) {
    const dmg = Math.max(1, Math.round((pBurn.pct || 0.05) * battle.playerHpMax));
    battle.playerHp = Math.max(0, battle.playerHp - dmg);
    log.push(`🔥 Chamas: -${dmg}`);
  }
  const bleed = findEff(battle.pEff, 'bleed');
  if (bleed) {
    const dmg = Math.max(1, Math.round((bleed.pct || 0.06) * battle.playerHpMax));
    battle.playerHp = Math.max(0, battle.playerHp - dmg);
    log.push(`🩸 Sangramento: -${dmg}`);
  }
  return log;
}

function computeCritChance(user) {
  const cls = classByKey(user.classe);
  let c = 0.10;
  if (cls?.key === 'ladino') c += 0.08;
  if (user.buffs?.lootBattles > 0) c += 0.02;
  return clamp(c, 0.05, 0.35);
}

function computeLootBonus(user) {
  const cls = classByKey(user.classe);
  let b = 0;
  if (cls?.key === 'ladino') b += 0.10;
  if (user.buffs?.lootBattles > 0) b += 0.10;
  return clamp(b, 0, 0.25);
}

function chooseSkillIntent(user, battle, want) {
  const cls = classByKey(user.classe);
  if (!cls) return null;
  const h1Ready = battle.cds.h1 <= 0;
  const h2Ready = battle.cds.h2 <= 0;
  if (want === 'h1' && h1Ready) return 'h1';
  if (want === 'h2' && h2Ready) return 'h2';
  if (want === 'h1' || want === 'h2') return null;
  const hpPct = battle.playerHp / Math.max(1, battle.playerHpMax);
  if (findEff(battle.pEff, 'freeze')) return null;
  if (hpPct <= 0.40 && h2Ready) {
    if (['guerreiro','ladino','mago','clerigo','alquimista'].includes(cls.key)) return 'h2';
  }
  if (h1Ready) return 'h1';
  if (h2Ready) return 'h2';
  return null;
}

function applySkill(user, battle, boss, skillKey, seed) {
  const cls = classByKey(user.classe);
  if (!cls) return { used: false, text: '' };
  const sk = (skillKey === 'h1') ? cls.h1 : cls.h2;
  if (!sk) return { used: false, text: '' };

  const setCd = () => {
    if (skillKey === 'h1') battle.cds.h1 = sk.cd; else battle.cds.h2 = sk.cd;
  };

  const st = computeBaseStats(user);
  let text = `✨ *${sk.name}*`;
  let extra = [];

  if (sk.type === 'atk') {
    if (sk.requires === 'distr' && !findEff(battle.bEff, 'distr')) {
      return { used: false, text: '⚠️ O alvo não está distraído para executar Ataque Furtivo.' };
    }
    setCd();
    let mult = Number(sk.mult) || 1.0;
    if (cls.key === 'barbaro') {
      const hpPct = battle.playerHp / Math.max(1, battle.playerHpMax);
      mult += clamp((1 - hpPct) * 0.50, 0, 0.35);
    }
    const bless = findEff(battle.pEff, 'bless');
    if (bless) mult += Number(bless.dmgUp || 0);
    const vuln = findEff(battle.bEff, 'vuln');
    if (vuln) mult += Number(vuln.vuln || 0);
    const fury = findEff(battle.pEff, 'fury');
    if (fury) mult += Number(fury.dmgUp || 0);

    let dmg = Math.max(1, Math.round(st.atk * mult));
    const critChance = computeCritChance(user);
    if (randInt(1, 100, seed) <= Math.round(critChance * 100)) {
      dmg = Math.round(dmg * 1.5);
      extra.push('💥 Golpe crítico!');
    }
    battle.bossHp = Math.max(0, battle.bossHp - dmg);
    extra.push(`-${dmg} HP no boss`);
    return { used: true, text: `${text}\n${extra.join(' ')}` };
  }

  if (sk.type === 'def') {
    setCd();
    upsertEffect(battle.pEff, { key: 'posture', turns: Number(sk.turns || 2), reduce: Number(sk.reduce || 0.35) });
    return { used: true, text: `${text}\n🛡 Postura reforçada por ${sk.turns || 2} turnos.` };
  }

  if (sk.type === 'evade') {
    setCd();
    upsertEffect(battle.pEff, { key: 'smoke', turns: 3, charges: Number(sk.charges || 2) });
    return { used: true, text: `${text}\n💨 Você evitará por ${sk.charges || 2} ataques (enquanto durar).` };
  }

  if (sk.type === 'dot') {
    setCd();
    const dmgMult = Number(sk.dmgMult || 1.0);
    const dmg = Math.max(1, Math.round(st.atk * dmgMult));
    battle.bossHp = Math.max(0, battle.bossHp - dmg);
    extra.push(`-${dmg} HP`);
    if (sk.burnPct) {
      upsertEffect(battle.bEff, { key: 'burn', turns: Number(sk.turns || 2), pct: Number(sk.burnPct || 0.06) });
      extra.push('🔥 queimadura');
    }
    if (sk.bleedPct) {
      upsertEffect(battle.pEff, { key: 'bleed', turns: Number(sk.turns || 2), pct: Number(sk.bleedPct || 0.06) });
      extra.push('🩸 sangramento');
    }
    return { used: true, text: `${text}\n${extra.join(' ')}` };
  }

  if (sk.type === 'debuff') {
    setCd();
    if (sk.freezeTurns) {
      upsertEffect(battle.pEff, { key: 'freeze', turns: Number(sk.freezeTurns || 1) });
      return { used: true, text: `${text}\n🧊 O frio te prende por ${sk.freezeTurns || 1} turno(s)!` };
    }
    if (sk.curseTurns) {
      upsertEffect(battle.pEff, { key: 'curse', turns: Number(sk.curseTurns || 2) });
      return { used: true, text: `${text}\n😵 Maldição por ${sk.curseTurns || 2} turnos.` };
    }
    return { used: true, text: `${text}` };
  }

  if (sk.type === 'heal') {
    setCd();
    const add = Math.max(1, Math.round(battle.playerHpMax * Number(sk.healPct || 0.25)));
    const cls2 = classByKey(user.classe);
    let add2 = add;
    if (cls2?.key === 'clerigo') add2 = Math.round(add2 * 1.05);
    battle.playerHp = Math.min(battle.playerHpMax, battle.playerHp + add2);
    return { used: true, text: `${text}\n💚 Cura: +${add2} HP` };
  }

  if (sk.type === 'heal_cleanse') {
    setCd();
    const add = Math.max(1, Math.round(battle.playerHpMax * Number(sk.healPct || 0.20)));
    battle.playerHp = Math.min(battle.playerHpMax, battle.playerHp + add);
    // remove bleed/curse/burn/freeze
    battle.pEff = (battle.pEff || []).filter(e => !['bleed','curse','burn','freeze'].includes(e.key));
    return { used: true, text: `${text}\n💚 Cura: +${add} HP e purificação.` };
  }

  if (sk.type === 'buff') {
    setCd();
    if (sk.dmgUp) {
      upsertEffect(battle.pEff, { key: 'bless', turns: Number(sk.turns || 2), dmgUp: Number(sk.dmgUp || 0.15) });
      return { used: true, text: `${text}\n✨ Dano +${Math.round((sk.dmgUp || 0) * 100)}% por ${sk.turns || 2} turnos.` };
    }
    if (sk.takeMore != null || sk.dmgUp != null) {
      upsertEffect(battle.pEff, { key: 'fury', turns: Number(sk.turns || 2), dmgUp: Number(sk.dmgUp || 0.20), takeMore: Number(sk.takeMore || 0.20) });
      return { used: true, text: `${text}\n😡 Fúria ativa por ${sk.turns || 2} turnos.` };
    }
    return { used: true, text: `${text}` };
  }

  if (sk.type === 'shield') {
    setCd();
    upsertEffect(battle.pEff, { key: 'shield', turns: Number(sk.turns || 2), absorbPct: Number(sk.absorbPct || 0.35) });
    return { used: true, text: `${text}\n🛡 Escudo por ${sk.turns || 2} turnos.` };
  }

  if (sk.type === 'pet') {
    setCd();
    upsertEffect(battle.pEff, { key: 'pet', turns: Number(sk.turns || 3), petPct: Number(sk.petPct || 0.15) });
    return { used: true, text: `${text}\n🧟 Um servo lutará por ${sk.turns || 3} turnos.` };
  }

  return { used: false, text: '' };
}

function bossAttack(user, battle, boss, seed) {
  if (battle.bossHp <= 0 || battle.playerHp <= 0) return { dmg: 0, text: '' };
  const smoke = findEff(battle.pEff, 'smoke');
  if (smoke && (smoke.charges || 0) > 0) {
    smoke.charges--;
    return { dmg: 0, text: '💨 Você se esquiva!' };
  }
  let atk = Number(boss.atk || 20);
  const roar = findEff(battle.bEff, 'roar');
  if (roar) atk = Math.round(atk * (1 - (roar.bossAtkDown || 0.20)));
  const posture = findEff(battle.pEff, 'posture');
  let reduce = posture ? Number(posture.reduce || 0.30) : 0;
  const fury = findEff(battle.pEff, 'fury');
  if (fury) atk = Math.round(atk * (1 + (fury.takeMore || 0.20)));
  const shield = findEff(battle.pEff, 'shield');
  if (shield) reduce = 1 - (1 - reduce) * (1 - (shield.absorbPct || 0.35));
  let dmg = Math.max(1, Math.round(atk * (1 - reduce)));
  battle.playerHp = Math.max(0, battle.playerHp - dmg);

  const eff = boss.bossEffect || {};
  let effectsApplied = [];
  if (eff.curseChance && randInt(1, 100, seed) <= eff.curseChance * 100) {
    upsertEffect(battle.pEff, { key: 'curse', turns: 2 });
    effectsApplied.push('😵');
  }
  if (eff.bleedChance && randInt(1, 100, seed) <= eff.bleedChance * 100) {
    upsertEffect(battle.pEff, { key: 'bleed', turns: 2, pct: 0.06 });
    effectsApplied.push('🩸');
  }
  if (eff.freezeChance && randInt(1, 100, seed) <= eff.freezeChance * 100) {
    upsertEffect(battle.pEff, { key: 'freeze', turns: 1 });
    effectsApplied.push('🧊');
  }
  if (eff.burnChance && randInt(1, 100, seed) <= eff.burnChance * 100) {
    upsertEffect(battle.pEff, { key: 'burn', turns: 2, pct: 0.05 });
    effectsApplied.push('🔥');
  }

  return { dmg, text: effectsApplied.join(' ') };
}

function playerAttackBase(user, battle, boss, seed) {
  const st = computeBaseStats(user);
  let atk = st.atk;
  const curse = findEff(battle.pEff, 'curse');
  if (curse) atk = Math.round(atk * 0.85);
  const bless = findEff(battle.pEff, 'bless');
  if (bless) atk = Math.round(atk * (1 + (bless.dmgUp || 0.15)));
  const vuln = findEff(battle.bEff, 'vuln');
  if (vuln) atk = Math.round(atk * (1 + (vuln.vuln || 0.12)));

  let dmg = Math.max(1, Math.round(atk * randInt(85, 115, seed) / 100));
  const critChance = computeCritChance(user);
  if (randInt(1, 100, seed) <= Math.round(critChance * 100)) {
    dmg = Math.round(dmg * 1.5);
    return { dmg, crit: true };
  }
  return { dmg, crit: false };
}

function applyTurn(user, boss, battle, wantSkill, seed) {
  const lines = [];
  battle.turn++;

  // DOT tick no começo do turno
  const dot = applyDotOnTurn(battle);
  if (dot.length) lines.push(...dot);

  if (battle.playerHp <= 0 || battle.bossHp <= 0) {
    battle.cds.h1 = Math.max(0, (battle.cds.h1 || 0) - 1);
    battle.cds.h2 = Math.max(0, (battle.cds.h2 || 0) - 1);
    battle.pEff = effTick(battle.pEff);
    battle.bEff = effTick(battle.bEff);
    return lines;
  }

  // Player action
  if (findEff(battle.pEff, 'freeze')) {
    lines.push('🧊 Você está congelado e perde o turno.');
  } else {
    const intent = chooseSkillIntent(user, battle, wantSkill);
    if (intent) {
      const res = applySkill(user, battle, boss, intent, seed);
      if (res.used) lines.push(res.text);
      else {
        // cai para ataque básico se não conseguiu usar
        const a = playerAttackBase(user, battle, boss, seed);
        battle.bossHp = Math.max(0, battle.bossHp - a.dmg);
        lines.push(`🗡️ Golpe: -${a.dmg}${a.crit ? ' 💥' : ''}`);
      }
    } else {
      const a = playerAttackBase(user, battle, boss, seed);
      battle.bossHp = Math.max(0, battle.bossHp - a.dmg);
      lines.push(`🗡️ Golpe: -${a.dmg}${a.crit ? ' 💥' : ''}`);
    }
  }

  if (battle.bossHp <= 0 || battle.playerHp <= 0) {
    // tick no fim também para não “prender” efeitos
    battle.cds.h1 = Math.max(0, (battle.cds.h1 || 0) - 1);
    battle.cds.h2 = Math.max(0, (battle.cds.h2 || 0) - 1);
    battle.pEff = effTick(battle.pEff);
    battle.bEff = effTick(battle.bEff);
    return lines;
  }

  // Pet attack
  const pet = findEff(battle.pEff, 'pet');
  if (pet) {
    const dmg = Math.max(1, Math.round((pet.petPct || 0.15) * computeBaseStats(user).atk));
    battle.bossHp = Math.max(0, battle.bossHp - dmg);
    lines.push(`🧟 Servo: -${dmg}`);
  }

  // Boss action
  const b = bossAttack(user, battle, boss, seed);
  lines.push(`👹 ${boss.name}: -${b.dmg} HP ${b.text || ''}`.trim());

  // CDs / efeitos tick
  battle.cds.h1 = Math.max(0, (battle.cds.h1 || 0) - 1);
  battle.cds.h2 = Math.max(0, (battle.cds.h2 || 0) - 1);
  battle.pEff = effTick(battle.pEff);
  battle.bEff = effTick(battle.bEff);

  return lines;
}

// =========================
// DROPS / LOOT
// =========================
function rollDrops(user, boss, seed, dropAdd = 0) {
  const lootBonus = computeLootBonus(user);
  const drops = [];
  for (const d of (boss.drops || [])) {
    const chance = clamp(Number(d.chance || 0) + lootBonus + Number(dropAdd || 0), 0, 0.80);
    if (randInt(1, 1000, seed) / 1000 <= chance) {
      drops.push({ itemId: d.itemId, qty: randInt(d.min || 1, d.max || 1, seed) });
    }
  }
  if (user.buffs?.lootBattles > 0 && randInt(1, 100, seed) <= 10) drops.push({ itemId: 'MAT_ESS', qty: 1 });
  return drops;
}

// =========================
// GESTÃO DE CHAT E BOSS GLOBAL
// =========================
function ensureSeason(store) {
  const ms = 30 * 24 * 60 * 60 * 1000;
  const now = Date.now();
  if (!store.season || typeof store.season !== 'object') store.season = {};
  if (!store.season.startedAt) store.season.startedAt = now;
  if (!store.season.id) store.season.id = dateKeyNow();
  const endAt = (store.season.startedAt + ms);
  if (now >= endAt) {
    store.season.startedAt = now;
    store.season.id = dateKeyNow();
    // zera placares simples por temporada
    for (const k of Object.keys(store.users || {})) {
      const u = store.users[k];
      if (!u || typeof u !== 'object') continue;
      if (!u.season || typeof u.season !== 'object') u.season = { id: null, ouro: 0, arena: 0, boss: 0 };
      u.season.id = store.season.id;
      u.season.ouro = 0;
      u.season.arena = 0;
      u.season.boss = 0;
    }
    __scheduleWrite();
  }
  return { id: store.season.id, endsInMs: Math.max(0, endAt - now) };
}

const EVENTOS = [
  { key: 'tempestade', name: '🌩 Tempestade Sombria', bonus: 'Mais ouro e itens', goldMul: 1.18, dropAdd: 0.06, eliteAdd: 0.08 },
  { key: 'dragao', name: '🐉 Dragão Avistado', bonus: 'Elite mais frequente', goldMul: 1.12, dropAdd: 0.08, eliteAdd: 0.14 },
  { key: 'mina', name: '💎 Mina Rara', bonus: 'Mais chance de item raro', goldMul: 1.10, dropAdd: 0.12, eliteAdd: 0.06 },
  { key: 'fenda', name: '👁 Fenda Misteriosa', bonus: 'Tudo um pouco melhor', goldMul: 1.14, dropAdd: 0.09, eliteAdd: 0.10 },
];

function getChatEvent(store, chatId) {
  if (!store.events || typeof store.events !== 'object') store.events = {};
  if (!store.events[chatId]) store.events[chatId] = { key: null, endsAt: 0, startedAt: 0 };
  const e = store.events[chatId];
  const now = Date.now();
  if (e.endsAt && now >= e.endsAt) {
    store.events[chatId] = { key: null, endsAt: 0, startedAt: 0 };
    __scheduleWrite();
    return null;
  }
  if (!e.key) return null;
  return EVENTOS.find(x => x.key === e.key) || null;
}

function maybeStartChatEvent(store, chatId, seedStr) {
  const now = Date.now();
  const cur = getChatEvent(store, chatId);
  if (cur) return null;
  // chance baixa por ação
  const seed = makeStableSeedFromParts('evt', chatId, seedStr, Math.floor(now / 60000));
  const roll = randInt(1, 100, seed);
  if (roll > 4) return null;
  const pick = EVENTOS[randInt(0, EVENTOS.length - 1, seed)];
  store.events[chatId] = { key: pick.key, startedAt: now, endsAt: now + (avtempos.CD.event || (30 * 60 * 1000)) };
  __scheduleWrite();
  return pick;
}

function applyEventBonus(event, gold, xp) {
  if (!event) return { gold, xp, dropAdd: 0, eliteAdd: 0 };
  const g = Math.max(1, Math.round((Number(gold) || 0) * (Number(event.goldMul) || 1)));
  const x = Math.max(1, Math.round((Number(xp) || 0) * 1.05));
  return { gold: g, xp: x, dropAdd: Number(event.dropAdd) || 0, eliteAdd: Number(event.eliteAdd) || 0 };

}

function goldWithPrestigio(user, gold) {
  const pr = Math.max(0, Math.min(10, Number(user?.prestigio) || 0));
  if (pr <= 0) return gold;
  return Math.max(1, Math.round((Number(gold) || 0) * (1 + pr * 0.02)));
}

function rarityMark(name, rarity) {
  const r = String(rarity || '').toLowerCase();
  if (r === 'lendario') return `✨ ${name}`;
  if (r === 'epico') return `💠 ${name}`;
  if (r === 'raro') return `🔹 ${name}`;
  return name;
}

function pushHistorico(user, line) {
  if (!user || !line) return;
  if (!Array.isArray(user.historico)) user.historico = [];
  user.historico.unshift({ at: Date.now(), text: String(line) });
  user.historico = user.historico.slice(0, 5);
}

function isFerido(user) {
  const t = Number(user?.feridoAte) || 0;
  return Date.now() < t;
}

function feridoLeft(user) {
  const t = Number(user?.feridoAte) || 0;
  return Math.max(0, t - Date.now());
}

function getChatState(store, chatId) {
  if (!store.chats[chatId]) store.chats[chatId] = {};
  return store.chats[chatId];
}

function ensureGlobalBoss(store) {
  const today = dateKeyNow();
  if (store.globalBoss.date !== today) {
    const b = pickGlobalBoss(today);
    store.globalBoss = {
      date: today,
      bossId: b.id,
      name: b.name,
      hpMax: Math.round(b.hp * 4),
      hp: Math.round(b.hp * 4),
    };
    __scheduleWrite();
  }
  return store.globalBoss;
}

// =========================
// TRADES (TROCA DIRETA) / LIMPEZA
// =========================
function cleanupExpiredTrades(store) {
  const now = Date.now();
  const limitMs = 10 * 60 * 1000;
  for (const id of Object.keys(store.trades || {})) {
    const t = store.trades[id];
    if (!t) continue;
    if ((now - (t.lastActionAt || t.createdAt || now)) > limitMs) {
      try {
        const uA = ensureUser(store, t.a);
        const uB = ensureUser(store, t.b);
        for (const [itemId, qty] of Object.entries(t.offerA?.items || {})) invAdd(uA, itemId, qty);
        for (const [itemId, qty] of Object.entries(t.offerB?.items || {})) invAdd(uB, itemId, qty);
      } catch (_) {}
      delete store.trades[id];
    }
  }
}

function cleanupMarket(store) {
  if (!store || !Array.isArray(store.market)) return;
  const now = Date.now();
  const maxAgeMs = 7 * 24 * 60 * 60 * 1000; // 7 dias
  // remove expiradas
  store.market = store.market.filter(o => o && (now - (o.createdAt || now)) <= maxAgeMs);
  // limita tamanho (remove as mais antigas)
  const limit = 500;
  if (store.market.length > limit) {
    store.market.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
    store.market = store.market.slice(-limit);
  }
}

function findEmporioItemById(store, itemId) {
  return ITEM[itemId] || null;
}

// =========================
// LOJA (EMPÓRIO)
// =========================
function handleEmporio(msg, store, user, prefix, args) {
  const sub = String(args?.[0] || '').toLowerCase().trim();
  if (!sub) {
    let txt = `🏪 *EMPÓRIO DA GUILDA*
`;
    txt += `Ouro na bolsa: ${fmtGold(user.gold)}

`;
    txt += `📦 Itens disponíveis:
`;
    for (const [, it] of Object.entries(ITEM)) {
      if (!it || !it.price) continue;
      const rar = rarityLabel(it.rarity || 'comum');
      txt += `• ${it.name} — ${fmtGold(it.price)}g (${rar})
`;
    }
    txt += `
Comprar: *${prefix}emporio comprar <nome do item> <qtd>*
`;
    txt += `Ex.: *${prefix}emporio comprar Poção Pequena 2*`;
    return msg.reply(txt);
  }
  if (sub === 'comprar') {
    const input = String(args?.[1] || '').trim();
    const qty = clamp(safeNumFromArgs(args?.[2]), 1, 999999);
    const itemId = findItemIdByInput(input);
    const it = itemId ? findEmporioItemById(store, itemId) : null;
    if (!it) return msg.reply('❌ Artefato desconhecido. Use o nome do item como aparece na lista.');
    const price = Math.max(1, Number(it.price) || 0);
    const total = price * qty;
    if (user.gold < total) return msg.reply(`❌ Ouro insuficiente para esta compra. Precisa de ${fmtGold(total)}g.`);
    user.gold -= total;
    invAdd(user, itemId, qty);
    __scheduleWrite();
    return msg.reply(`✅ Negócio selado: ${qty}x ${it.name} por ${fmtGold(total)}g.`);
  }
  return msg.reply('📜 Guia do Empório: emporio / emporio comprar');
}

// =========================
// LEILÃO GLOBAL (MERCADO)
// =========================
function handleLeilao(msg, store, user, prefix, args) {
  const sub = String(args?.[0] || '').toLowerCase().trim();
  if (!store.market) store.market = [];

  if (!sub) {
    msg.reply(
      `⚖️ *LEILÃO GLOBAL DA GUILDA*\n` +
      `Anuncie espólios para outros aventureiros (mesmo offline).\n\n` +
      `• *${prefix}leilao listar* (ver ofertas)\n` +
      `• *${prefix}leilao vender <itemId> <qtd> <preço>*\n` +
      `• *${prefix}leilao comprar <uid>*\n` +
      `• *${prefix}leilao minhas* (cancelar)\n\n` +
      `Dica: você pode usar o *nome do item* (como aparece na mochila).`
    );
    return;
  }

  if (sub === 'listar') {
    if (store.market.length === 0) return msg.reply('📭 Nenhuma oferta ecoa no Leilão agora.');
    const list = store.market.slice(-15);
    const lines = ['⚖️ *OFERTAS RECENTES NO LEILÃO*'];
    list.forEach(m => {
      lines.push(`🏷️ *${m.uid}* | ${itemName(m.itemId)} x${m.qty} — 💰 ${fmtGold(m.price)}`);
    });
    lines.push(`\nComprar: *${prefix}leilao comprar <uid>*`);
    msg.reply(lines.join('\n'));
    return;
  }

  if (sub === 'vender') {
    const input = String(args?.[1] || '').trim();
    const itemId = findItemIdByInput(input);
    const qty = clamp(safeNumFromArgs(args?.[2]), 1, 999999);
    const price = clamp(safeNumFromArgs(args?.[3]), 1, 1000000000);

    if (!itemId || !ITEM[itemId]) return msg.reply('❌ Eu não reconheci esse item. Use o nome como aparece na mochila.');
    if (ITEM[itemId].trade === false) return msg.reply('🔒 Este item é juramentado e não pode ser negociado.');
    if (invGet(user, itemId) < qty) return msg.reply(`❌ Na sua mochila há apenas ${invGet(user, itemId)}x.`);
    const rar = ITEM[itemId]?.rarity || 'comum';
    const feePct = (rar === 'comum') ? 0.10 : 0.05;
    const fee = Math.ceil(price * feePct);
    if (user.gold < fee) return msg.reply(`❌ O Leilão exige tributo (${Math.round(feePct * 100)}%): ${fmtGold(fee)} ouro.`);

    user.gold -= fee;
    invAdd(user, itemId, -qty);
    const uid = makeMarketUid(store);

    store.market.push({
      uid,
      sellerKey: user.__key,
      itemId,
      qty,
      price,
      createdAt: Date.now()
    });

    __scheduleWrite();
    msg.reply(`✅ Oferta registrada (Selo ${uid})!\nItem: ${itemName(itemId)} x${qty}\nPreço: ${fmtGold(price)}`);
    return;
  }

  if (sub === 'comprar') {
    const uid = String(args?.[1] || '').trim();
    const idx = store.market.findIndex(m => m.uid === uid);
    if (idx === -1) return msg.reply('❌ Oferta não encontrada nos pergaminhos do Leilão.');
    const offer = store.market[idx];
    if (offer.sellerKey === user.__key) return msg.reply('❌ Para desfazer uma oferta sua, use *minhas* e então cancele.');
    if (user.gold < offer.price) return msg.reply(`❌ Ouro insuficiente para este lance. Precisa de ${fmtGold(offer.price)}g.`);

    // paga
    user.gold -= offer.price;
    invAdd(user, offer.itemId, offer.qty);

    // entrega ao vendedor
    const seller = ensureUser(store, offer.sellerKey);
    seller.gold += offer.price;

    store.market.splice(idx, 1);
    __scheduleWrite();
    msg.reply(`✅ Aquisição concluída: ${itemName(offer.itemId)} x${offer.qty} por ${fmtGold(offer.price)}g.`);
    return;
  }

  if (sub === 'minhas') {
    const mine = store.market.filter(m => m.sellerKey === user.__key);
    if (mine.length === 0) return msg.reply('📭 Você não tem ofertas registradas no Leilão.');
    const lines = ['📦 *SUAS OFERTAS NO LEILÃO*'];
    for (const m of mine.slice(-15)) {
      lines.push(`🏷️ *${m.uid}* | ${itemName(m.itemId)} x${m.qty} — 💰 ${fmtGold(m.price)}`);
    }
    lines.push(`\nCancelar: *${prefix}liquidar <uid>*`);
    msg.reply(lines.join('\n'));
    return;
  }

  return msg.reply('Invocação inválida.');
}

function handleAdquirir(msg, store, user, prefix, args) {
  // alias antigo mantido por compatibilidade
  return handleLeilao(msg, store, user, prefix, ['comprar', ...args]);
}

function handleLiquidar(msg, store, user, prefix, args) {
  const uid = String(args?.[0] || '').trim();
  if (!uid) return msg.reply(`Use: *${prefix}liquidar <uid>*`);
  const idx = store.market.findIndex(m => m.uid === uid);
  if (idx === -1) return msg.reply('❌ Oferta não encontrada nos pergaminhos do Leilão.');
  const offer = store.market[idx];
  if (offer.sellerKey !== user.__key) return msg.reply('❌ Esta oferta não pertence ao seu selo.');
  invAdd(user, offer.itemId, offer.qty);
  store.market.splice(idx, 1);
  __scheduleWrite();
  msg.reply(`✅ Oferta desfeita; itens devolvidos à sua mochila.`);
}

// =========================
// PERFIL / INVENTÁRIO
// =========================
function handleAvPerfil(msg, store, user, prefix, displayName) {
  const st = computeBaseStats(user);
  const xpNeed = needXpForLevel(user.lvl);

  const reg = getRegiao(user);

  // Vida atual (se tiver batalha ativa, usa o estado leve)
  const hpNow = user.battleLite ? Number(user.battleLite.hp || 0) : Number(st.hp || 0);
  const hpMax = user.battleLite ? Number(user.battleLite.hpMax || st.hp) : Number(st.hp || 0);

  // Reputação (sem criar sistema novo: usa o que já existe)
  const reputacao = Math.max(0, Number(user.prestigio) || 0);

  // Sequência
  if (!user.hunt) user.hunt = { streak: 0, best: 0 };
  const streak = Number(user.hunt.streak || 0);

  // Boss derrotados (já existe na jornada)
  const bossKills = Number(user.jornada?.boss || 0);

  // Total de itens (soma quantidades do inventário)
  const inv = user.inv || {};
  let itensTotal = 0;
  for (const q of Object.values(inv)) itensTotal += Math.max(0, Number(q) || 0);

  const name = (displayName && String(displayName).trim()) ? String(displayName).trim() : getDisplayName(null, msg);
  const e = ensureEnergia(user);

  // Identidade curta (baseado em nível)
  let identidade = '';
  if (user.lvl <= 2) identidade = 'Explorador iniciante';
  else if (user.lvl <= 5) identidade = 'Caçador em progresso';
  else if (user.lvl <= 8) identidade = `Veterano de ${reg.name}`;
  else identidade = 'Lenda do mundo';

  // Estado discreto (sem tempo)
  let estado = '';
  const injMs = avtempos.leftMs(user, 'injury');
  if (injMs > 0) estado = '💢 Estado: Ferido';
  else if (streak >= 6) estado = '🌟 Estado: Em ascensão';
  else if (e.cur >= e.max) estado = '✨ Estado: Motivado';

  const lines = [];
  lines.push(`🎟️ *AVENTURA — ${name}*`);
  if (user.titulo && String(user.titulo).trim()) lines.push(`🏅 Título: ${String(user.titulo).trim()}`);
  if (estado) lines.push(estado);
  if (identidade) lines.push(identidade);
  lines.push('');
  lines.push(`🧬 Nível: ${user.lvl}`);
  lines.push(`⭐ XP: ${fmtGold(user.xp)} / ${fmtGold(xpNeed)}`);
  lines.push(`❤️ Vida: ${hpNow} / ${hpMax}`);

  // Energia (humana, sem regra interna)
  const energiaNota = (e.cur <= 2) ? '(Cansado)' : (e.cur >= e.max ? '(Pronto para agir)' : '');
  lines.push(`⚡ Energia: ${e.cur}/${e.max}${energiaNota ? `\n${energiaNota}` : ''}`);

  lines.push('');
  lines.push(`📍 Região: ${reg.name}`);
  lines.push(`🏆 Reputação: ${reputacao}`);
  const fama = Math.max(0, Number(user.fama) || 0);
  if (fama > 0) lines.push(`✨ Fama: ${fama}`);
  lines.push('');
  lines.push(`🔥 Sequência: ${streak}`);
  lines.push(`🐉 Boss derrotados: ${bossKills}`);
  lines.push('');
  lines.push(`💰 Ouro: ${fmtGold(user.gold)}`);
  const rel = getRelicAtiva(user);
  if (rel) lines.push(`💎 Relíquia ativa: ${itemName(rel.id)}`);
  lines.push('');
  // 🎒 Equipamento (sem comando novo)
  const eq = user.dark?.equip || {};
  const w = eq.weapon ? itemName(eq.weapon) : 'Nenhuma';
  const a = eq.armor ? itemName(eq.armor) : 'Nenhuma';
  const ac = eq.acc ? itemName(eq.acc) : 'Nenhum';

  lines.push(`🎒 Equipamento`);
  lines.push(`• Arma: ${w}`);
  lines.push(`• Armadura: ${a}`);
  lines.push(`• Acessório: ${ac}`);
  lines.push(`Gerenciar: *${prefix}avinv*`);
  lines.push('');

  lines.push(`🎒 Itens: ${itensTotal}`);

  return msg.reply(lines.join('\n'));
}
function handleMochila(msg, store, user, prefix) {
  const entries = Object.entries(user.inv || {});
  if (entries.length === 0) return msg.reply('🎒 Sua mochila está vazia.');

  // ordena por categoria e raridade para ficar “bonito”
  const orderCat = { 'Poção': 1, 'Material': 2, 'Relíquia': 3, 'Arma': 4, 'Armadura': 5, 'Acessório': 6, 'Artefato': 7 };
  const orderRar = { 'comum': 1, 'raro': 2, 'epico': 3, 'mitico': 4 };

  const rows = entries
    .map(([id, qty]) => {
      const it = ITEM[id] || {};
      const cat = itemCategory(id);
      const rarKey = String(it.rarity || 'comum').toLowerCase();
      return { id, qty: Number(qty) || 0, name: itemName(id), cat, rarKey, rarTxt: rarityLabel(rarKey) };
    })
    .filter(r => r.qty > 0)
    .sort((a, b) => (orderCat[a.cat] || 99) - (orderCat[b.cat] || 99) || (orderRar[a.rarKey] || 99) - (orderRar[b.rarKey] || 99) || a.name.localeCompare(b.name));

  const lines = ['🎒 *MOCHILA DO AVENTUREIRO*', ''];
  let lastCat = null;
  for (const r of rows) {
    if (r.cat !== lastCat) {
      lastCat = r.cat;
      lines.push(`📁 *${r.cat}*`);
    }
    lines.push(`• ${r.name} x${r.qty} (${r.rarTxt})`);
  }

  lines.push('');
  lines.push(`Atalhos:`);
  lines.push(`• Usar poção: *${prefix}avusar Poção Pequena*`);
  lines.push(`• Forjar: *${prefix}craft*`);
  lines.push(`• Vender rápido: *${prefix}avvender <nome> <qtd>*`);
  lines.push(`• Leilão: *${prefix}leilao*`);

  return msg.reply(lines.join('\n'));
}

// =========================
// CLASSES (comando)
// =========================
async function handleClasse(msg, store, user, prefix, args) {
  const sub = String(args?.[0] || '').toLowerCase().trim();

  // ===== NOCTHARIA (DARK) =====
  if (sub === 'dark') {
    const cur = user.dark?.classe ? (darkClassByKey(user.dark.classe)?.name || user.dark.classe) : 'Nenhuma';
    const out = [];
    out.push(`🌑 *CLASSES — NOCTHARIA*`);
    out.push(`Atual: *${cur}*`);
    out.push('');
    DARK_CLASSES.forEach((c, i) => out.push(`${i + 1}) ${c.name}`));
    out.push('');
    out.push(`➡️ *${prefix}classe escolher <n> dark*`);
    return msg.reply(lines2.join('\n'));
  }

  if (sub === 'escolher' && String(args?.[2] || '').toLowerCase().trim() === 'dark') {
    if (user.dark?.classe) return msg.reply(`Você já firmou um pacto em Noctharia. Use *${prefix}classe trocar <n> dark*.`);
    const cls = darkClassByIndex(args?.[1]);
    if (!cls) return msg.reply(`Classe dark inválida. Use *${prefix}classe dark* e escolha pelo número.`);
    user.dark.classe = cls.key;
    __scheduleWrite();
    return msg.reply(`✅ Pacto firmado: *${cls.name}* (Noctharia)`);
  }

  if (sub === 'trocar' && String(args?.[2] || '').toLowerCase().trim() === 'dark') {
    const cls = darkClassByIndex(args?.[1]);
    if (!cls) return msg.reply(`Classe dark inválida. Use *${prefix}classe dark* e escolha pelo número.`);
    const cost = 2000;
    if (user.dark?.classe) {
      if (user.gold < cost) return msg.reply(`❌ Você precisa de ${fmtGold(cost)}g para mudar o pacto sombrio.`);
      user.gold -= cost;
    }
    user.dark.classe = cls.key;
    __scheduleWrite();
    return msg.reply(`✅ Pacto alterado: *${cls.name}* (Noctharia) (-${fmtGold(cost)}g)`);
  }
  
  // ===== FIM DARK =====


  if (!sub) {
    const cls = classByKey(user.classe);
    const cur = cls ? `*${cls.name}*` : '*Nenhuma*';
    let txt = `🎭 *CLASSES DA GUILDA*
Atual: ${cur}

Classes:
`;
    for (const c of CLASSES) txt += `• ${c.name} (${c.passive})
`;
    txt += `
Use *${prefix}classe escolher <nome>* (Grátis)
Ou *${prefix}classe trocar <nome>* (2.000g)`;
    return msg.reply(txt);
  }
  if (sub === 'ver') {
    const cls = classByKey(args?.[1]);
    if (!cls) return msg.reply('Classe desconhecida.');
    return msg.reply(`🎭 *${cls.name}*
Passiva: ${cls.passive}
H1: ${cls.h1.name}
H2: ${cls.h2.name}`);
  }
  if (sub === 'escolher') {
    if (user.classe) return msg.reply(`Você já jurou uma Classe. Use *${prefix}classe trocar <nome>*.`);
    const cls = classByKey(args?.[1]);
    if (!cls) return msg.reply('Classe desconhecida.');
    user.classe = cls.key;
    __scheduleWrite();
    return msg.reply(`✅ Juramento firmado: *${cls.name}*`);
  }
  if (sub === 'trocar') {
    const cls = classByKey(args?.[1]);
    if (!cls) return msg.reply('Classe desconhecida.');
    if (!user.classe) {
      user.classe = cls.key;
      __scheduleWrite();
      return msg.reply(`✅ Juramento firmado: *${cls.name}*`);
    }
    const cost = 2000;
    if (user.gold < cost) return msg.reply(`❌ Você precisa de ${fmtGold(cost)}g para mudar de caminho.`);
    user.gold -= cost;
    user.classe = cls.key;
    __scheduleWrite();
    return msg.reply(`✅ Caminho alterado: *${cls.name}* (-${fmtGold(cost)}g)`);
  }
  return msg.reply('Invocação inválida.');
}

// =========================
// CRAFT
// =========================

const RECIPES = [
  {
    name: 'Poção Pequena',
    makes: { itemId: 'POT_PEQ', qty: 1 },
    req: { 'MAT_ERVA': 2 },
    tier: 'Básicas',
    note: 'Boa para começar a caçar com segurança.'
  },
  {
    name: 'Poção Média',
    makes: { itemId: 'POT_MED', qty: 1 },
    req: { 'MAT_ERVA': 3, 'MAT_ESS': 1 },
    tier: 'Básicas',
    note: 'Equilíbrio perfeito para caçadas longas.'
  },
  {
    name: 'Poção Grande',
    makes: { itemId: 'POT_GRA', qty: 1 },
    req: { 'MAT_ERVA': 6, 'MAT_ESS': 2 },
    tier: 'Intermediárias',
    note: 'Para quando a coisa ficar séria.'
  },
  {
    name: 'Poção da Sorte',
    makes: { itemId: 'POT_SORTE', qty: 1 },
    req: { 'MAT_ESS_INST': 1, 'MAT_FRAGMENTO': 1, 'MAT_ERVA': 2 },
    tier: 'Intermediárias',
    note: 'Aumenta suas chances em caçadas importantes.'
  },
  {
    name: 'Lâmina Bruta',
    makes: { itemId: 'ARMA_LAMINA_BRUTA', qty: 1 },
    req: { 'MAT_FERRO': 6, 'MAT_COURO': 2 },
    tier: 'Básicas',
    note: 'Uma arma simples, mas confiável.'
  },
  {
    name: 'Armadura de Couro Leve',
    makes: { itemId: 'ARM_COURO_LEVE', qty: 1 },
    req: { 'MAT_COURO_RES': 2, 'MAT_COURO': 3 },
    tier: 'Intermediárias',
    note: 'Protege sem atrapalhar seus passos.'
  },
  {
    name: 'Talismã Antigo',
    makes: { itemId: 'ACC_TALISMA_ANTIGO', qty: 1 },
    req: { 'MAT_RELIQ': 1, 'MAT_CRISTAL': 1, 'MAT_ESS': 2 },
    tier: 'De Elite',
    note: 'Um artefato raro, desejado por toda guilda.'
  }
];

function recipeByName(input) {
  const q = normTxt(input);
  if (!q) return null;
  for (const r of (RECIPES || [])) {
    if (normTxt(r.name) === q) return r;
  }
  for (const r of (RECIPES || [])) {
    if (normTxt(r.name).includes(q)) return r;
  }
  return null;
}

function recipeProgressText(user, req) {
  const parts = [];
  for (const [id, q] of Object.entries(req || {})) {
    const have = invGet(user, id);
    parts.push(`${itemName(id)} ${have}/${q}`);
  }
  return parts.join(' • ');
}

function handleCraft(msg, store, user, prefix, args) {
  const sub = String(args?.[0] || '').toLowerCase().trim();

  // ===== NOCTHARIA (DARK) =====
  if (sub === 'dark') {
    const action = String(args?.[1] || '').toLowerCase().trim();
    if (!action) {
      const out = ['🛠️ *CRAFT — NOCTHARIA*', ''];
      for (const r of DARK_RECIPES) {
        const reqTxt = Object.entries(r.req).map(([id, q]) => `${itemName(id)} x${q}`).join(' + ');
        out.push(`${r.id}) ${r.name} (${reqTxt})`);
      }
      out.push('');
      out.push(`➡️ *${prefix}craft dark fazer <id>*`);
      out.push(`➡️ *${prefix}craft dark fragmentar <id>*`);
	      return msg.reply(out.join('\n'));

    }

    if (action === 'fazer') {
      const rid = args?.[2];
      const r = darkRecipeById(rid);
      if (!r) return msg.reply(`❌ Receita dark inválida. Use *${prefix}craft dark*.`);
      for (const [id, q] of Object.entries(r.req || {})) {
        if (!darkInvHas(user, id, q)) return msg.reply('❌ Materiais insuficientes para concluir o craft dark.');
      }
      for (const [id, q] of Object.entries(r.req || {})) darkInvAdd(user, id, -q);
      darkInvAdd(user, r.itemId, 1);
      __scheduleWrite();
      return msg.reply(`✅ Craft concluído: 1x ${itemName(r.itemId)} (Noctharia)`);
    }

    if (action === 'fragmentar') {
      const rid = args?.[2];
      const r = darkRecipeById(rid);
      if (!r) return msg.reply(`❌ Receita dark inválida. Use *${prefix}craft dark*.`);
      if (!darkInvHas(user, r.itemId, 1)) return msg.reply(`❌ Você não tem ${itemName(r.itemId)} para fragmentar.`);
      darkInvAdd(user, r.itemId, -1);
      for (const [id, q] of Object.entries(r.req || {})) darkInvAdd(user, id, q);
      __scheduleWrite();
      return msg.reply(`🧩 Fragmentação concluída: ${itemName(r.itemId)} → materiais devolvidos.`);
    }

    return msg.reply(`Invocação inválida. Use *${prefix}craft dark*.`);
  }
  // ===== FIM DARK =====


  if (!sub) {
    const lines = [];
    lines.push('🛠️ *FORJA E ALQUIMIA*');
    lines.push('');
    lines.push('Aqui você transforma espólios em poder.');
    lines.push('Dica: quanto mais você caça, mais materiais aparecem.');
    lines.push('');
    const byTier = {};
    for (const r of (RECIPES || [])) {
      const t = r.tier || 'Outras';
      if (!byTier[t]) byTier[t] = [];
      byTier[t].push(r);
    }
    const tiers = ['Básicas', 'Intermediárias', 'De Elite', 'Outras'];
    for (const t of tiers) {
      const list = byTier[t];
      if (!list || !list.length) continue;
      lines.push(`📜 *${t}*`);
      for (const r of list) {
        const prog = recipeProgressText(user, r.req);
        lines.push(`• ${r.name} → ${itemName(r.makes.itemId)} (${prog})`);
      }
      lines.push('');
    }
    lines.push(`Forjar: *${prefix}craft fazer <nome da receita>*`);
    lines.push(`Ex.: *${prefix}craft fazer Poção Média*`);
    lines.push('');
    lines.push(nextObjectiveHint(prefix, user));
    return msg.reply(lines.join('\n'));
  }

  if (sub === 'fazer') {
    const input = String(args?.slice(1).join(' ') || '').trim();
    const r = recipeByName(input);
    if (!r) return msg.reply('❌ Receita desconhecida. Use *craft* para ver o grimório.');

    // checa materiais e mostra progresso claro
    const missing = [];
    for (const [id, q] of Object.entries(r.req || {})) {
      const have = invGet(user, id);
      if (have < q) missing.push(`${itemName(id)} ${have}/${q}`);
    }
    if (missing.length) {
      return msg.reply(
        `❌ Materiais insuficientes para forjar *${r.name}*.
` +
        `Você precisa completar:
• ${missing.join('\\n• ')}

` +
        `Dica: use *${prefix}avcacar* e *${prefix}avexp* para juntar materiais.`
      );
    }

    for (const [id, q] of Object.entries(r.req || {})) invAdd(user, id, -q);
    invAdd(user, r.makes.itemId, r.makes.qty || 1);

    __scheduleWrite();

    const cel = lootCelebration(r.makes.itemId);
    return msg.reply(
      `✅ Forja concluída: *${r.name}*.
` +
      `🎒 Você recebeu: ${itemName(r.makes.itemId)} x${r.makes.qty || 1}.
` +
      (cel ? `
${cel}
` : '\n') +
      `➡️ Próximo passo: *${prefix}avcacar* (treino e espólio) ou *${prefix}boss* quando estiver pronto.`
    );
  }

  return msg.reply('Invocação inválida.');
}

// =========================
// BOSS MENU (seleciona modo por chat)
// =========================
function handleBoss(msg, store, user, prefix, args, chatId, displayName) {
  const chatState = getChatState(store, chatId);
  const sub = String(args?.[0] || '').toLowerCase().trim();

  // ===== NOCTHARIA (DARK) =====
  if (sub === 'dark') {
    const gb = ensureDarkGlobalBoss(store);
    const pct = gb.hpMax ? Math.round((gb.hp / gb.hpMax) * 100) : 0;
    const lines2 = [];
    lines2.push(`👹 *BOSS — NOCTHARIA*`);
    lines2.push('');
    lines2.push(`☠️ ${gb.name}`);
    lines2.push(`HP Global: ${pct}%`);
    lines2.push('');
    lines2.push('Drops:');
    lines2.push(`• ${itemName('MAT_FRAG_DIVINO')}`);
    lines2.push(`• ${itemName('ARMA_ESPADA_ABISSAL')}`);
    lines2.push('');
    lines2.push(`➡️ *${prefix}matarboss dark*`);
    return msg.reply(out.join('\n'));
  }
  // ===== FIM DARK =====

  if (!sub) {
    const mode = chatState.mode || 'dia';
    const gb = ensureGlobalBoss(store);
    let txt = `👹 *CAÇADA AO BOSS*
`;
    txt += `Estratégia do grupo: *${mode}*

`;
    txt += `• *${prefix}boss dia* (Alvo do dia)
`;
    txt += `• *${prefix}boss global* (Colosso global do dia)
`;
    txt += `
Atacar: *${prefix}matarboss* (continua a luta)
`;
    txt += `
Global: ${gb.name} — HP: ${fmtGold(gb.hp)}/${fmtGold(gb.hpMax)}
`;
    return msg.reply(txt);
  }
  if (sub === 'dia' || sub === 'global') {
    chatState.mode = sub;
    __scheduleWrite();
    return msg.reply(`✅ Alvo definido para o grupo: *${sub}*`);
  }
  return msg.reply('Invocação inválida.');
}

// =========================
// MATAR BOSS (turn-based)
// =========================

function handleMatarBossDark(msg, store, user, prefix, args, chatId) {
  const now = Date.now();
  if (!user.dark) ensureUser(store, user.__key);

  // Gate de nível (Boss não é conteúdo inicial)
  const pLvl = Math.max(1, Number(user.dark?.stats?.lvl) || 1);
  if (pLvl < 3) {
    return msg.reply(`🔒 O Leviatã não é conteúdo inicial.\n➡️ Upe primeiro em *${prefix}avexp* até Lv.3 para poder atacar o Boss Dark.`);
  }

  if (now - (user.dark.lastAttackAt || 0) < 8000) {
    return msg.reply(`⏳ Recuperando fôlego: ${Math.ceil((8000-(now-(user.dark.lastAttackAt||0)))/1000)}s`);
  }

  const seed = { v: 0xdeadbeef ^ now };
  const gb = ensureDarkGlobalBoss(store);
  if (gb.hp <= 0) return msg.reply('O Boss de Noctharia já tombou hoje.');

  const boss = { ...DARK_GLOBAL_BOSS, hp: gb.hp, hpMax: gb.hpMax };
  const battle = ensureDarkBattle(user, boss);

  // sincroniza HP global
  battle.bossHp = gb.hp;
  battle.bossHpMax = gb.hpMax;

  // turno simples: ataque básico (ou skill "sombra" futuramente)
  battle.turn++;

  // player atk
  const st = computeDarkBaseStats(user);
  let dmg = Math.max(1, Math.round(st.atk * randInt(85, 115, seed) / 100));
  battle.bossHp = Math.max(0, battle.bossHp - dmg);

  // boss atk
  let bdmg = 0;
  if (battle.bossHp > 0) {
    bdmg = Math.max(1, Math.round(DARK_GLOBAL_BOSS.atk * 0.90));
    battle.playerHp = Math.max(0, battle.playerHp - bdmg);
  }

  // aplica HP global
  gb.hp = battle.bossHp;
  user.dark.lastAttackAt = now;

  const pct = gb.hpMax ? Math.round((gb.hp / gb.hpMax) * 100) : 0;
  const lines = [];
  lines.push(`🗡️ Golpe: -${dmg}`);
  if (bdmg > 0) lines.push(`👹 ${gb.name}: -${bdmg} HP`);
  lines.push('');
  lines.push(`❤️ Você: ${battle.playerHp}/${battle.playerHpMax}`);
  lines.push(`☠️ ${gb.name}: ${pct}%`);

  if (battle.playerHp <= 0) {
    user.dark.battle = null;
    __scheduleWrite();
    return msg.reply(`⚔️ *NOCTHARIA*\n${lines.join('\n')}\n\n💀 Você tombou no Mundo Sombrio.`);
  }

  if (gb.hp <= 0) {
    gb.hp = 0;
    user.dark.battle = null;

    // recompensa / drops
    const drops = darkRollDrops(user, DARK_GLOBAL_BOSS, seed);
    if (drops.length) {
      lines.push('');
      lines.push('🎁 *Drops:*');
      drops.forEach(d => lines.push(`• ${itemName(d.itemId)} x${d.qty}`));
      drops.forEach(d => darkInvAdd(user, d.itemId, d.qty));
    }

    // XP dark
    user.dark.stats = user.dark.stats || { lvl: 1, xp: 0 };
    user.dark.stats.xp += 40;
    if (user.dark.stats.xp >= 120) {
      user.dark.stats.xp -= 120;
      user.dark.stats.lvl += 1;
      lines.push(`⬆️ Noctharia: nível ${user.dark.stats.lvl}`);
    }

    __scheduleWrite();
    return msg.reply(`⚔️ *NOCTHARIA*\n${lines.join('\n')}\n\n🏆 O Leviatã caiu.`);
  }

  __scheduleWrite();
  return msg.reply(`⚔️ *NOCTHARIA*\n${lines.join('\n')}\n\n➡️ *${prefix}matarboss dark*`);
}

function handleMatarBoss(msg, store, user, prefix, args, chatId, displayName) {
  const first = String(args?.[0] || '').toLowerCase().trim();
  if (first === 'dark') return handleMatarBossDark(msg, store, user, prefix, args, chatId);

  // Gate de progressão: Boss é conteúdo final (Lv.6+)
  const pLvl = Math.max(1, Number(user.lvl) || 1);
  if (pLvl < 6) {
    return msg.reply(`🔒 ${displayName}, você ainda não está pronto para o Boss.
➡️ Upe em *${prefix}cacar* até Nv.6.`);
  }

  const now = Date.now();
  if (now - (user.lastAttackAt || 0) < 8000) return msg.reply(`⏳ Recuperando fôlego: ${Math.ceil((8000-(now-(user.lastAttackAt||0)))/1000)}s`);

  const chatState = getChatState(store, chatId);
  const mode = chatState.mode || 'dia';
  const seed = { v: 0xdeadbeef ^ now };

  let boss, hpRef;
  if (mode === 'global') {
    const gb = ensureGlobalBoss(store);
    if (gb.hp <= 0) return msg.reply('O Boss global já tombou hoje.');
    boss = bossById(gb.bossId);
    hpRef = gb;
  } else if (mode === 'raid') {
    if (!chatState.raid?.active) return msg.reply('Nenhuma Expedição (Raid) está ativa.');
    if (!chatState.raid.members.includes(user.__key)) return msg.reply(`${displayName}, você não está nesta Expedição.`);
    boss = bossById(chatState.raid.bossId);
    hpRef = chatState.raid;
  } else {
    boss = pickBossOfDay(dateKeyNow());
    const dk = dateKeyNow();
    if (user.daily?.[`bossdia_done_${dk}`] && !user.battle) return msg.reply(`${displayName}, você já enfrentou o Boss do dia.`);
  }

  const battle = ensureBattle(user, boss);
  // sincroniza HP global/raid
  if (hpRef) {
    battle.bossHp = hpRef.hp;
    battle.bossHpMax = hpRef.hpMax;
  }

  const want = String(args?.[0] || '').toLowerCase().trim();
  const lines = applyTurn(user, boss, battle, want, seed);

  // atualiza referências de HP
  if (hpRef) {
    hpRef.hp = battle.bossHp;
    if (hpRef.hp <= 0) hpRef.hp = 0;
  }

  user.lastAttackAt = now;

  // finalizações
  if (battle.playerHp <= 0) {
    if (mode === 'dia') user.daily[`bossdia_done_${dateKeyNow()}`] = true;
    user.battle = null;
    lines.push('💀 Você tombou em batalha.');
    __scheduleWrite();
    return msg.reply(`⚔️ *CONFRONTO*\n${lines.join('\n')}`);
  }

  if (battle.bossHp <= 0) {
    // rewards
    const baseGold = (mode === 'global') ? 120 : 200;
    const gold = Math.max(10, baseGold);
    user.gold += gold;
    user.xp += Math.max(15, Math.round(30 + user.lvl * 2));
    const ups = maybeLevelUp(user);
    pushHistorico(user, `Vitória na caça: ${enc.name}`);
    if (user.season && typeof user.season === 'object') user.season.ouro = (Number(user.season.ouro)||0) + gFinal;
    lines.push(`🏆 Missão concluída! +${fmtGold(gold)}g`);
    if (ups > 0) lines.push(`⬆️ Subiu ${ups} nível(is)! Agora: ${user.lvl}`);

    const drops = rollDrops(user, boss, seed);
    if (drops.length) {
      lines.push(`\n🎁 *Drops:*`);
      drops.forEach(d => lines.push(`• ${itemName(d.itemId)} x${d.qty}`));
      drops.forEach(d => invAdd(user, d.itemId, d.qty));
    }

    if (mode === 'dia') {
      user.daily[`bossdia_done_${dateKeyNow()}`] = true;
      user.battle = null;
    }
    if (mode === 'global') {
      // global só morre uma vez
      const gb = ensureGlobalBoss(store);
      gb.hp = 0;
      user.battle = null;
    }
    __scheduleWrite();
    return msg.reply(`⚔️ *CONFRONTO*\n${lines.join('\n')}`);
  }

  __scheduleWrite();
  return msg.reply(
    `⚔️ *CONFRONTO*\n` +
    `${lines.join('\n')}\n\n` +
    `❤️ Você: ${battle.playerHp}/${battle.playerHpMax}\n` +
    `👹 ${boss.name}: ${battle.bossHp}/${battle.bossHpMax}\n` +
    `CD H1: ${battle.cds.h1} | CD H2: ${battle.cds.h2}\n` +
    `Use: *${prefix}matarboss h1* ou *${prefix}matarboss h2*`
  );
}

// =========================
// ARENA PVP (simplificada)
// =========================
async function handleArena(client, msg, store, user, prefix, args, audit, ctx, extra) {
  const sub = String(args?.[0] || '').toLowerCase().trim();
  if (!sub) {
    let txt = `🏟️ *ARENA* (Elo: ${fmtGold(user.arena?.points || 1000)})\n`;
    txt += `• *${prefix}arena lutar* (buscar duelo)\n`;
    txt += `• *${prefix}arena info* (registros)\n`;
    return msg.reply(txt);
  }
  if (sub === 'info') {
    const a = user.arena || { wins: 0, losses: 0, points: 1000 };
    return msg.reply(`🏟️ *ARENA — REGISTROS*\nVitórias: ${a.wins}\nDerrotas: ${a.losses}\nElo: ${fmtGold(a.points)}`);
  }
  if (sub === 'lutar') {
    const now = Date.now();
    if (now - (user.arena?.lastMatch || 0) < 60000) return msg.reply('⏳ O árbitro exige 60s antes do próximo duelo.');
    user.arena.lastMatch = now;

    // matchmaking simples: escolhe um usuário aleatório do store
    const keys = Object.keys(store.users || {}).filter(k => k !== user.__key);
    if (keys.length === 0) return msg.reply('📭 Nenhum rival foi registrado ainda.');
    const seed = { v: 0xdeadbeef ^ now };
    const enemyKey = keys[randInt(0, keys.length - 1, seed)];
    const enemy = ensureUser(store, enemyKey);

    // simula resultado
    const pPower = user.lvl * 10 + user.gold * 0.01;
    const ePower = enemy.lvl * 10 + enemy.gold * 0.01;
    const roll = randInt(1, 1000, seed) / 1000;
    const winChance = clamp(0.50 + (pPower - ePower) * 0.001, 0.15, 0.85);
    const win = roll <= winChance;

    const reward = 50;
    if (win) {
      user.arena.wins = (user.arena.wins || 0) + 1;
      user.arena.points = (user.arena.points || 1000) + 18;
      user.gold += reward;
      msg.reply(`🏟️ *ARENA*\nVocê enfrentou ${enemyKey} e venceu!\n+${fmtGold(reward)}g | Elo +18`);
    } else {
      user.arena.losses = (user.arena.losses || 0) + 1;
      user.arena.points = Math.max(0, (user.arena.points || 1000) - 12);
      msg.reply(`🏟️ *ARENA*\nVocê enfrentou ${enemyKey} e perdeu.\nElo -12`);
    }
    __scheduleWrite();
    return;
  }
  return msg.reply('Invocação inválida.');
}


// =========================
// CAÇA (PROGRESSÃO ATÉ O BOSS)
// =========================
//
// O loop foi pensado para o jogador:
// • Começa em criaturas simples (Lv.1–2)
// • Avança para ameaças comuns (Lv.3–4)
// • Entra em Elite (Lv.5–6)
// • Só então enfrenta o Boss (Lv.6+)
//
// Comandos:
// • !cacar — encontra um alvo compatível com seu nível
// • !atacar — continua o combate (turno a turno)
// • !fugir — abandona a caça atual
// • !usar <poção> — usa Poção Pequena/Média/Grande (fora ou durante a caça)

function tierByLevel(lvl) {
  const L = Math.max(1, Number(lvl) || 1);
  if (L <= 2) return 1; // Fase 1 — Caça
  if (L <= 4) return 2; // Fase 2 — Comuns
  if (L <= 9) return 3; // Fase 3 — Elite
  return 4;             // Fase 4 — Lendas (Lv 10+)
}


const HUNT_ENEMIES = {
  1: [
    {
      id: 'veado_selvagem',
      name: 'Veado Selvagem',
      desc: 'Um animal ágil que vive nas trilhas. Perfeito para o início.',
      hp: [55, 80], atk: [6, 9],
      gold: [12, 22], xp: [18, 28],
      drops: [
        { itemId: 'MAT_COURO', chance: 0.75, min: 1, max: 2 },
        { itemId: 'MAT_ERVA', chance: 0.35, min: 1, max: 2 },
      ]
    },
    {
      id: 'lobo_faminto',
      name: 'Lobo Faminto',
      desc: 'Ele ronda em silêncio. Fere rápido e recua.',
      hp: [70, 95], atk: [8, 12],
      gold: [16, 30], xp: [22, 34],
      drops: [
        { itemId: 'MAT_COURO', chance: 0.80, min: 1, max: 3 },
        { itemId: 'MAT_PRESA', chance: 0.55, min: 1, max: 2 },
      ]
    },
    {
      id: 'javali_sombrio',
      name: 'Javali Sombrio',
      desc: 'Casco duro e investida bruta. Um teste justo.',
      hp: [85, 115], atk: [9, 13],
      gold: [18, 34], xp: [24, 38],
      drops: [
        { itemId: 'MAT_COURO_RES', chance: 0.65, min: 1, max: 2 },
        { itemId: 'MAT_ERVA', chance: 0.55, min: 1, max: 3 },
      ]
    },
  ],
  2: [
    {
      id: 'goblin_errante',
      name: 'Goblin Errante',
      desc: 'Carrega minério e moedas saqueadas de viajantes.',
      hp: [120, 160], atk: [12, 16],
      gold: [35, 70], xp: [40, 60],
      drops: [
        { itemId: 'MAT_FERRO', chance: 0.80, min: 1, max: 4 },
        { itemId: 'MAT_ESS', chance: 0.25, min: 1, max: 1 },
      ]
    },
    {
      id: 'esqueleto_guerreiro',
      name: 'Esqueleto Guerreiro',
      desc: 'Ossos antigos guiados por um eco de batalha.',
      hp: [135, 180], atk: [13, 18],
      gold: [40, 80], xp: [45, 65],
      drops: [
        { itemId: 'MAT_FRAGMENTO', chance: 0.55, min: 1, max: 2 },
        { itemId: 'MAT_FERRO', chance: 0.45, min: 1, max: 3 },
      ]
    },
    {
      id: 'slime_corrompido',
      name: 'Slime Corrompido',
      desc: 'Uma gosma instável. Parece fraca… até se mover.',
      hp: [110, 165], atk: [12, 17],
      gold: [38, 75], xp: [42, 62],
      drops: [
        { itemId: 'MAT_ESS_INST', chance: 0.45, min: 1, max: 1 },
        { itemId: 'MAT_ERVA', chance: 0.40, min: 1, max: 3 },
      ]
    },
  ],
  3: [
    {
      id: 'cavaleiro_corrompido',
      name: 'Cavaleiro Corrompido',
      desc: 'A armadura ainda luta… mas o coração já foi tomado.',
      hp: [210, 280], atk: [18, 24],
      gold: [90, 160], xp: [85, 120],
      drops: [
        { itemId: 'MAT_RELIQ', chance: 0.50, min: 1, max: 1 },
        { itemId: 'MAT_CRISTAL', chance: 0.22, min: 1, max: 1 },
      ]
    },
    {
      id: 'ogro_brutal',
      name: 'Ogro Brutal',
      desc: 'Um colosso de músculos. Se errar, paga caro.',
      hp: [240, 320], atk: [20, 26],
      gold: [110, 190], xp: [90, 130],
      drops: [
        { itemId: 'DROP_ESCAMA_RARA', chance: 0.22, min: 1, max: 1 },
        { itemId: 'MAT_COURO_RES', chance: 0.55, min: 1, max: 2 },
      ]
    },
    {
      id: 'assassino_sombrio',
      name: 'Assassino Sombrio',
      desc: 'Você só o vê quando já é tarde. Risco alto, chance alta.',
      hp: [190, 270], atk: [22, 30],
      gold: [120, 220], xp: [95, 140],
      drops: [
        { itemId: 'MAT_CRISTAL', chance: 0.25, min: 1, max: 1 },
        { itemId: 'DROP_ANEL', chance: 0.08, min: 1, max: 1 },
      ]
    },
  ],
  4: [
    {
      id: 'guardiao_de_lava',
      name: 'Guardião de Lava',
      desc: 'Uma criatura feita de rocha incandescente. Cada golpe queima.',
      hp: [220, 300], atk: [26, 34],
      gold: [90, 140], xp: [95, 140],
      drops: [
        { itemId: 'MAT_NUCLEO', chance: 0.30, min: 1, max: 1 },
        { itemId: 'MAT_ESS', chance: 0.20, min: 1, max: 2 },
      ]
    },
    {
      id: 'draco_das_cinzas',
      name: 'Draco das Cinzas',
      desc: 'As asas levantam poeira quente. Ele ataca sem aviso.',
      hp: [240, 330], atk: [28, 38],
      gold: [105, 160], xp: [110, 160],
      drops: [
        { itemId: 'MAT_PRESA', chance: 0.55, min: 1, max: 2 },
        { itemId: 'MAT_NUCLEO', chance: 0.18, min: 1, max: 1 },
      ]
    },
    {
      id: 'cavaleiro_corrompido',
      name: 'Cavaleiro Corrompido',
      desc: 'Uma armadura vazia que ainda luta por vontade própria.',
      hp: [260, 360], atk: [30, 42],
      gold: [120, 190], xp: [125, 175],
      drops: [
        { itemId: 'MAT_FERRO', chance: 0.80, min: 1, max: 3 },
        { itemId: 'MAT_ESS', chance: 0.25, min: 1, max: 1 },
      ]
    },
  ],
};

function getRegiao(user) {
  // SSOT: catálogo em aventuraRegioes
  return regioes.getBiome(user);
}

function tierByRegiao(user) {
  const reg = getRegiao(user);
  const t = tierByLevel(user.lvl);
  if (reg.tiers.includes(t)) return t;
  // ajusta para o tier mais próximo permitido
  const all = reg.tiers.slice().sort((a,b)=>a-b);
  if (t < all[0]) return all[0];
  return all[all.length-1];
}


function huntPickEnemy(user, seed) {
  const tier = tierByRegiao(user);
  const list = HUNT_ENEMIES[tier] || HUNT_ENEMIES[1];
  const idx = randInt(0, list.length - 1, seed);
  return { tier, enemy: list[idx] };
}

function ensureHuntEncounter(user, seed, opts) {
  if (user.encounter && user.encounter.hp > 0) return user.encounter;

  const o = opts && typeof opts === 'object' ? opts : {};
  const reg = getRegiao(user);

  // Chance progressiva de Elite (invisível)
  const baseElite = 0.05;
  const pity = clamp(Number(user.elitePity || 0), 0, 0.25);
  const add = clamp(Number(o.eliteAdd || 0), 0, 0.25);
  const biomeElite = clamp(Number(reg?.eliteBonus || 0), 0, 0.15);
  const regEvt = isRegiaoEventAtivo(user) ? 0.04 : 0;
  const allowElite = !!o.allowElite;

  // buff de marco (consome na próxima ação)
  const bonusNext = clamp(regioes.popBuff(user, 'eliteBoostNext') * 0.02, 0, 0.10);

  let eliteChance = clamp(baseElite + pity + add + biomeElite + regEvt + bonusNext, 0, 0.35);
  const canEliteByLevel = (Number(user.lvl || 1) >= 5);
  const regHasEliteTier = Array.isArray(reg.tiers) && reg.tiers.includes(3);

  let isElite = false;
  let pick;

  if (allowElite && canEliteByLevel && regHasEliteTier) {
    const roll = randInt(1, 1000, seed) / 1000;
    if (roll <= eliteChance) isElite = true;
  }

  if (isElite) {
    pick = { tier: 3, enemy: (HUNT_ENEMIES[3] || HUNT_ENEMIES[2] || HUNT_ENEMIES[1])[randInt(0, (HUNT_ENEMIES[3] || HUNT_ENEMIES[2] || HUNT_ENEMIES[1]).length - 1, seed)] };
    user.elitePity = 0; // reseta ao surgir Elite
  } else {
    pick = huntPickEnemy(user, seed);
  }

  const e = pick.enemy;

  const baseHp = randInt(e.hp[0], e.hp[1], seed);
  const baseAtk = randInt(e.atk[0], e.atk[1], seed);
  const baseGold = randInt(e.gold[0], e.gold[1], seed);
  const baseXp = randInt(e.xp[0], e.xp[1], seed);

  // Variantes (sem siglas, sem termos técnicos)
  const vRoll = randInt(1, 10000, seed);

  let variant = 'normal';
  if (vRoll <= 10) variant = 'suprema';
  else if (vRoll <= 60) variant = 'lendario';
  else if (vRoll <= 220) variant = 'corrompido';
  else if (vRoll <= 1200) variant = 'feroz';
  else if (vRoll <= 3000) variant = 'fraco';

  const mult = (variant === 'fraco')
    ? { hp: 0.85, atk: 0.90, gold: 0.90, xp: 0.92 }
    : (variant === 'feroz')
      ? { hp: 1.15, atk: 1.12, gold: 1.18, xp: 1.15 }
      : (variant === 'corrompido')
        ? { hp: 1.25, atk: 1.18, gold: 1.28, xp: 1.22 }
        : (variant === 'lendario')
          ? { hp: 1.45, atk: 1.28, gold: 1.55, xp: 1.35 }
          : (variant === 'suprema')
            ? { hp: 1.75, atk: 1.45, gold: 1.90, xp: 1.60 }
            : { hp: 1.00, atk: 1.00, gold: 1.00, xp: 1.00 };

  const eliteMult = isElite ? { hp: 1.18, atk: 1.12, gold: 1.22, xp: 1.18 } : { hp: 1, atk: 1, gold: 1, xp: 1 };

  const hp = Math.max(1, Math.round(baseHp * mult.hp * eliteMult.hp));
  const atk = Math.max(1, Math.round(baseAtk * mult.atk * eliteMult.atk));
  const gold = Math.max(1, Math.round(baseGold * mult.gold * eliteMult.gold));
  const xp = Math.max(1, Math.round(baseXp * mult.xp * eliteMult.xp));

  const tag =
    (variant === 'suprema') ? '🌑 Supremo' :
    (variant === 'lendario') ? '✨ Lendário' :
    (variant === 'corrompido') ? '🕳 Corrompido' :
    (variant === 'feroz') ? '🔥 Feroz' :
    (variant === 'fraco') ? '💤 Cansado' :
    null;

  const vName = tag ? `${e.name} ${tag}` : e.name;

  let vDesc = e.desc;
  if (variant === 'fraco') vDesc = `${e.desc} Parece cansado, mas ainda pode reagir.`;
  if (variant === 'feroz') vDesc = `${e.desc} Os olhos brilham de fúria. Recompensa maior… e risco maior.`;
  if (variant === 'corrompido') vDesc = `${e.desc} Algo errado está aqui. A sombra se move junto.`;
  if (variant === 'lendario') vDesc = `${e.desc} Uma presença rara. Você sente o perigo no ar.`;
  if (variant === 'suprema') vDesc = `${e.desc} O mundo fica silencioso. Esse encontro não acontece duas vezes.`;

  if (isElite) {
    vDesc = `${vDesc} 🌟 Uma Elite apareceu.`;
  }

  user.encounter = {
    tier: pick.tier,
    id: e.id,
    name: isElite ? `🌟 Elite: ${vName}` : vName,
    desc: vDesc,
    variant,
    isElite,
    regionKey: reg.key,
    hpMax: hp,
    hp: hp,
    atk: atk,
    goldWin: gold,
    xpWin: xp,
    drops: e.drops || []
  };

  return user.encounter;
}


function huntRollDrops(enc, user, seed, dropAdd = 0) {
  const lootBonus = computeLootBonus(user);
  const out = [];
  for (const d of (enc.drops || [])) {
    const chance = clamp(Number(d.chance || 0) + lootBonus + Number(dropAdd || 0), 0, 0.90);
    if (randInt(1, 1000, seed) / 1000 <= chance) {
      out.push({ itemId: d.itemId, qty: randInt(d.min || 1, d.max || 1, seed) });
    }
  }
  return out;
}

function huntApplyStreakRewards(user, baseGold, baseXp, seed) {
  if (!user.hunt) user.hunt = { streak: 0, best: 0 };
  const s = Number(user.hunt.streak || 0);

  // bônus leve (não quebra o balance)
  const goldMult = clamp(1 + s * 0.06, 1, 1.35);
  const xpMult = clamp(1 + s * 0.04, 1, 1.25);

  // marcos de sequência: 3 / 5 / 8
  let milestoneGold = 0;
  let milestonePotion = false;
  if (s === 3) { milestoneGold = 60; milestonePotion = randInt(1, 100, seed) <= 25; }
  if (s === 5) { milestoneGold = 120; milestonePotion = randInt(1, 100, seed) <= 35; }
  if (s === 8) { milestoneGold = 220; milestonePotion = randInt(1, 100, seed) <= 50; }

  const lines = [];
  if (s > 0) lines.push(`🔥 Sequência: ${s} (bônus aplicado)`);
  if (milestoneGold > 0) lines.push(`🎯 Marco de sequência! +${fmtGold(milestoneGold)}g bônus`);

  return {
    gold: Math.round(baseGold * goldMult) + milestoneGold,
    xp: Math.round(baseXp * xpMult),
    text: lines.join('\n'),
    potion: milestonePotion
  };
}


async function handleCacar(msg, store, user, prefix) {
const now = Date.now();
const last = user.lastHunt || 0;

if (isFerido(user)) {
  return msg.reply(`🩹 Você ainda está se recuperando. Volte em ${avtempos.fmt(feridoLeft(user))}.`);
}

const cdHunt = Number(avtempos.CD.hunt || 30000);
const leftHunt = avtempos.leftMs(last, cdHunt);
if (leftHunt > 0) {
  return msg.reply(`⏳ Você precisa respirar. Tente novamente em ${avtempos.fmt(leftHunt)}.`);
}

// Energia natural (limite leve, sem poluição)
const eNow = ensureEnergia(user);
if (Number(eNow.cur || 0) <= 0) {
  const nextE = energiaNextMs(user);
  return msg.reply(nextE > 0 ? `⚡ Você está sem energia. Volte em ${avtempos.fmt(nextE)}.` : '⚡ Você está sem energia. Descanse um pouco.');
}

user.lastHunt = now;

const chatId = await getChatKey(msg);
maybeStartChatEvent(store, chatId, String(user.__key || '') + ':' + dateKeyNow());

const evt = getChatEvent(store, chatId);
const evtCfg = evt ? (EVENTOS[evt.key] || null) : null;
const eliteAdd = evtCfg ? Number(evtCfg.eliteAdd || 0) : 0;

const seed = makeStableSeedFromParts(user.__key, 'hunt', dateKeyNow(), last || 0);
const enc = ensureHuntEncounter(user, seed, { eliteAdd, allowElite: Number(eNow.cur || 0) >= 2 });

// Consome energia conforme o tipo do encontro
const custo = energiaGastaPara(enc);
if (!gastarEnergia(user, custo)) {
  const nextE = energiaNextMs(user);
  return msg.reply(nextE > 0 ? `⚡ Você está sem energia. Volte em ${avtempos.fmt(nextE)}.` : '⚡ Você está sem energia. Descanse um pouco.');
}

    __scheduleWrite();

  if (!user.hunt) user.hunt = { streak: 0, best: 0 };

  const lines = [];
  lines.push('🐾 *CAÇA*');
  if (enc.variant === 'suprema') lines.push('🌑 Um encontro supremo surgiu.');
  else if (enc.isElite) lines.push('🌟 Uma Elite está à sua frente.');
  else if (enc.variant === 'lendario') lines.push('✨ Um inimigo lendário apareceu.');
  lines.push('');
  lines.push(`Você encontrou: *${enc.name}*`);
  lines.push(enc.desc);
  lines.push('');
  lines.push(`❤️ Vida do alvo: ${enc.hp}/${enc.hpMax}`);
  lines.push(`⚠️ Risco: se sua vida cair a 0, a sequência zera.`);
  lines.push('');
  lines.push('Ações:');
  lines.push(`• *${prefix}avatacar*`);
  lines.push(`• *${prefix}avusar Poção Pequena* (ou Média / Grande)`);
  lines.push(`• *${prefix}avfugir* (perde 1 ponto de sequência)`);
  lines.push('');
  lines.push(`🔥 Sequência atual: ${user.hunt.streak || 0} (melhor: ${user.hunt.best || 0})`);
  lines.push('');
  lines.push(nextObjectiveHint(prefix, user));

  return msg.reply(lines.join('\n'));
}

async function handleAtacar(msg, store, user, prefix) {
  if (!user.encounter || user.encounter.hp <= 0) return msg.reply(`📭 Nada para atacar. Use *${prefix}avcacar*.`);

  const now = Date.now();
  if (now - (user.lastAttackAt || 0) < (avtempos.CD.attack || 3500)) return msg.reply('⏳ Você está se reposicionando. Aguarde alguns segundos.');
  user.lastAttackAt = now;

  const seed = { v: 0xdeadbeef ^ now };
  const enc = user.encounter;

  // player atk (base + chance de crit, reaproveita balance do boss)
  const st = computeBaseStats(user);
  let atk = st.atk;
  let dmg = Math.max(1, Math.round(atk * randInt(85, 115, seed) / 100));
  const estilo = String(user.estilo || 'equilibrado');
  if (estilo === 'ofensivo') dmg = Math.max(1, Math.round(dmg * 1.10));
  if (estilo === 'defensivo') dmg = Math.max(1, Math.round(dmg * 0.95));
  const critChance = computeCritChance(user);
  const crit = randInt(1, 100, seed) <= Math.round(critChance * 100);
  if (crit) dmg = Math.round(dmg * 1.5);

  enc.hp = Math.max(0, enc.hp - dmg);

  const lines = [];
  lines.push(`🗡️ Você causou ${dmg} de dano${crit ? ' 💥' : ''}`);

  let enemyDmg = 0;

  // enemy retaliation (mesma fórmula, só texto mais natural)
  if (enc.hp > 0) {
    let dmg2 = Math.max(1, Math.round(enc.atk * randInt(85, 115, seed) / 100));
    const estilo2 = String(user.estilo || 'equilibrado');
    if (estilo2 === 'defensivo') dmg2 = Math.max(1, Math.round(dmg2 * 0.88));
    if (estilo2 === 'ofensivo') dmg2 = Math.max(1, Math.round(dmg2 * 1.06));
    // pool de HP do jogador fora do boss: usa battleLite
    if (!user.battleLite) {
      const base = computeBaseStats(user);
      user.battleLite = { hp: base.hp, hpMax: base.hp };
    }
    user.battleLite.hp = Math.max(0, (user.battleLite.hp || 0) - dmg2);
    enemyDmg = dmg2;
    lines.push(`🐺 ${enc.name} causou ${dmg2} de dano`);
  }

  // status (com barra visual simples)
  const hpPool = user.battleLite || { hp: computeBaseStats(user).hp, hpMax: computeBaseStats(user).hp };
  lines.push('');
  lines.push('❤️ Você');
  lines.push(hpBar(hpPool.hp, hpPool.hpMax));
  lines.push('');
  lines.push(`🎯 ${enc.name}`);
  lines.push(hpBar(enc.hp, enc.hpMax));

  // pressão e dicas (sem mudar fórmula)
  const hpPctE = enc.hpMax ? (enc.hp / enc.hpMax) : 1;
  const hpPctP = hpPool.hpMax ? (hpPool.hp / hpPool.hpMax) : 1;

  if (enc.hp > 0 && hpPctE <= 0.25) lines.push(`⚠️ ${enc.name} está desesperado!`);
  if (hpPool.hp > 0 && hpPctP <= 0.30) lines.push('💊 Talvez seja hora de usar uma poção.');

  // reações curtas (raras)
  const reactRoll = randInt(1, 100, seed);
  if (enc.hp > 0 && reactRoll <= 10) lines.push(`🐺 ${enc.name} investe com força!`);
  else if (enc.hp > 0 && reactRoll <= 16) lines.push(`🐺 ${enc.name} hesita por um momento.`);

  lines.push('');
  lines.push(`➡️ ${prefix}avatacar | ${prefix}avfugir`);


  // defeat
  if (hpPool.hp <= 0) {
    user.encounter = null;
    if (user.hunt) user.hunt.streak = 0;
    user.battleLite = null;
    __scheduleWrite();
    user.feridoAte = Date.now() + (avtempos.CD.injury || (10 * 60 * 1000));
    pushHistorico(user, `Derrota contra ${enc.name}`);
    __scheduleWrite();
    return msg.reply(`💀 *DERROTA*
${lines.join('\n')}

Você recua ferido. Sua sequência foi quebrada.`);
  }

  // victory
  if (enc.hp <= 0) {
    // streak
    if (!user.hunt) user.hunt = { streak: 0, best: 0 };
    user.hunt.streak = (user.hunt.streak || 0) + 1;
    user.hunt.best = Math.max(user.hunt.best || 0, user.hunt.streak || 0);

    // contrato diário (conta vitórias na caça)
    const dc = ensureDailyContract(user);
    if (dc && dc.type === 'cacar' && !dc.claimed) {
      dc.progress = Math.min(dc.goal, (Number(dc.progress) || 0) + 1);
      if (dc.progress >= dc.goal) dc.done = true;
    }
// Contrato especial da região (integrado ao avregiao)
if (user.regionContract && typeof user.regionContract === 'object' && user.regionContract.dayKey === dateKeyNow()) {
  const rc = user.regionContract;
  if (!rc.claimed && rc.regionKey === String(enc.regionKey || getRegiao(user).key)) {
    rc.progress = Math.min(rc.goal, (Number(rc.progress) || 0) + 1);
    if (rc.progress >= rc.goal) rc.done = true;
  }
}

// Contrato semanal difícil (por região)
if (user.regionWeekly && typeof user.regionWeekly === 'object' && user.regionWeekly.weekKey === weekKeyNow()) {
  const wc = user.regionWeekly;
  if (!wc.claimed && wc.regionKey === String(enc.regionKey || getRegiao(user).key)) {
    wc.progress = Math.min(wc.goal, (Number(wc.progress) || 0) + 1);
    if (wc.progress >= wc.goal) wc.done = true;
  }
}

// Elite com chance progressiva (invisível)
if (enc.isElite) {
  user.elitePity = 0;
  user.fama = (Number(user.fama) || 0) + 1;
} else {
  user.elitePity = clamp((Number(user.elitePity) || 0) + 0.03, 0, 0.25);
}

// Progresso da região (pode ativar evento curto)
const startedRegEvt = bumpRegiaoProgress(user, String(enc.regionKey || getRegiao(user).key), randInt(8, 14, seed));

    const chatId = await getChatKey(msg);
    const evt = getChatEvent(store, chatId);
    const bon = applyEventBonus(evt, enc.goldWin || 10, enc.xpWin || 10);
    const rew = huntApplyStreakRewards(user, bon.gold, bon.xp, seed);
    const rb = relicBonus(user);
    const famaMul = 1 + clamp((Number(user.fama || 0) * 0.001), 0, 0.05);
    const regMul = isRegiaoEventAtivo(user) ? 1.05 : 1;
    const biome = getRegiao(user);
    const biomeGoldMul = (Number(biome?.goldMul) > 0 ? Number(biome.goldMul) : 1);
    const biomeXpMul = (Number(biome?.xpMul) > 0 ? Number(biome.xpMul) : 1);
    const lootBoostNext = clamp(regioes.popBuff(user, 'lootBoostNext') * 0.03, 0, 0.12);
    const goldBase = Math.max(1, Number(rew.gold) || 0);
    const gFinal = goldWithPrestigio(
      user,
      Math.max(1, Math.round(goldBase * (rb.goldMul || 1) * famaMul * regMul * biomeGoldMul))
    );
    user.gold += gFinal;
    user.xp += Math.max(1, Math.round((Number(rew.xp) || 0) * biomeXpMul));
    if (rew.potion) invAdd(user, 'POT_PEQ', 1);

    const ups = maybeLevelUp(user);
    pushHistorico(user, `Vitória na caça: ${enc.name}`);
    if (user.season && typeof user.season === 'object') user.season.ouro = (Number(user.season.ouro)||0) + gFinal;

    lines.push('');
    lines.push(`🐺 ${enc.name} foi abatido`);
    lines.push('');
    lines.push(`💰 Ouro recebido: +${fmtGold(gFinal)}g`);
    lines.push(`⭐ XP ganho: +${fmtGold(rew.xp)} XP`);
    if (rew.text) lines.push(rew.text);
    lines.push(`🔥 Sequência: ${user.hunt.streak || 0}`);
    if (rew.potion) lines.push(`🍀 Bônus de marco: ${itemName('POT_PEQ')} x1`);
    lines.push('');
    lines.push(`➡️ Continuar caçando — *${prefix}avcacar*`);
    lines.push(`➡️ Ver perfil — *${prefix}avperfil*`);
    if (startedRegEvt) lines.push('🌿 Evento da região começou.');
    if (user.regionContract && user.regionContract.done && !user.regionContract.claimed) lines.push(`📜 ${user.regionContract.title}: pronto para resgatar em *${prefix}avregiao resgatar*`);
    if (ups > 0) lines.push(`⬆️ Você subiu ${ups} nível(is)! Agora: ${user.lvl}`);

    const drops = huntRollDrops(enc, user, seed, bon.dropAdd + lootBoostNext);
    if (drops.length) {
      lines.push('');
      lines.push('🎁 *Espólios:*');
      drops.forEach(d => lines.push(lootLine(d.itemId, d.qty)));
      drops.forEach(d => invAdd(user, d.itemId, d.qty));

      // celebra raridades altas
      const big = drops.find(d => {
        const r = String(ITEM[d.itemId]?.rarity || '').toLowerCase();
        return r === 'epico' || r === 'mitico';
      });
      if (big) {
        lines.push('');
        lines.push(lootCelebration(big.itemId));
      }
    } else {
      // sensação de valor no começo: quase sempre um espólio útil
      if ((Number(user.lvl) || 1) <= 3 && randInt(1, 100, seed) <= 70) {
        invAdd(user, 'MAT_ERVA', 1);
        lines.push('');
        lines.push('🎁 *Espólios:*');
        lines.push(lootLine('MAT_ERVA', 1));
      } else {
        lines.push('');
        lines.push('🎁 Espólios: nada além de pegadas e poeira…');
      }
    }

    // limpa encontro, mantém HP atual do battleLite (o jogador segue com risco)
    user.encounter = null;
    __scheduleWrite();

    // dica de progressão
    const nextHint = nextObjectiveHint(prefix, user);

    return msg.reply(`🐾 *CAÇA*
${lines.join('\n')}

${nextHint}`);
  }

  __scheduleWrite();
  return msg.reply(`🐾 *CAÇA*
${lines.join('\n')}

➡️ *${prefix}avatacar* | *${prefix}avusar Poção Pequena* | *${prefix}avfugir*`);
}

function handleFugir(msg, store, user, prefix) {
  if (!user.encounter) return msg.reply(`📭 Você não está caçando nada. Use *${prefix}avcacar*.`);
  user.encounter = null;
  // fuga não zera sequência, mas pune levemente
  if (!user.hunt) user.hunt = { streak: 0, best: 0 };
  user.hunt.streak = Math.max(0, (user.hunt.streak || 0) - 1);
  __scheduleWrite();
  return msg.reply(`🏃 Você recua antes que a situação piore. Sequência agora: ${user.hunt.streak || 0}.`);
}

function handleUsar(msg, store, user, prefix, args) {
  const what = String(args?.join(' ') || '').trim();
  if (!what) return msg.reply(`Use: *${prefix}usar <poção>* (ex.: Poção Pequena)`);
  const itemId = findItemIdByInput(what);
  if (!itemId) return msg.reply('❌ Eu não reconheci essa poção. Use o nome como aparece na mochila.');
  if (!['POT_PEQ','POT_MED','POT_GRA'].includes(itemId)) return msg.reply('❌ Este item não pode ser usado aqui.');
  if (!invHas(user, itemId, 1)) return msg.reply(`❌ Você não tem ${itemName(itemId)}.`);

  const base = computeBaseStats(user);
  if (!user.battleLite) user.battleLite = { hp: base.hp, hpMax: base.hp };
  if (!user.battleLite.hpMax) user.battleLite.hpMax = base.hp;

  const heal = (itemId === 'POT_PEQ') ? 50 : (itemId === 'POT_MED') ? 120 : 250;

  user.battleLite.hp = Math.min(user.battleLite.hpMax, (user.battleLite.hp || 0) + heal);
  invAdd(user, itemId, -1);
  __scheduleWrite();

  const extra = user.encounter ? `

➡️ Volte para a luta com *${prefix}atacar*.` : '';
  return msg.reply(`🧪 Você usou *${itemName(itemId)}*.
❤️ Vida: ${user.battleLite.hp}/${user.battleLite.hpMax}${extra}`);
}


// =========================
// EXPLORAR
// =========================
async function handleExplorar(msg, store, user, prefix, args) {
const now = Date.now();
const last = user.lastExplore || 0;

// Tipo de rota (curta/longa/viagem) via args[0]
const route = regioes.routeByArg(args && args[0]);

// Energia
const eNow = ensureEnergia(user);
if (Number(eNow.cur || 0) <= 0) {
  const nextE = energiaNextMs(user);
  return msg.reply(nextE > 0 ? `⚡ Você está sem energia. Volte em ${avtempos.fmt(nextE)}.` : '⚡ Você está sem energia. Descanse um pouco.');
}

const cdExp = Number(
  (route.key === 'viagem' ? avtempos.CD.travel : (route.key === 'longa' ? avtempos.CD.exploreLong : avtempos.CD.explore))
  || 120000
);
const left = avtempos.leftMs(last, cdExp);
if (left > 0) return msg.reply(`⏳ Você precisa recuperar o fôlego. Explore novamente em ${avtempos.fmt(left)}.`);

// Gasta energia (exploração é ação principal)
if (!gastarEnergia(user, 1)) {
  const nextE = energiaNextMs(user);
  return msg.reply(nextE > 0 ? `⚡ Você está sem energia. Volte em ${avtempos.fmt(nextE)}.` : '⚡ Você está sem energia. Descanse um pouco.');
}

user.lastExplore = now;
  const today = dateKeyNow();
  const seed = makeStableSeedFromParts(user.__key, today, last || 0);
  const roll = randInt(1, 100, seed);
  let result = '';
  let success = false;
  const biome = getRegiao(user);
  const biomeGoldMul = (Number(biome?.goldMul) > 0 ? Number(biome.goldMul) : 1);

  if (roll <= 30) {
    const gold = randInt(10, 30, seed);
    const rb = relicBonus(user);
    const famaMul = 1 + clamp((Number(user.fama || 0) * 0.001), 0, 0.05);
    const regMul = isRegiaoEventAtivo(user) ? 1.05 : 1;
    const gFinal = Math.max(1, Math.round(gold * (rb.goldMul || 1) * famaMul * regMul * biomeGoldMul));
    success = true;
    user.gold += gFinal;
    result = `⚔️ Você emboscou um goblin! Saiu vitorioso e recolheu *${fmtGold(gFinal)} ouro*.`;
  } else if (roll <= 60) {
    result = `🍂 Você percorreu trilhas antigas, mas não encontrou nada de valor.`;
  } else if (roll <= 90) {
    success = true;
    const dominant = Array.isArray(biome?.lootDominante) && biome.lootDominante.length ? biome.lootDominante : ['MAT_FERRO', 'MAT_COURO', 'MAT_ERVA'];
    const items = dominant.slice(0, 3);
    const item = items[randInt(0, items.length - 1, seed)];
    invAdd(user, item, 1);
    result = `🎒 Você encontrou um espólio: 
${lootLine(item, 1)}`;
  } else {
    const gold = randInt(100, 300, seed);
    success = true;
    invAdd(user, 'POT_PEQ', 1);
    const rb = relicBonus(user);
    const famaMul = 1 + clamp((Number(user.fama || 0) * 0.001), 0, 0.05);
    const regMul = isRegiaoEventAtivo(user) ? 1.05 : 1;
    const gFinal = Math.max(1, Math.round(gold * (rb.goldMul || 1) * famaMul * regMul * biomeGoldMul));
    user.gold += gFinal;
    result = `💎 *SORTE!* Um baú oculto te recompensou:
• Ouro: ${fmtGold(gFinal)}
${lootLine('POT_PEQ', 1)}`;
  }

  // contrato diário (conta explorações bem sucedidas)
  const dc = ensureDailyContract(user);
  if (dc && dc.type === 'explorar' && success && !dc.claimed) {
    dc.progress = Math.min(dc.goal, (Number(dc.progress) || 0) + 1);
    if (dc.progress >= dc.goal) dc.done = true;
  }

  __scheduleWrite();
  // Progresso da região (pode ativar evento curto)
  const startedRegEvt = bumpRegiaoProgress(
    user,
    biome.key,
    success
      ? randInt(route.progress[0], route.progress[1], seed)
      : randInt(Math.max(2, Math.floor(route.progress[0] / 2)), Math.max(3, Math.floor(route.progress[1] / 2)), seed)
  );
  if (startedRegEvt) result += `

🌿 Evento da região começou.`;

  await msg.reply(`🗺️ *EXPLORAÇÃO*\n${result}\n\n${nextObjectiveHint(prefix, user)}`);
}


// =========================
// CONTRATOS DIÁRIOS (ouro extra sem quebrar balance)
// =========================
function ensureDailyContract(user) {
  if (!user.daily) user.daily = {};
  const k = 'contract_' + dateKeyNow();
  const cur = user.daily[k];
  if (cur && typeof cur === 'object') return cur;

  // contratos simples (uma vez por dia)
  const pool = [
    { type: 'cacar', goal: 3, title: 'Contrato da Guilda', desc: 'Derrote 3 alvos na Caça.' },
    { type: 'explorar', goal: 1, title: 'Missão de Exploração', desc: 'Faça 1 exploração bem sucedida.' }
  ];

  const seed = makeStableSeedFromParts(user.__key, 'contract', dateKeyNow());
  const pick = pool[randInt(0, pool.length - 1, seed)];

  const contract = {
    title: pick.title,
    desc: pick.desc,
    type: pick.type,
    goal: pick.goal,
    progress: 0,
    done: false,
    claimed: false
  };

  user.daily[k] = contract;
  return contract;
}

function handleContrato(msg, store, user, prefix, args) {
  const sub = String(args?.[0] || '').toLowerCase().trim();
  const c = ensureDailyContract(user);

  if (!sub) {
    const lines = [];
    lines.push('📜 *CONTRATO DIÁRIO*');
    lines.push('');
    lines.push(`🧭 ${c.title}`);
    lines.push(`• ${c.desc}`);
    lines.push('');
    lines.push(`📊 Progresso: ${c.progress}/${c.goal}` + (c.done ? ' ✅' : ''));
    if (!c.done) {
      lines.push('');
      lines.push('Atalhos:');
      if (c.type === 'cacar') lines.push(`• Caçar: *${prefix}avcacar*`);
      if (c.type === 'explorar') lines.push(`• Explorar: *${prefix}avexp*`);
      lines.push('');
      lines.push('Quando completar, use:');
      lines.push(`• *${prefix}avcontrato resgatar*`);
    } else if (!c.claimed) {
      lines.push('');
      lines.push(`✅ Você completou o contrato! Resgate com: *${prefix}avcontrato resgatar*`);
    } else {
      lines.push('');
      lines.push('✅ Contrato do dia já resgatado. Volte amanhã para um novo.');
    }
    __scheduleWrite();
    return msg.reply(lines.join('\n'));
  }

  if (sub === 'resgatar' || sub === 'resgate' || sub === 'claim') {
    if (!c.done) return msg.reply('❌ Ainda não está completo. Veja o progresso em *avcontrato*.');
    if (c.claimed) return msg.reply('✅ Você já resgatou o contrato de hoje. Volte amanhã.');
    c.claimed = true;

    const baseGold = 120 + Math.round((Number(user.lvl) || 1) * 18);
    const baseXp = 45 + Math.round((Number(user.lvl) || 1) * 8);
    user.gold += baseGold;
    user.xp += baseXp;

    // chance pequena de poção
    const seed = makeStableSeedFromParts(user.__key, 'contract_reward', dateKeyNow());
    const gotPotion = randInt(1, 100, seed) <= 35;
    if (gotPotion) invAdd(user, 'POT_PEQ', 1);

    const ups = maybeLevelUp(user);
    pushHistorico(user, `Vitória na caça: ${enc.name}`);
    if (user.season && typeof user.season === 'object') user.season.ouro = (Number(user.season.ouro)||0) + gFinal;
    __scheduleWrite();

    return msg.reply(
      `🎁 *CONTRATO RESGATADO!*

` +
      `• Ouro: +${fmtGold(baseGold)}g
` +
      `• XP: +${fmtGold(baseXp)}
` +
      (gotPotion ? `• Bônus: ${itemName('POT_PEQ')} x1
` : '') +
      (ups > 0 ? `
⬆️ Você subiu ${ups} nível(is)! Agora: ${user.lvl}
` : '\n') +
      nextObjectiveHint(prefix, user)
    );
  }

  return msg.reply('Invocação inválida.');
}

// =========================
// MERCADOR — VENDA RÁPIDA (instantâneo)
// =========================
function handleVenderGuilda(msg, store, user, prefix, args) {
  const input = String(args?.[0] || '').trim();
  const qty = clamp(safeNumFromArgs(args?.[1]), 1, 999999);

  const itemId = findItemIdByInput(input);
  if (!itemId || !ITEM[itemId]) return msg.reply('❌ Eu não reconheci esse item. Use o nome como aparece na mochila.');
  if (!invHas(user, itemId, qty)) return msg.reply('❌ Você não tem essa quantidade.');

  const it = ITEM[itemId];
  const base = Number(it.price || 0);
  if (!base) return msg.reply('❌ Este item não tem valor de venda para a guilda.');
  if (it.trade === false) return msg.reply('❌ A guilda não compra este item.');

  const unit = Math.max(1, Math.floor(base * 0.60));
  const total = unit * qty;

  invAdd(user, itemId, -qty);
  user.gold += total;

  __scheduleWrite();
  return msg.reply(
    `💰 *VENDA RÁPIDA*

` +
    `Você vendeu: ${itemName(itemId)} x${qty}
` +
    `Recebeu: ${fmtGold(total)}g (preço da guilda)

` +
    `Dica: no *${prefix}leilao* você pode conseguir mais, mas depende de alguém comprar.`
  );
}



// =========================
// NOCTHARIA (DARK) — EXPLORAÇÃO / DUNGEON / INVENTÁRIO
// =========================
function darkTierByPlayerLvl(lvl) {
  const L = Math.max(1, Number(lvl) || 1);
  if (L <= 3) return 0;        // Tier 0 (iniciante)
  if (L <= 7) return 1;        // Tier 1 (intermediário)
  return 2;                    // Tier 2 (elite)
}

function darkEnemyBySeed(seed, tier) {
  // Sistema de UP (mobs), nunca boss.
  const T0 = [
    { name: 'Rato Abissal' },
    { name: 'Sombra Rasgada' },
    { name: 'Verme de NØX' },
  ];
  const T1 = [
    { name: 'Cultista Perdido' },
    { name: 'Cão Carmesim' },
    { name: 'Olho Vazio' },
  ];
  const T2 = [
    { name: 'Arauto da Névoa' },
    { name: 'Vulto Carmesim' },
    { name: 'Sentinela Abissal' },
  ];

  const list = (tier === 0) ? T0 : (tier === 1) ? T1 : T2;
  return list[randInt(0, list.length - 1, seed)];
}

function ensureDarkEncounter(user, seed) {
  if (!user.dark) user.dark = {};
  if (user.dark.encounter && user.dark.encounter.hp > 0) return user.dark.encounter;

  const pLvl = Math.max(1, Number(user.dark?.stats?.lvl) || 1);
  const tier = darkTierByPlayerLvl(pLvl);

  const base = darkEnemyBySeed(seed, tier);

  // Stats por Tier (conforme especificação)
  const hpMin = (tier === 0) ? 50  : (tier === 1) ? 110 : 180;
  const hpMax = (tier === 0) ? 90  : (tier === 1) ? 160 : 260;
  const atkMin = (tier === 0) ? 6  : (tier === 1) ? 12  : 18;
  const atkMax = (tier === 0) ? 10 : (tier === 1) ? 16  : 26;

  const xpMin = (tier === 0) ? 6  : (tier === 1) ? 10 : 18;
  const xpMax = (tier === 0) ? 8  : (tier === 1) ? 14 : 25;

  // Corrupção por luta
  const corrMin = (tier === 0) ? 0 : (tier === 1) ? 2 : 3;
  const corrMax = (tier === 0) ? 1 : (tier === 1) ? 2 : 4;

  // “Nível” do inimigo é só informativo (mantém fantasia), sem quebrar balance.
  const eLvl = Math.max(1, pLvl + randInt(-1, 1, seed));

  const hp = randInt(hpMin, hpMax, seed);
  const atk = randInt(atkMin, atkMax, seed);

  user.dark.encounter = {
    tier,
    name: base.name,
    lvl: eLvl,
    hpMax: hp,
    hp,
    atk,
    xpWin: randInt(xpMin, xpMax, seed),
    corrGain: randInt(corrMin, corrMax, seed),
  };
  return user.dark.encounter;
}

async function __avNameFromMsg(msg, user) {
  const n = (msg && (msg.pushName || msg._data?.notifyName)) || (user && user.name) || 'Você';
  return String(n || 'Você').trim() || 'Você';
}

function __avHpBar(cur, max, size = 8) {
  const c = Math.max(0, Number(cur) || 0);
  const m = Math.max(1, Number(max) || 1);
  const pct = Math.max(0, Math.min(1, c / m));
  const filled = Math.round(pct * size);
  const empty = Math.max(0, size - filled);
  return `[${'█'.repeat(filled)}${'░'.repeat(empty)}] ${c}/${m}`;
}


function __avFinishDarkEncounter(user, enc, seed, prefix) {
  const tier = Number(enc.tier ?? 0);

  // Drops por Tier (materiais + chance de suporte)
  const dropRoll = randInt(1, 100, seed);

  if (tier === 0) {
    if (dropRoll <= 70) darkInvAdd(user, 'MAT_FRAG_ABISSAL', randInt(1, 2, seed));
    if (dropRoll <= 18) darkInvAdd(user, 'POT_SOMBRA', 1);
    if (dropRoll <= 8) darkInvAdd(user, 'POT_ABISSAL', 1);
  } else if (tier === 1) {
    if (dropRoll <= 75) darkInvAdd(user, 'MAT_FRAG_ABISSAL', randInt(2, 4, seed));
    if (dropRoll <= 40) darkInvAdd(user, 'MAT_MINERIO_NEGRO', randInt(1, 2, seed));
    if (dropRoll <= 25) darkInvAdd(user, 'POT_SOMBRA', 1);
    if (dropRoll <= 12) darkInvAdd(user, 'POT_ABISSAL', 1);
  } else if (tier === 2) {
    if (dropRoll <= 80) darkInvAdd(user, 'MAT_FRAG_ABISSAL', randInt(3, 6, seed));
    if (dropRoll <= 55) darkInvAdd(user, 'MAT_MINERIO_NEGRO', randInt(2, 3, seed));
    if (dropRoll <= 35) darkInvAdd(user, 'MAT_ESSENCIA_SOMBRA', 1);
    if (dropRoll <= 28) darkInvAdd(user, 'POT_SOMBRA', 1);
    if (dropRoll <= 15) darkInvAdd(user, 'POT_ABISSAL', 1);
  } else {
    if (dropRoll <= 85) darkInvAdd(user, 'MAT_FRAG_ABISSAL', randInt(4, 8, seed));
    if (dropRoll <= 70) darkInvAdd(user, 'MAT_MINERIO_NEGRO', randInt(3, 5, seed));
    if (dropRoll <= 45) darkInvAdd(user, 'MAT_ESSENCIA_SOMBRA', randInt(1, 2, seed));
    if (dropRoll <= 20) darkInvAdd(user, 'REL_LASCA_NEGRA', 1);
    if (dropRoll <= 30) darkInvAdd(user, 'POT_SOMBRA', 1);
    if (dropRoll <= 18) darkInvAdd(user, 'POT_ABISSAL', 1);
  }

  // XP / Ouro (dark)
  const xp = Math.max(2, Math.round((enc.lvl || 1) * 6));
  const gold = Math.max(4, Math.round((enc.lvl || 1) * 9));
  user.xp = (Number(user.xp) || 0) + xp;
  user.gold = (Number(user.gold) || 0) + gold;

  // Corrupção por luta (Tier)
  user.dark.corr = clamp((user.dark.corr || 0) + Math.max(0, Number(enc.corrGain) || 0), 0, 100);

  user.dark.encounter = null;
  user.dark.battle = null;

  return (
    `👁️ ${enc.name} foi derrotado\n\n` +
    `✨ Corrupção: ${user.dark.corr}%\n` +
    `💰 Recompensa recebida\n\n` +
    `➡️ Próximo passo:\n` +
    `• Continuar explorando — ${prefix}avexp\n` +
    `• Ver seu progresso — ${prefix}avperfil`
  );
}


function handleAvExp(msg, store, user, prefix) {
  const now = Date.now();
  if (!user.dark) user.dark = {};
  const last = user.dark.lastExplore || 0;
  if (now - last < 120000) return msg.reply('⏳ As sombras exigem 2min antes da próxima exploração.');

  user.dark.lastExplore = now;
  const today = dateKeyNow();
  const seed = makeStableSeedFromParts(user.__key, 'dark', today, last || 0);
  const enc = ensureDarkEncounter(user, seed);

  __scheduleWrite();
  return msg.reply(
    `🌫️ MUNDO SOMBRIO
` +
    `👁️ ${enc.name} — Nv.${enc.lvl}
` +
    `Vida: ${enc.hp}/${enc.hpMax}

` +
    `Ações:
` +
    `• ${prefix}avatacar
` +
    `• ${prefix}avskill sombra
` +
    `• ${prefix}avfugir`
  );
}

function handleAvAtk(msg, store, user, prefix) {
  if (!user.dark?.encounter || user.dark.encounter.hp <= 0) return msg.reply(`📭 Nenhum alvo nas sombras. Use ${prefix}avexp.`);
  const now = Date.now();
  const seed = { v: 0xdeadbeef ^ now };

  const enc = user.dark.encounter;
  const st = computeDarkBaseStats(user);

  const actorName = __avNameFromMsg(msg, user);

  // garante pool de vida do jogador (mantém fórmula intacta)
  if (!user.dark.battle) {
    user.dark.battle = { playerHp: st.hp, playerHpMax: st.hp, turns: 0 };
  }
  user.dark.battle.turns = (Number(user.dark.battle.turns) || 0) + 1;

  const dmg = Math.max(1, Math.round(st.atk * randInt(85, 115, seed) / 100));
  enc.hp = Math.max(0, enc.hp - dmg);

  let bdmg = 0;
  if (enc.hp > 0) {
    bdmg = Math.max(1, Math.round(enc.atk * 0.90));
    user.dark.battle.playerHp = Math.max(0, (user.dark.battle.playerHp || st.hp) - bdmg);
  }

  // derrota do jogador
  if (user.dark.battle?.playerHp <= 0) {
    user.dark.encounter = null;
    user.dark.battle = null;
    user.dark.corr = clamp((user.dark.corr || 0) + 6, 0, 100);
    __scheduleWrite();
    return msg.reply(
      `💀 Você caiu.\n` +
      `✨ Corrupção: ${user.dark.corr}%\n\n` +
      `➡️ Próximo passo: ${prefix}avexp`
    );
  }

  // vitória
  if (enc.hp <= 0) {
    const text = __avFinishDarkEncounter(user, enc, seed, prefix);
    __scheduleWrite();
    return msg.reply(text);
  }

  __scheduleWrite();

  return msg.reply(
    `🗡️ ${actorName} causou ${dmg} de dano\n` +
    (bdmg > 0 ? `👁️ ${enc.name} causou ${bdmg} de dano\n\n` : `\n`) +
    `👁️ ${enc.name}\n` +
    `${__avHpBar(enc.hp, enc.hpMax)}\n\n` +
    `➡️ ${prefix}avatacar | ${prefix}avfugir`
  );
}


function handleAvSkill(msg, store, user, prefix, args) {
  const sk = String(args?.[0] || '').toLowerCase().trim();
  if (sk !== 'sombra') return msg.reply(`Use ${prefix}avskill sombra.`);
  if (!user.dark?.encounter || user.dark.encounter.hp <= 0) return msg.reply(`📭 Nenhum alvo nas sombras. Use ${prefix}avexp.`);

  const now = Date.now();
  const seed = { v: 0xdeadbeef ^ now };
  const enc = user.dark.encounter;
  const st = computeDarkBaseStats(user);

  const actorName = __avNameFromMsg(msg, user);

  const dmg = Math.max(1, Math.round(st.atk * 1.25));
  enc.hp = Math.max(0, enc.hp - dmg);

  user.dark.corr = clamp((user.dark.corr || 0) + 4, 0, 100);
  __scheduleWrite();

  // vitória
  if (enc.hp <= 0) {
    const text = __avFinishDarkEncounter(user, enc, seed, prefix);
    __scheduleWrite();
    return msg.reply(text);
  }

  return msg.reply(
    `🕯️ ${actorName} causou ${dmg} de dano\n\n` +
    `👁️ ${enc.name}\n` +
    `${__avHpBar(enc.hp, enc.hpMax)}\n\n` +
    `✨ Corrupção: ${user.dark.corr}%\n` +
    `➡️ ${prefix}avatacar | ${prefix}avfugir`
  );
}


function handleAvRun(msg, store, user, prefix) {
  if (!user.dark?.encounter) return msg.reply(`📭 Nenhum perigo imediato. Use *${prefix}avexp*.`);
  user.dark.encounter = null;
  user.dark.battle = null;
  user.dark.corr = clamp((user.dark.corr || 0) + 1, 0, 100);
  __scheduleWrite();
  return msg.reply(`🏃 Você recua para a penumbra. Corrupção: ${user.dark.corr}%`);
}

function handleAvDg(msg, store, user, prefix, args) {
  const sub = String(args?.[0] || '').toLowerCase().trim();
  const DGS = [
    { id: 1, name: 'Ruínas Vivas', minLv: 1, maxDepth: 5 },
    { id: 2, name: 'Ritual Carmesim', minLv: 2, maxDepth: 7 },
    { id: 3, name: 'Abismo de NØX', minLv: 5, maxDepth: 10, locked: true },
  ];

  if (!sub) {
    const lines = ['🏰 *DUNGEONS — NOCTHARIA*', ''];
    DGS.forEach(d => {
      const lock = d.locked ? ' (bloq)' : '';
      lines.push(`${d.id}) ${d.name}${lock}`);
    });
    lines.push('');
    lines.push(`➡️ *${prefix}avdg entrar <id>*`);
    return msg.reply(lines.join('\n'));
  }

  if (sub === 'entrar') {
    const id = Number(args?.[1]);
    const dg = DGS.find(d => d.id === id);
    if (!dg) return msg.reply('Dungeon inválida.');
    if (dg.locked) return msg.reply('🔒 Esta dungeon está bloqueada por enquanto.');
    user.dark.dungeon = { id: dg.id, name: dg.name, depth: 1, maxDepth: dg.maxDepth };
    __scheduleWrite();
    return msg.reply(`🏰 Você entrou em *${dg.name}*.\n➡️ *${prefix}avdg go* | *${prefix}avdg sair*`);
  }

  if (sub === 'go') {
    if (!user.dark?.dungeon) return msg.reply(`Você não está em uma dungeon. Use *${prefix}avdg entrar <id>*.`);
    user.dark.dungeon.depth = Math.min(user.dark.dungeon.maxDepth, (user.dark.dungeon.depth || 1) + 1);
    user.dark.corr = clamp((user.dark.corr || 0) + 3, 0, 100);
    __scheduleWrite();
    const done = user.dark.dungeon.depth >= user.dark.dungeon.maxDepth;
    return msg.reply(
      `🏰 *${user.dark.dungeon.name}*\n` +
      `Profundidade: ${user.dark.dungeon.depth}/${user.dark.dungeon.maxDepth}\n` +
      `Corrupção: ${user.dark.corr}%` +
      (done ? `\n\n✅ Você alcançou o fim desta rota.` : `\n\n➡️ *${prefix}avdg go* | *${prefix}avdg sair*`)
    );
  }

  if (sub === 'sair') {
    if (!user.dark?.dungeon) return msg.reply('Você não está em uma dungeon.');
    const depth = user.dark.dungeon.depth || 1;
    user.dark.dungeon = null;
    __scheduleWrite();
    return msg.reply(`🚪 Você saiu da dungeon. Profundidade alcançada: ${depth}.`);
  }

  return msg.reply('Invocação inválida.');
}

function handleAvInv(msg, store, user, prefix) {
  const entries = Object.entries(user.dark?.inv || {});
  if (entries.length === 0) return msg.reply('🎒 Seu inventário de Noctharia está vazio.');
  const lines = ['🎒 *INVENTÁRIO — NOCTHARIA*'];
  let i = 1;
  for (const [id, qty] of entries) {
    lines.push(`${i}) ${id} — ${itemName(id)} x${qty}`);
    i++;
  }
  lines.push('');
  lines.push(`Usar: *${prefix}avusar <n>* | Equipar: *${prefix}avequip <n>*`);
  return msg.reply(lines.join('\n'));
}

function handleAvEquip(msg, store, user, prefix, args) {
  const idx = Number(args?.[0]);
  const entries = Object.entries(user.dark?.inv || {});
  if (!Number.isFinite(idx) || idx < 1 || idx > entries.length) return msg.reply(`Use: *${prefix}avequip <n>* (veja em *${prefix}avinv*)`);
  const [itemId] = entries[idx - 1];
  if (!user.dark.equip) user.dark.equip = { weapon: null, armor: null, acc: null };

  // regra simples por prefixo do item
  if (String(itemId).startsWith('ARMA_')) user.dark.equip.weapon = itemId;
  else user.dark.equip.acc = itemId;

  __scheduleWrite();
  return msg.reply(`✅ Equipado em Noctharia: *${itemName(itemId)}*`);
}

function handleAvUse(msg, store, user, prefix, args) {
  const idx = Number(args?.[0]);
  const entries = Object.entries(user.dark?.inv || {});
  if (!Number.isFinite(idx) || idx < 1 || idx > entries.length) return msg.reply(`Use: *${prefix}avusar <n>* (veja em *${prefix}avinv*)`);
  const [itemId] = entries[idx - 1];
  if (!darkInvHas(user, itemId, 1)) return msg.reply('Item indisponível.');

  if (itemId === 'POT_ABISSAL') {
    darkInvAdd(user, itemId, -1);
    user.dark.corr = clamp((user.dark.corr || 0) - 8, 0, 100);
    __scheduleWrite();
    return msg.reply(`🧪 Você bebeu ${itemName(itemId)}. Corrupção: ${user.dark.corr}%`);
  }

  if (itemId === 'POT_SOMBRA') {
    // Cura básica (HP) — útil no loop de UP
    const st = computeDarkBaseStats(user);
    if (!user.dark.battle) user.dark.battle = { playerHp: st.hp, playerHpMax: st.hp };
    if (!user.dark.battle.playerHpMax) user.dark.battle.playerHpMax = st.hp;

    const heal = 50;
    user.dark.battle.playerHp = Math.min(user.dark.battle.playerHpMax, (user.dark.battle.playerHp || st.hp) + heal);
    darkInvAdd(user, itemId, -1);
    __scheduleWrite();
    return msg.reply(`🩸 Você usou ${itemName(itemId)}. HP: ${user.dark.battle.playerHp}/${user.dark.battle.playerHpMax}`);
  }

  return msg.reply('Este item não pode ser usado diretamente.');
}

async function handleAvRank(client, msg, store, user, prefix, args) {
  const sub = String(args?.[0] || '').toLowerCase().trim();

  // normaliza chaves para evitar duplicados (@c.us vs só dígitos)
  const keys = Object.keys(store.users || {});
  const bestByCanon = new Map();

  const canonKey = (k) => {
    const s = String(k || '').trim();
    const digits = s.replace(/\D/g, '');
    if (digits && digits.length >= 6) return digits; // telefone
    return s.toLowerCase();
  };

  for (const k of keys) {
    const u = ensureUser(store, k);
    const lvl = Number(u.dark?.stats?.lvl) || 1;
    const xp = Number(u.dark?.stats?.xp) || 0;
    const corr = Number(u.dark?.corr) || 0;
    const depth = Number(u.dark?.dungeon?.depth) || 0;
    const power = lvl * 100 + xp + depth * 15 - corr * 2;

    const canon = canonKey(k);
    const prev = bestByCanon.get(canon);
    const row = { k, canon, lvl, xp, corr, depth, power };

    if (!prev || (row.lvl > prev.lvl) || (row.lvl === prev.lvl && row.power > prev.power)) {
      bestByCanon.set(canon, row);
    }
  }

  let rows = Array.from(bestByCanon.values());

  // ✅ FIEL AO GRUPO: em grupo, só considera quem está em chat.participants
  const chat = await whatsappSafe.safeGetChatFromMessage(msg);
  if (chat?.isGroup && Array.isArray(chat.participants) && chat.participants.length) {
    const inGroup = new Set(
      chat.participants
        .map((p) => canonKey(p?.id?._serialized || p?.id || p))
        .filter(Boolean)
    );
    rows = rows.filter((r) => inGroup.has(r.canon));
  }

  if (sub === 'abismo') {
    rows.sort((a, b) => (b.depth - a.depth) || (b.power - a.power));
  } else if (sub === 'poder') {
    rows.sort((a, b) => b.power - a.power);
  } else {
    rows.sort((a, b) => (b.lvl - a.lvl) || (b.power - a.power));
  }

  const top = rows.slice(0, 10);
  const lines = [`🏆 *RANK — NOCTHARIA* (${sub || 'nível'})`];

  // ✅ Nome (sem número) usando SSOT
  for (let i = 0; i < top.length; i++) {
    const r = top[i];
    const lookup = (r.canon && r.canon.length >= 6) ? r.canon : r.k;
    const name = await whatsappSafe.resolveDisplayNamePlain(client, lookup, chat, 'membro');
    lines.push(`${i + 1}. ${name} — Lv.${r.lvl} | Poder ${r.power} | Corr ${r.corr}%`);
  }

  return msg.reply(lines.join('\n'));
}

function handleAvCorr(msg, store, user, prefix) {
  const c = clamp((user.dark?.corr || 0), 0, 100);
  let txt = `☠️ *CORRUPÇÃO: ${c}%*\n\n`;
  txt += `Efeito:\nSombras sussurram seu nome.\n\n`;
  txt += `• *${prefix}avpurificar* (reduzir corrupção)`;
  if (c >= 50) txt += `\n\n⚠️ Acima de 50%: você pode virar Boss Global.`;
  return msg.reply(txt);
}

function handleAvPurificar(msg, store, user, prefix) {
  const c = clamp((user.dark?.corr || 0), 0, 100);
  if (c <= 0) return msg.reply('✨ Você já está purificado.');
  const cost = 2;
  if (!darkInvHas(user, 'MAT_FRAG_ABISSAL', cost)) {
    return msg.reply(`❌ Para purificar, precisa de ${cost}x ${itemName('MAT_FRAG_ABISSAL')}.`);
  }
  darkInvAdd(user, 'MAT_FRAG_ABISSAL', -cost);
  user.dark.corr = clamp(c - 15, 0, 100);
  __scheduleWrite();
  return msg.reply(`✨ Purificação feita. Corrupção: ${user.dark.corr}%`);
}

// =========================
// ROUTER
// =========================

// =========================
// PAINÉIS NOVOS (UX)
// =========================
function painelMeuAv(store, user, chatId, prefix, displayName) {
  // UI SSOT: painel compacto do jogador (sem textão)
  // Mantém assinatura para não quebrar calls existentes.
  return aventuraPainelUI.buildMeuAvPanel(store, user, chatId, prefix, displayName);
}

function painelEvento(store, chatId, prefix) {
  const evt = getChatEvent(store, chatId);
  const lines = [];
  lines.push('🌍 *EVENTO DO MUNDO*');
  if (!evt) {
    lines.push('Nada acontecendo agora.');
    lines.push(`Dica: jogando você pode despertar um evento.`);
    return lines.join('\n');
  }
  const endsAt = store.events?.[chatId]?.endsAt || 0;
  lines.push(`Agora: ${evt.name}`);
  lines.push(`Bônus: ${evt.bonus}`);
  lines.push(`Tempo: ${avtempos.fmt(Math.max(0, endsAt - Date.now()))}`);
  lines.push('');
  lines.push(`Ações rápidas:`);
  lines.push(`• ${prefix}avcacar`);
  lines.push(`• ${prefix}avexp`);
  return lines.join('\n');
}

// =========================
// BOSS RAID (por chat)
// - Ataque com cooldown
// - Contribuição diária (ouro leve) + ranking semanal
// =========================

function __ensureRaid(store, chatId) {
  if (!store.raids || typeof store.raids !== 'object') store.raids = {};

  const wk = weekKeyNow();
  const cur = store.raids[chatId];

  // fecha/premia semana anterior (lazy)
  if (cur && cur.weekKey && cur.weekKey !== wk && !cur.paidWeekKey) {
    const sum = __finalizeRaidWeek(store, chatId, cur);
    // prepara a próxima semana
    store.raids[chatId] = null;
    delete store.raids[chatId];
    return { raid: null, weeklyClosedText: sum };
  }

  if (cur && cur.weekKey === wk) return { raid: cur, weeklyClosedText: null };

  const bossList = [
    { id: 'colosso', name: 'Colosso do Norte', hp: 42000 },
    { id: 'hidra', name: 'Hidra Ancestral', hp: 46000 },
    { id: 'titã', name: 'Titã de Pedra', hp: 52000 },
  ];
  const pick = bossList[Math.floor(Math.random() * bossList.length)];

  const raid = {
    weekKey: wk,
    bossId: pick.id,
    bossName: pick.name,
    hp: pick.hp,
    hpMax: pick.hp,
    defeated: false,
    defeatedAt: 0,
    lastHitUser: null,
    contrib: {}, // userKey -> { dmg, lastAt, dayKey, dayGold }
    paidWeekKey: null,
    createdAt: Date.now(),
  };

  store.raids[chatId] = raid;
  return { raid, weeklyClosedText: null };
}

function __finalizeRaidWeek(store, chatId, raid) {
  try {
    const wk = String(raid?.weekKey || '').trim();
    if (!wk) return null;

    const winners = raidRewards.computeWeeklyWinners(raid.contrib || {});
    const rows = winners.rows;
    if (!rows.length) {
      raid.paidWeekKey = wk;
      return `🏁 *RAID — Semana encerrada*\nNinguém participou nessa semana.`;
    }

    // premia no store.users (sem depender de online)
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      const rank = i + 1;
      const u = store.users && store.users[r.userKey] ? store.users[r.userKey] : null;
      if (!u) continue;

      let addGold = 0;
      addGold += raidRewards.goldForRank(rank);
      if (raidRewards.canParticipation(r.dmg)) addGold += raidRewards.WEEKLY.participationGold;
      if (raid.lastHitUser && String(raid.lastHitUser) === String(r.userKey)) addGold += raidRewards.WEEKLY.lastHitGold;

      if (addGold > 0) u.gold = (Number(u.gold) || 0) + addGold;
    }

    raid.paidWeekKey = wk;
    raid.paidAt = Date.now();

    const top = winners.top3;
    const lines = [];
    lines.push('🏁 *RAID — Semana encerrada*');
    lines.push(`Boss: ${raid.bossName}`);
    lines.push('');
    lines.push('🥇 *Top 3 dano*');
    for (let i = 0; i < top.length; i++) {
      const r = top[i];
      lines.push(`${i + 1}. ${String(r.userKey)} — ${fmtGold(r.dmg)} dmg`);
    }
    lines.push('');
    lines.push(`✅ Participação: ${fmtGold(raidRewards.WEEKLY.participationGold)} ouro (dano ≥ ${fmtGold(raidRewards.DAILY.minDmgForParticipation)})`);
    lines.push(`🎯 Último golpe: ${fmtGold(raidRewards.WEEKLY.lastHitGold)} ouro`);
    lines.push('');
    lines.push('➡️ Nova semana começou automaticamente.');

    return lines.join('\n');
  } catch (_) {
    try { raid.paidWeekKey = String(raid?.weekKey || weekKeyNow()); } catch (__e) {}
    return null;
  }
}

function __raidRankText(raid, prefix) {
  const lines = [];
  lines.push('🐲 *RAID DO CHAT*');
  if (!raid) {
    lines.push('Nada ativo agora.');
    lines.push(`Use: *${prefix}raid*`);
    return lines.join('\n');
  }
  lines.push(`Semana: ${raid.weekKey}`);
  lines.push(`Boss: ${raid.bossName}`);
  lines.push(hpBar(raid.hp, raid.hpMax));
  lines.push('');

  const winners = raidRewards.computeWeeklyWinners(raid.contrib || {});
  const top = winners.top;
  lines.push('🏆 *Ranking (Top 10)*');
  if (!top.length) lines.push('• (ninguém ainda)');
  else {
    for (let i = 0; i < top.length; i++) {
      const r = top[i];
      lines.push(`${i + 1}. ${String(r.userKey)} — ${fmtGold(r.dmg)} dmg`);
    }
  }
  lines.push('');
  lines.push(`Ataque: *${prefix}raid*`);
  return lines.join('\n');
}

function __calcRaidDamage(user, seed) {
  const lvl = Math.max(1, Number(user?.lvl || 1));
  const base = 60 + (lvl * 12);
  const varr = randInt(0, Math.max(12, lvl * 6), seed);
  return Math.max(25, base + varr);
}

async function handleRaid(msg, store, user, chatId, prefix, args) {
  const a0 = String((args && args[0]) || '').trim().toLowerCase();

  const ensured = __ensureRaid(store, chatId);
  const raid = ensured.raid;
  const weeklyClosedText = ensured.weeklyClosedText;

  // Se fechou semana anterior, avisa 1x no mesmo comando
  if (weeklyClosedText) {
    __scheduleWrite();
    try { await msg.reply(weeklyClosedText); } catch (_) {}
  }

  if (a0 === 'rank' || a0 === 'ranking' || a0 === 'top') {
    return msg.reply(__raidRankText(store.raids?.[chatId] || raid, prefix));
  }

  // Painel rápido
  if (a0 === 'info' || a0 === 'status') {
    return msg.reply(__raidRankText(raid, prefix));
  }

  if (!raid) {
    // acabou de fechar e ainda não criou novo (o próximo ataque cria)
    const ensured2 = __ensureRaid(store, chatId);
    return msg.reply(__raidRankText(ensured2.raid, prefix));
  }

  if (raid.defeated) {
    return msg.reply(`🏁 O raid desta semana já foi derrotado.\nUse *${prefix}raid rank* para ver o ranking.`);
  }

  // cooldown por usuário
  const left = avtempos.leftMs(user.lastRaidAt || 0, avtempos.CD.raidAttack || 10_000);
  if (left > 0) return msg.reply(`⏳ Aguarde ${avtempos.fmt(left)} para atacar de novo.`);

  user.lastRaidAt = Date.now();

  const seed = makeStableSeedFromParts(user.__key, 'raid', raid.weekKey, user.lastRaidAt);
  const dmg = __calcRaidDamage(user, seed);
  raid.hp = Math.max(0, Number(raid.hp || 0) - dmg);

  // contrib
  if (!raid.contrib || typeof raid.contrib !== 'object') raid.contrib = {};
  const row = raid.contrib[user.__key] || { dmg: 0, lastAt: 0, dayKey: null, dayGold: 0 };
  row.dmg = Math.max(0, Number(row.dmg || 0) + dmg);
  row.lastAt = Date.now();

  // recompensa diária leve (anti-abuso)
  const dk = dateKeyNow();
  if (row.dayKey !== dk) {
    row.dayKey = dk;
    row.dayGold = 0;
  }
  const rawGold = Math.floor(clamp(dmg / 3, 15, 120));
  const canAdd = raidRewards.clampDailyGold((Number(row.dayGold) || 0) + rawGold);
  const addGold = Math.max(0, canAdd - (Number(row.dayGold) || 0));
  if (addGold > 0) {
    user.gold = (Number(user.gold) || 0) + addGold;
    row.dayGold = (Number(row.dayGold) || 0) + addGold;
  }

  raid.contrib[user.__key] = row;

  let extra = '';
  if (raid.hp <= 0) {
    raid.defeated = true;
    raid.defeatedAt = Date.now();
    raid.lastHitUser = user.__key;
    extra = `\n\n🏁 *DERROTADO!*\nÚltimo golpe: ${displayNameToShort(user)} (+${fmtGold(raidRewards.WEEKLY.lastHitGold)} ouro na semana)`;
  }

  __scheduleWrite();

  return msg.reply(
    `🐲 *RAID*\n` +
    `${raid.bossName}\n` +
    `${hpBar(raid.hp, raid.hpMax)}\n\n` +
    `🗡️ Dano: *${fmtGold(dmg)}*\n` +
    `🏆 Seu total: *${fmtGold(row.dmg)}*\n` +
    (addGold > 0 ? `💰 Ouro (dia): +${fmtGold(addGold)}\n` : '') +
    `⏳ CD: ${avtempos.fmt(avtempos.CD.raidAttack || 10_000)}` +
    extra
  );
}

function displayNameToShort(user) {
  // evita flood com nome gigante
  const n = String(user?.name || 'Jogador').trim();
  if (!n) return 'Jogador';
  if (n.length <= 18) return n;
  return n.slice(0, 18).trim() + '…';
}

function painelRegioes(user, prefix) {
  const reg = getRegiao(user);
  const lines = [];
  lines.push('🗺️ *REGIÕES*');
  lines.push(`Atual: ${reg.name}`);
  {
    const st = regioes.ensureBiomeState(user);
    const prog = clamp(Number(st?.progress || 0), 0, 100);
    const next = regioes.getNextMilestone(user);
    lines.push(`Progresso: ${prog}%${next ? ` • Próx: ${next.pct}%` : ''}`);
  }
  lines.push('');
  lines.push('Escolha uma região:');
  const all = regioes.listBiomes();
  all.forEach((r, i) => {
    lines.push(`${i + 1}) ${r.name} — ${r.rec} • Risco: ${r.risco}`);
  });
  lines.push('');
  lines.push(`Use: *${prefix}avregiao 1* (ou 2, 3, 4)`);

  const rc = ensureRegiaoContrato(user);
  if (rc && rc.regionKey === reg.key) {
    lines.push('');
    lines.push(`📜 ${rc.title}`);
    lines.push(`• ${rc.desc}`);
    lines.push(`• Progresso: ${Math.min(rc.goal, Number(rc.progress || 0))}/${rc.goal}`);
    if (rc.done && !rc.claimed) lines.push(`• Resgatar: *${prefix}avregiao resgatar*`);
    else lines.push(`• Ver: *${prefix}avregiao contrato*`);
  }

  const wc = ensureRegiaoContratoSemanal(user);
  if (wc && wc.regionKey === reg.key) {
    lines.push('');
    lines.push(`🧨 ${wc.title}`);
    lines.push(`• Progresso: ${Math.min(wc.goal, Number(wc.progress || 0))}/${wc.goal}`);
    if (wc.done && !wc.claimed) lines.push(`• Resgatar: *${prefix}avregiao resgatarsemanal*`);
    else lines.push(`• Ver: *${prefix}avregiao semanal*`);
  }

  return lines.join('\n');
}

function painelContratoRegiao(user, prefix, rc) {
  const reg = getRegiao(user);
  const c = rc && typeof rc === 'object' ? rc : ensureRegiaoContrato(user);
  const lines = [];
  const isWeekly = !!c.weekKey;
  lines.push(isWeekly ? '📜 *CONTRATO DIFÍCIL (SEMANAL)*' : '📜 *CONTRATO DA REGIÃO*');
  lines.push(reg.name);
  lines.push('');
  lines.push(`• ${c.desc}`);
  lines.push(`• Progresso: ${Math.min(c.goal, Number(c.progress || 0))}/${c.goal}`);
  lines.push(`• Recompensa: ${fmtGold(c.rewardGold)} ouro${(!isWeekly && Number(c.streak) > 0) ? ` • Streak ${c.streak}d` : ''}`);
  if (c.done && !c.claimed) {
    lines.push(`• Resgatar: *${prefix}avregiao ${isWeekly ? 'resgatarsemanal' : 'resgatar'}*`);
  }
  else if (c.claimed) lines.push('• Status: resgatado');
  else lines.push('• Status: em andamento');
  return lines.join('\n');
}

function painelEstilos(user, prefix) {
  const cur = String(user.estilo || 'equilibrado');
  const lines = [];
  lines.push('⚔️ *ESTILO DE COMBATE*');
  lines.push(`Atual: *${cur === 'ofensivo' ? 'Ofensivo' : cur === 'defensivo' ? 'Defensivo' : 'Equilibrado'}*`);
  lines.push('');
  lines.push('Escolha:');
  lines.push('1) Ofensivo — mais dano, mais risco');
  lines.push('2) Defensivo — aguenta mais, menos dano');
  lines.push('3) Equilibrado — estável');
  lines.push('');
  lines.push(`Use: *${prefix}avestilo 1* (ou 2, 3)`);
  return lines.join('\n');
}

async function resolveAdventureTarget(client, msg, args, chat) {
  const targets = await whatsappSafe.resolveTargetsFromMsg(client, msg, null, args, chat);
  const raw = (Array.isArray(targets) && targets.length) ? targets[0] : null;
  if (!raw) return null;

  const resolved = await whatsappSafe.resolveCanonicalUserFromAnyJid(client, raw, chat);
  const phone = resolved?.phone ? String(resolved.phone).replace(/\D/g, '') : null;
  if (!phone) return null;

  const mention = whatsappSafe.buildMentionText(
    resolved?.jidCanonical || `${phone}@c.us`,
    resolved?.displayName || phone,
    'aventureiro'
  );

  return {
    raw,
    phone,
    jid: resolved?.jidCanonical || `${phone}@c.us`,
    displayName: resolved?.displayName || phone,
    mention,
  };
}

function getRobGoldChance(user, targetUser) {
  const me = computeBaseStats(user);
  const target = computeBaseStats(targetUser);

  const myPower =
    (Number(me.hp) || 0) * 0.08 +
    (Number(me.atk) || 0) * 2.4 +
    (Number(me.def) || 0) * 1.8 +
    (Math.max(1, Number(user?.lvl) || 1) * 5) +
    (Math.max(0, Number(user?.fama) || 0) * 0.35);

  const targetPower =
    (Number(target.hp) || 0) * 0.08 +
    (Number(target.atk) || 0) * 2.4 +
    (Number(target.def) || 0) * 1.8 +
    (Math.max(1, Number(targetUser?.lvl) || 1) * 5) +
    (Math.max(0, Number(targetUser?.fama) || 0) * 0.35);

  const chance = 0.5 + ((myPower - targetPower) / 220);
  return clamp(chance, 0.18, 0.82);
}

function applyGuardarGold(user, val) {
  const amount = Math.max(0, Math.floor(Number(val) || 0));
  if (amount <= 0) {
    return { ok: false, code: 'INVALID_AMOUNT' };
  }

  const taxa = Math.max(0, Math.round(amount * 0.02));
  const total = amount + taxa;
  if ((Number(user.gold) || 0) < total) {
    return { ok: false, code: 'INSUFFICIENT_GOLD', amount, taxa, total };
  }

  user.gold = Math.max(0, (Number(user.gold) || 0) - total);
  user.cofre = (Number(user.cofre) || 0) + amount;
  return { ok: true, amount, taxa, total };
}

function applySacarGold(user, val) {
  const amount = Math.max(0, Math.floor(Number(val) || 0));
  if (amount <= 0) {
    return { ok: false, code: 'INVALID_AMOUNT' };
  }

  if ((Number(user.cofre) || 0) < amount) {
    return { ok: false, code: 'INSUFFICIENT_VAULT', amount };
  }

  user.cofre = Math.max(0, (Number(user.cofre) || 0) - amount);
  user.gold = (Number(user.gold) || 0) + amount;
  return { ok: true, amount };
}

function painelCofre(user, prefix) {
  const lines = [];
  lines.push('🏛️ *COFRE PESSOAL*');
  lines.push(`Carteira: *${fmtGold(user.gold)}g*`);
  lines.push(`Cofre: *${fmtGold(user.cofre)}g*`);
  lines.push('');
  lines.push('Ações:');
  lines.push(`• ${prefix}guardargold 1000`);
  lines.push(`• ${prefix}avcofre sacar 500`);
  lines.push('');
  lines.push('Ouro no cofre fica protegido e não entra no !roubargold.');
  return lines.join('\n');
}

function painelMapa(prefix) {
  const lines = [];
  lines.push('🗺️ *MAPA DO MUNDO*');
  lines.push('🌲 Floresta Sombria — Nível 1–3');
  lines.push('🏔 Montanhas Quebradas — Nível 3–6');
  lines.push('🏰 Ruínas Antigas — Nível 6–10');
  lines.push('🌋 Terras Ardentes — Nível 10+');
  lines.push('');
  lines.push(`Ação: *${prefix}avregiao*`);
  return lines.join('\n');
}

function painelPreparar(user, prefix) {
  const st = computeBaseStats(user);
  const lines = [];
  lines.push('🛡️ *PREPARO*');
  lines.push(`Vida: *${st.hp}*`);
  if (isFerido(user)) lines.push(`Recuperação: ${avtempos.fmt(feridoLeft(user))}`);
  const potSmall = invCount(user, 'POT_PEQ');
  const potMed = invCount(user, 'POT_MED');
  const potBig = invCount(user, 'POT_GRA');
  lines.push(`Poções: Pequena ${potSmall} • Média ${potMed} • Grande ${potBig}`);
  lines.push(`Equipado: ${formatEquippedShort(user)}`);
  lines.push('');
  if (isFerido(user)) lines.push(`Sugestão: use *${prefix}avusar Poção Pequena* ou espere recuperar.`);
  else lines.push(`Sugestão: leve poções e ajuste seu estilo em *${prefix}avestilo*.`);
  return lines.join('\n');
}

function formatEquippedShort(user) {
  const w = user.equip?.weapon ? itemName(user.equip.weapon) : 'Arma básica';
  const a = user.equip?.armor ? itemName(user.equip.armor) : 'Armadura simples';
  const c = user.equip?.acc ? itemName(user.equip.acc) : 'Sem acessório';
  return `${w} • ${a} • ${c}`;
}
module.exports = async function aventura(client, msg, config, cmd, args, audit, ctx, extra = {}) {
  const store = await __loadStore();
  const userKey = getUserKey(ctx, msg);
  const chatId = await getChatKey(msg);
  const prefix = (config && config.prefix) ? String(config.prefix) : '!';
  const displayName = getDisplayName(ctx, msg, extra);

  cleanupExpiredTrades(store);
  cleanupMarket(store);

  const c = String(cmd || '').toLowerCase().trim();

  // 🌟 Central anti-perdido
  if (c === 'avmeu' || c === 'meuav') {
    const user = ensureUser(store, userKey);
    user.__key = userKey;
    ensureSeason(store);
    maybeStartChatEvent(store, chatId, String(userKey) + ':' + dateKeyNow());

    const displayName =
      (ctx && (ctx.requesterName || ctx.pushName || ctx.senderName)) ||
      (extra && (extra.requesterName || extra.pushName)) ||
      (msg && (msg.pushName || msg.senderName)) ||
      getDisplayName(ctx, msg, extra);

    const text = painelMeuAv(store, user, chatId, prefix, displayName);
    __scheduleWrite();
    return msg.reply(text);
  }

  if (c === 'avevento') {
    ensureSeason(store);
    const text = painelEvento(store, chatId, prefix);
    return msg.reply(text);
  }

  if (c === 'avmapa') {
    return msg.reply(painelMapa(prefix));
  }

  if (c === 'raid' || c === 'avraid') {
    const user = ensureUser(store, userKey);
    user.__key = userKey;
    return handleRaid(msg, store, user, chatId, prefix, args);
  }

  if (c === 'avregiao') {
    const user = ensureUser(store, userKey);
    user.__key = userKey;

    const a0 = String((args && args[0]) || '').trim();
    const sub = a0.toLowerCase();

    // Painel padrão
    if (!sub) {
      ensureRegiaoContrato(user);
      __scheduleWrite();
      return msg.reply(painelRegioes(user, prefix));
    }

    // Contrato da região (integrado aqui)
    if (sub === 'contrato') {
      const rc = ensureRegiaoContrato(user);
      __scheduleWrite();
      return msg.reply(painelContratoRegiao(user, prefix, rc));
    }

    if (sub === 'semanal') {
      const wc = ensureRegiaoContratoSemanal(user);
      __scheduleWrite();
      return msg.reply(painelContratoRegiao(user, prefix, wc));
    }

    if (sub === 'resgatar') {
      const rc = ensureRegiaoContrato(user);
      if (!rc.done) return msg.reply('📜 Seu contrato ainda não está pronto.');
      if (rc.claimed) return msg.reply('📜 Você já resgatou o contrato de hoje nesta região.');
      rc.claimed = true;
      user.gold += Math.max(1, Number(rc.rewardGold) || 0);
      // Fama leve por contrato
      user.fama = (Number(user.fama) || 0) + 1;
      if (user.regionStreak && typeof user.regionStreak === 'object') user.regionStreak.lastDoneDayKey = rc.dayKey;
      __scheduleWrite();
      return msg.reply(`🏆 Contrato resgatado! +${fmtGold(rc.rewardGold)} ouro`);
    }

    if (sub === 'resgatarsemanal' || sub === 'resgatar-semanal' || sub === 'resgatarsem') {
      const wc = ensureRegiaoContratoSemanal(user);
      if (!wc.done) return msg.reply('📜 Seu contrato semanal ainda não está pronto.');
      if (wc.claimed) return msg.reply('📜 Você já resgatou o contrato semanal desta região.');
      wc.claimed = true;
      user.gold += Math.max(1, Number(wc.rewardGold) || 0);
      user.fama = (Number(user.fama) || 0) + 2;
      __scheduleWrite();
      return msg.reply(`🏆 Semanal resgatado! +${fmtGold(wc.rewardGold)} ouro`);
    }

    // Escolha por número
    const n = Number(sub);
    if (!n) {
      ensureRegiaoContrato(user);
      __scheduleWrite();
      return msg.reply(painelRegioes(user, prefix));
    }

    const all = regioes.listBiomes();
    const idx = Math.max(1, Math.min(all.length, Math.floor(n))) - 1;
    regioes.setBiome(user, all[idx].key);
    user.encounter = null;

    ensureRegiaoContrato(user);
    ensureRegiaoContratoSemanal(user);
    __scheduleWrite();
    return msg.reply(`🧭 Região definida: ${all[idx].name}
📜 Dica: *${prefix}avregiao contrato*`);
  }

  if (c === 'avestilo') {
    const user = ensureUser(store, userKey);
    user.__key = userKey;
    const n = Number(args && args[0]);
    if (!n) return msg.reply(painelEstilos(user, prefix));
    const pick = (n === 1) ? 'ofensivo' : (n === 2) ? 'defensivo' : 'equilibrado';
    user.estilo = pick;
    __scheduleWrite();
    return msg.reply(`⚔️ Estilo ajustado: *${pick === 'ofensivo' ? 'Ofensivo' : pick === 'defensivo' ? 'Defensivo' : 'Equilibrado'}*`);
  }

  if (c === 'avcofre') {
    const user = ensureUser(store, userKey);
    user.__key = userKey;
    const sub = String(args && args[0] || '').toLowerCase();
    if (!sub) return msg.reply(painelCofre(user, prefix));

    const amountArg = String(args && args[1] || '').trim();
    const sourceAvailable = (sub === 'guardar') ? (Number(user.gold) || 0) : (Number(user.cofre) || 0);
    const val = parseGoldAmount(amountArg, sourceAvailable);
    if (val <= 0) return msg.reply(`Use: *${prefix}avcofre guardar 1000*`);

    if (sub === 'guardar') {
      const out = applyGuardarGold(user, val);
      if (!out.ok) return msg.reply(`Você precisa de *${fmtGold(out.total)}g* (inclui taxa ${fmtGold(out.taxa)}g).`);
      __scheduleWrite();
      return msg.reply(`🏛️ Guardado: *${fmtGold(out.amount)}g* (taxa ${fmtGold(out.taxa)}g).`);
    }

    if (sub === 'sacar') {
      const out = applySacarGold(user, val);
      if (!out.ok) return msg.reply('Você não tem esse valor no cofre.');
      __scheduleWrite();
      return msg.reply(`💰 Sacado do cofre: *${fmtGold(out.amount)}g*.`);
    }

    return msg.reply(painelCofre(user, prefix));
  }

  if (c === 'guardargold') {
    const user = ensureUser(store, userKey);
    user.__key = userKey;

    const amountArg = String((args && args[args.length - 1]) || '').trim();
    const val = parseGoldAmount(amountArg, Number(user.gold) || 0);
    if (val <= 0) return msg.reply(`Use: *${prefix}guardargold 1000*`);

    const out = applyGuardarGold(user, val);
    if (!out.ok) {
      return msg.reply(`❌ Você precisa de *${fmtGold(out.total)}g* para guardar *${fmtGold(out.amount)}g* (taxa ${fmtGold(out.taxa)}g).`);
    }

    pushHistorico(user, `Guardou ${fmtGold(out.amount)}g no cofre.`);
    __scheduleWrite();
    return msg.reply(
      `🏛️ Ouro protegido: *${fmtGold(out.amount)}g* guardados no cofre.
` +
      `💸 Taxa: *${fmtGold(out.taxa)}g*
` +
      `🛡️ O valor no cofre não pode ser levado no *${prefix}roubargold*.`
    );
  }

  if (c === 'enviargold') {
    if (!(ctx && ctx.isBotOwner)) {
      return msg.reply('⛔ Apenas o dono do bot pode usar este comando.');
    }

    const chat = await whatsappSafe.safeGetChatFromMessage(msg);
    const target = await resolveAdventureTarget(client, msg, args, chat);
    if (!target) {
      return msg.reply(`Use: *${prefix}enviargold @marcar 1000*\nOu responda a mensagem da pessoa com o valor.`);
    }

    const amountArg = String((args && args[args.length - 1]) || '').trim();
    const val = parseGoldAmount(amountArg);
    if (val <= 0) {
      return msg.reply(`Use: *${prefix}enviargold @marcar 1000*`);
    }

    const targetUser = ensureUser(store, target.phone);
    targetUser.__key = target.phone;
    targetUser.gold = (Number(targetUser.gold) || 0) + val;

    pushHistorico(targetUser, `Recebeu ${fmtGold(val)}g do dono do bot.`);
    __scheduleWrite();

    const mentionOpts = (target.mention?.mentions && target.mention.mentions.length)
      ? { mentions: target.mention.mentions }
      : undefined;

    return msg.reply(
      `👑 ${target.mention?.tag || '@aventureiro'} recebeu *${fmtGold(val)}g* na carteira da aventura.`,
      undefined,
      mentionOpts
    );
  }

  if (c === 'roubargold') {
    const user = ensureUser(store, userKey);
    user.__key = userKey;

    if (isFerido(user)) {
      return msg.reply(`🩹 Você ainda está se recuperando. Volte em ${avtempos.fmt(feridoLeft(user))}.`);
    }

    const robCd = Math.max(1, Number(avtempos?.CD?.robGold || (5 * 60 * 1000)));
    const robLeft = avtempos.leftMs(user.lastRobGoldAt, robCd);
    if (robLeft > 0) {
      return msg.reply(`⏳ Você precisa esperar ${avtempos.fmt(robLeft)} para tentar roubar ouro de novo.`);
    }

    const chat = await whatsappSafe.safeGetChatFromMessage(msg);
    const target = await resolveAdventureTarget(client, msg, args, chat);
    if (!target) {
      return msg.reply(`Use: *${prefix}roubargold @marcar*\nOu responda a mensagem do alvo.`);
    }

    if (String(target.phone) === String(userKey)) {
      return msg.reply('❌ Você não pode roubar o próprio ouro.');
    }

    const targetUser = ensureUser(store, target.phone);
    targetUser.__key = target.phone;

    const wallet = Math.max(0, Math.floor(Number(targetUser.gold) || 0));
    if (wallet <= 0) {
      const mentionOpts = (target.mention?.mentions && target.mention.mentions.length)
        ? { mentions: target.mention.mentions }
        : undefined;
      return msg.reply(
        `🪙 ${target.mention?.tag || '@aventureiro'} está sem ouro na bolsa. Ouro guardado no cofre não entra no roubo.`,
        undefined,
        mentionOpts
      );
    }

    const chance = getRobGoldChance(user, targetUser);
    const seed = makeStableSeedFromParts(user.__key, 'roubargold', target.phone, wallet, Date.now());
    const roll = randInt(1, 1000, seed) / 1000;
    const mentionOpts = (target.mention?.mentions && target.mention.mentions.length)
      ? { mentions: target.mention.mentions }
      : undefined;

    user.lastRobGoldAt = Date.now();

    if (roll <= chance) {
      const pct = randInt(8, 18, seed) / 100;
      const amount = Math.max(1, Math.min(wallet, Math.floor(wallet * pct)));

      targetUser.gold = Math.max(0, wallet - amount);
      user.gold = (Number(user.gold) || 0) + amount;

      pushHistorico(user, `Roubou ${fmtGold(amount)}g de ${target.displayName || target.phone}.`);
      pushHistorico(targetUser, `Perdeu ${fmtGold(amount)}g para um ladrão.`);
      __scheduleWrite();

      return msg.reply(
        `🗡️ Golpe certo. Você levou *${fmtGold(amount)}g* de ${target.mention?.tag || '@aventureiro'}.\n` +
        `💼 O cofre do alvo continua protegido.`,
        undefined,
        mentionOpts
      );
    }

    const penaltyBase = Math.max(0, Math.floor(Number(user.gold) || 0));
    const penalty = Math.min(penaltyBase, Math.max(0, randInt(15, 60, seed)));
    if (penalty > 0) {
      user.gold = Math.max(0, penaltyBase - penalty);
      targetUser.gold = (Number(targetUser.gold) || 0) + penalty;
    }

    pushHistorico(user, `Falhou ao tentar roubar ${target.displayName || target.phone}.`);
    pushHistorico(targetUser, `Percebeu uma tentativa de roubo e recuperou ${fmtGold(penalty)}g.`);
    __scheduleWrite();

    const failExtra = penalty > 0
      ? `\n💸 Você deixou *${fmtGold(penalty)}g* cair na fuga.`
      : '';

    return msg.reply(
      `🚨 ${target.mention?.tag || '@aventureiro'} percebeu o roubo e protegeu a bolsa.` + failExtra,
      undefined,
      mentionOpts
    );
  }

  if (c === 'avpreparar') {
    const user = ensureUser(store, userKey);
    user.__key = userKey;
    return msg.reply(painelPreparar(user, prefix));
  }

  if (c === 'avhistorico') {
    const user = ensureUser(store, userKey);
    user.__key = userKey;
    const hist = Array.isArray(user.historico) ? user.historico : [];
    const lines = [];
    lines.push('📜 *HISTÓRICO*');
    if (hist.length === 0) {
      lines.push('Sem batalhas recentes.');
    } else {
      for (const h of hist) lines.push(`• ${h.text}`);
    }
    return msg.reply(lines.join('\n'));
  }

  if (c === 'avprestigio') {
    const user = ensureUser(store, userKey);
    user.__key = userKey;
    const need = 30;
    if (user.lvl < need) return msg.reply(`✨ Prestígio abre no nível ${need}. Você está no nível ${user.lvl}.`);
    const sub = String(args && args[0] || '').toLowerCase();
    if (sub !== 'confirmar') {
      return msg.reply(
        '✨ *PRESTÍGIO*\n' +
        'Recomece mais forte e ganhe um título.\n\n' +
        'Ao prestigiar:\n' +
        '• Seu nível volta para 1\n' +
        '• Você ganha um bônus leve permanente\n\n' +
        `Use: *${prefix}avprestigio confirmar*`
      );
    }
    user.prestigio = (Number(user.prestigio) || 0) + 1;
    user.lvl = 1;
    user.xp = 0;
    user.encounter = null;
    user.battleLite = null;
    user.battle = null;
    user.hunt = { streak: 0, best: (user.hunt?.best || 0) };
    user.titulo = 'Lenda Renascida';
    __scheduleWrite();
    return msg.reply('✨ Você prestigiou! Agora você volta ao início, mas com mais presença no mundo.');
  }

  // 🧭 Início oficial da Aventura
  if (c === 'aventura') {
    const existing = getUserIfExists(store, userKey);
    if (!existing) {
      const user = ensureUser(store, userKey);
      user.__key = userKey;
      __scheduleWrite();
      return msg.reply(`🧭 AVENTURA INICIADA\n\n✨ ${displayName}, sua jornada começou.\n\n📌 Próximos passos:\n• ${prefix}avperfil\n• ${prefix}classe\n• ${prefix}avexp\n• ${prefix}boss`);
    }

    return msg.reply(`ℹ️ ${displayName}, você já faz parte da Aventura.\n\nUse:\n• ${prefix}avperfil\n• ${prefix}avexp`);
  }

  const user = getUserIfExists(store, userKey);
  if (!user) {
    return msg.reply(`🧭 ${displayName}, você ainda não iniciou a Aventura.\nUse: ${prefix}aventura`);
  }
  user.__key = userKey;

  // ROUTER
  if (c === 'classe') return handleClasse(msg, store, user, prefix, args);
  if (c === 'craft') return handleCraft(msg, store, user, prefix, args);

  // Lojas
  if (c === 'emporio') return handleEmporio(msg, store, user, prefix, args);
  if (c === 'leilao' || c === 'avmercado') return handleLeilao(msg, store, user, prefix, args);
  if (c === 'adquirir') return handleAdquirir(msg, store, user, prefix, args);
  if (c === 'liquidar') return handleLiquidar(msg, store, user, prefix, args);
  if (c === 'trocaritem') return handleTrocarItem(msg, store, user, prefix, args, ctx, extra);

  // Caça (progressão) — exatamente como no AVENTURA_COMMANDS (somente av*)
  if (c === 'avcacar' || c === 'avcaçar') return handleCacar(msg, store, user, prefix);
  if (c === 'avatacar') return user.dark?.encounter ? handleAvAtk(msg, store, user, prefix) : handleAtacar(msg, store, user, prefix);
  if (c === 'avfugir') return user.dark?.encounter ? handleAvRun(msg, store, user, prefix) : handleFugir(msg, store, user, prefix);
  if (c === 'avusar') {
    const firstArg = String(args?.[0] || '').trim();
    const isIndexedDarkUse = /^\d+$/.test(firstArg);
    if (user.dark?.encounter || isIndexedDarkUse) return handleAvUse(msg, store, user, prefix, args);
    return handleUsar(msg, store, user, prefix, args);
  }

  // Combate
  if (c === 'boss') return handleBoss(msg, store, user, prefix, args, chatId, displayName);
  if (c === 'matarboss' || c === 'matarboos') return handleMatarBoss(msg, store, user, prefix, args, chatId, displayName);
  if (c === 'arena') return handleArena(client, msg, store, user, prefix, args, audit, ctx, extra);
  if (c === 'explorar') return handleExplorar(msg, store, user, prefix, args);

  // NOCTHARIA (DARK)
  if (c === 'avexp') {
    // Default: explorar mapa/bioma (AV-001)
    // Para o MUNDO SOMBRIO: use "avexp dark"
    const a0 = String((args && args[0]) || '').trim().toLowerCase();
    if (a0 === 'dark' || a0 === 'sombras' || a0 === 'noctharia') {
      return handleAvExp(msg, store, user, prefix);
    }
    return handleExplorar(msg, store, user, prefix, args);
  }
  if (c === 'avskill') return handleAvSkill(msg, store, user, prefix, args);
  if (c === 'avdg') return handleAvDg(msg, store, user, prefix, args);
  if (c === 'avinv') return handleAvInv(msg, store, user, prefix);
  if (c === 'avequip') return handleAvEquip(msg, store, user, prefix, args);
  if (c === 'avrank') return handleAvRank(client, msg, store, user, prefix, args);
  if (c === 'avcorr') return handleAvCorr(msg, store, user, prefix);
  if (c === 'avpurificar') return handleAvPurificar(msg, store, user, prefix);

  // Perfil
  if (c === 'avperfil') return handleAvPerfil(msg, store, user, prefix, displayName);
  if (c === 'mochila' || c === 'bag') return handleMochila(msg, store, user, prefix);

  // Contrato diário e mercador
  if (c === 'avcontrato' || c === 'contrato') return handleContrato(msg, store, user, prefix, args);
  if (c === 'avvender' || c === 'venderrapido') return handleVenderGuilda(msg, store, user, prefix, args);

  await msg.reply(`⚠️ Aventura: Invocação desconhecida. Tente *${prefix}boss* ou *${prefix}avperfil*`);
};



// =========================
// TROCAR ITEM (placeholder simples - mantém compatibilidade)
// =========================
function handleTrocarItem(msg, store, user, prefix, args, ctx, extra) {
  return msg.reply('⚠️ A troca direta ainda não foi aberta neste tomo.');
}