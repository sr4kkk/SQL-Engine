// commands/menu.js
// ====== PREFIXOS DO BOT ======
const { prefixes } = require('../../core/bot/prefixes');
const loader = require('../../core/loader');
const registry = require('../../core/cmd/commandRegistry');

const LINE = '━━━━━━━━';

function renderCommandList(prefix, list, { columns = 3, max = 300 } = {}) {
    const arr = Array.isArray(list) ? list.filter(Boolean) : [];
    const uniq = Array.from(new Set(arr.map(v => String(v).trim()).filter(Boolean)));
    const items = uniq.slice(0, Math.max(0, Number(max) || 0));

    if (!items.length) return '—';

    const cols = Math.max(1, Math.min(6, Number(columns) || 3));
    const rows = Math.ceil(items.length / cols);

    const lines = [];
    for (let r = 0; r < rows; r++) {
        const parts = [];
        for (let c = 0; c < cols; c++) {
            const i = r + (c * rows);
            if (i >= items.length) continue;
            parts.push(`${prefix}${items[i]}`);
        }
        if (parts.length) lines.push(`• ${parts.join('   ')}`);
    }
    return lines.join('\n');
}


// =============================================================
// PREFIXOS / HEADER
// =============================================================
function getPrimaryPrefix(context) {
    const config = (context && context.config) || {};

    if (
        config.prefix &&
        typeof config.prefix === 'string' &&
        config.prefix.trim().length > 0
    ) {
        return config.prefix.trim();
    }

    if (Array.isArray(prefixes) && prefixes.length > 0) {
        return prefixes[0];
    }

    return '!';
}

function getAllPrefixesText(context) {
    const primary = getPrimaryPrefix(context);
    const list = Array.isArray(prefixes) && prefixes.length > 0 ? prefixes : [primary];
    const uniq = [...new Set(list)];
    return uniq.join(' ');
}

function buildPrefixesReply(context) {
    const allPrefixesText = getAllPrefixesText(context);
    return `📌 Meus prefixos: ${allPrefixesText}`;
}

/**
 * HEADER padrão para todos os menus
 * Reutilizado em: menu principal, RP, cassino, admin, dono, bot.
 */
function buildHeader(context) {
    const { requesterName, isGroup, chatName, config } = context || {};
    const botName = (config && config.botName) || 'Bot';

    const primaryPrefix = getPrimaryPrefix(context);
    const allPrefixesText = getAllPrefixesText(context);

    const linhas = [];

    linhas.push(`🤖 ${botName}`);
    if (isGroup) {
        linhas.push(`👥 Grupo: ${chatName || 'Grupo'}`);
    } else {
        linhas.push('💬 Chat privado');
    }

    if (requesterName) {
        linhas.push(`🙋 Usuário: ${requesterName}`);
    }

    linhas.push(`📌 Prefixos: ${allPrefixesText} (principal: ${primaryPrefix})`);
    linhas.push(LINE);

    return linhas.join('\n');
}

// =============================================================
// MENU PRINCIPAL
// =============================================================
function buildMainMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    return `
${header}

📚 *MENU PRINCIPAL*

📂 *Navegação*
• ${prefix}menujogos
• ${prefix}menufigurinhas
• ${prefix}menuaudio
• ${prefix}menuutil
• ${prefix}menuadm
• ${prefix}menudono
• ${prefix}menubot
• ${prefix}menu18

${LINE}
`.trim();
}

function buildUtilidadesMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    return `
${header}

🛠️ *MENU UTILIDADES*

📂 *Acesso rápido*
• ${prefix}menu — voltar ao menu principal
• ${prefix}menuutil — abrir este menu

${LINE}

🧮 *Cálculos*
• ${prefix}calc [expressão]
  Ex: ${prefix}calc 2 + 2 * 50
📌 Resolve contas com +, -, *, / e parênteses.

${LINE}

🌤️ *Clima e tempo*
• ${prefix}clima [cidade]
  Ex: ${prefix}clima Rio de Janeiro
📌 Mostra temperatura atual, sensação térmica e condição climática.

${LINE}

⚡ *Diagnóstico*
• ${prefix}ping
📌 Mede a latência de resposta do bot em ms.

${LINE}
`.trim();
}

function buildMenu18(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    const adultoConfigList = Array.isArray(registry?.ADULTO_CONFIG_COMMANDS) ? registry.ADULTO_CONFIG_COMMANDS : [];
    const adultoList = Array.isArray(registry?.ADULTO_COMMANDS) ? registry.ADULTO_COMMANDS : [];

    return `
${header}

🔞 *MENU 18*

🛡️ *Controle do modo adulto*
${renderCommandList(prefix, adultoConfigList, { columns: 2, max: 20 })}

🔥 *Comandos +18*
${renderCommandList(prefix, adultoList, { columns: 2, max: 40 })}

📌 *Uso rápido*
• ${prefix}xvideos <pesquisa|link|número>
• ${prefix}pornohub <pesquisa|link|número>
• ${prefix}hentai <categoria|pesquisa>
• ${prefix}hentaiteca <nome|top|pdf>

${LINE}
`.trim();
}

// =============================================================
// MENU JOGOS (hub simples)
// =============================================================
function buildJogosMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    const rpStatus = context.group?.rpEnabled ? '🟢 ATIVO' : '🔴 DESATIVADO';
    const avStatus = context.group?.aventuraEnabled ? '🟢 ATIVO' : '🔴 DESATIVADO';
    const simsStatus = context.group?.simsEnabled ? '🟢 ATIVO' : '🔴 DESATIVADO';

    return `
${header}

🎮 *MULTIVERSO PALMINHA*
━━━━━━━━━━━━

🌐 *STATUS DOS UNIVERSOS*
• 🧱 RP: ${rpStatus}
• 🌑 Aventura: ${avStatus}
• 🏡 The Sims: ${simsStatus}

━━━━━━━━━━━━

🧱 *UNIVERSO CRIMINAL (RP)*
Economia • Profissões • Crime • Cassino
• ${prefix}ativarrp on | off
• ${prefix}menurp
• ${prefix}menucassino
• ${prefix}menudono

━━━━━━━━━━━━

🌑 *UNIVERSO DARK (AVENTURA)*
RPG • Boss • Exploração • Ranking
• ${prefix}modav on | off
• ${prefix}menuaventura

━━━━━━━━━━━━

🏡 *UNIVERSO VIDA (THE SIMS)*
Relacionamentos • Construção • Vida social
• ${prefix}modsims on | off
• ${prefix}menusims

━━━━━━━━━━━━

🎲 *INTERAÇÕES & MINI-JOGOS*
• ${prefix}brincadeiras

━━━━━━━━
`.trim();
}


// =============================================================
// MENU STICKERS / FIGURINHAS (sticker.js)
// - Submenus via: !menusticker <secao>
// - Alias: !menufigurinhas
// =============================================================
function buildStickerMenu(context, sectionRaw) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    const norm = (v) => String(v || '').trim().toLowerCase();
    const section = norm(sectionRaw);

    const hub = `
${header}

🎨 *STICKERS / FIGURINHAS*

Abra um submenu:
• 🖼 Básico: *${prefix}menusticker basico*
• ✍️ Texto: *${prefix}menusticker texto*
• 🎞 GIF: *${prefix}menusticker gif*
• 🔁 Converter: *${prefix}menusticker converter*
• 🎲 Aleatórias: *${prefix}menusticker aleatorias*
• 🧩 Auto: *${prefix}menusticker auto*

Dica: *${prefix}menusticker tudo*

${LINE}
`.trim();

    const full = `
${header}

🎨 *STICKERS / FIGURINHAS*

🖼 *Básico (responda mídia)*
• ${prefix}fig / ${prefix}f / ${prefix}s
• ${prefix}crop
• ${prefix}nobg                  — remove fundo e envia a imagem

✍️ *Texto*
• ${prefix}figtexto / ${prefix}fgtxt

🎞 *GIF*
• ${prefix}figgif
]
🔁 *Converter*
• ${prefix}toimg                 — figurinha → imagem

🧩 *Extras*
• ${prefix}scriador              — renomear figurinha
• ${prefix}rename                 — renomear figurinha
• ${prefix}sballon               — ballon (WhatsApp)

🎲 *Aleatórias*
• ${prefix}randomfig aleatórias
• ${prefix}randomfigif <qualquercoisa>
gera uma figurinha aleatória imagem
• ${prefix}randomfiimg <qualquercoisa>
gera uma figurinha aleatória GIF

🧩 *Auto*
• ${prefix}autofig [on|off|status]



${LINE}
`.trim();

    const menus = {
        basico: `
${header}

🖼 *STICKERS — BÁSICO*
(responda mídia)

• ${prefix}fig / ${prefix}f / ${prefix}s
• ${prefix}crop
• ${prefix}nobg                  — remove fundo e envia a imagem

${LINE}
`.trim(),

        texto: `
${header}

✍️ *STICKERS — TEXTO*

• ${prefix}figtexto <texto>
• ${prefix}fgtxt <texto>

${LINE}
`.trim(),

        gif: `
${header}

🎞 *STICKERS — GIF*

• ${prefix}figgif

${LINE}
`.trim(),

        converter: `
${header}

🔁 *STICKERS — CONVERTER*

• ${prefix}toimg        — figurinha → imagem
• ${prefix}togif        — figurinha → GIF

${LINE}
`.trim(),

        aleatorias: `
${header}

🎲 *STICKERS — ALEATÓRIAS*

• ${prefix}randomfig <anime|desenho>

${LINE}
`.trim(),

        auto: `
${header}

🧩 *STICKERS — AUTO*

• ${prefix}autofig on
• ${prefix}autofig off
• ${prefix}autofig status

${LINE}
`.trim(),
    };

    const alias = {
        basic: 'basico',
        base: 'basico',
        txt: 'texto',
        text: 'texto',
        gifs: 'gif',
        conv: 'converter',
        convert: 'converter',
        random: 'aleatorias',
        aleatoria: 'aleatorias',
        aleatorio: 'aleatorias',
    };

    const resolved = alias[section] || section;
    if (!resolved) return hub;
    if (resolved === 'tudo' || resolved === 'all' || resolved === 'completo') return full;
    if (menus[resolved]) return menus[resolved];
    return hub;
}

// =============================================================
// MENU ÁUDIO (audioTools.js)
// =============================================================
function buildAudioMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    return `
${header}

🎧 *MENU ÁUDIO*

🎬➡️🎧 *CONVERTER VÍDEO PARA ÁUDIO*
• ${prefix}converter        (MP3 por padrão)
• ${prefix}converter mp3
• ${prefix}converter wav
• ${prefix}converter ogg

📌 Envie um vídeo/áudio ou responda a um vídeo/áudio com o comando.

${LINE}

⚡ *EDIÇÃO DE ÁUDIO*
• ${prefix}acelerar 1.5     (padrão: 1.25x)
• ${prefix}lento 0.8
• ${prefix}volume 150       (em %)
• ${prefix}cortar 00:10 01:00

${LINE}

🎶 *EFEITOS DE ÁUDIO*
• ${prefix}grave            (voz mais encorpada)
• ${prefix}agudo            (voz mais clara)
• ${prefix}eco
• ${prefix}robot
• ${prefix}chipmunk
• ${prefix}vozcrianca
• ${prefix}vozmonstro

${LINE}

🧠 *AJUSTES INTELIGENTES*
• ${prefix}normalizar       (padroniza volume)
• ${prefix}removerruido     (remove ruído)
• ${prefix}audio            (converte áudio → MP3)
• ${prefix}juntar           (fila: use várias vezes)
• ${prefix}juntar fim       (gera o MP3 final)



${LINE}
`.trim();
}


// =============================================================
// MENU THE SIMS (theSims.js)
// =============================================================
function buildTheSimsMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    return `
${header}

🎮 *THE SIMS — MENU*

✅ *Começar o the sims*
• ${prefix}tsentrar               — entrar no modo The Sims neste chat

👤 *Perfil*
• ${prefix}tsperfil               — ver seu Sim
• ${prefix}tsdeletarperfil        — deletar seu Sim (zera o perfil deste chat)

🧩 *Criação do Sim (CAS)*
• ${prefix}tscriar                — iniciar criação guiada
• ${prefix}tscatalogo             — catálogo (corpo/pele/estilo/traços/aspiração)
• ${prefix}tsnome <nome>
• ${prefix}tssexo <masculino|feminino|outro>
• ${prefix}tsaspiracao <aspiracao>
• ${prefix}tstraco <traço>        — até 3 (aceita "a, b, c")
• ${prefix}tcorpo <tipo>
• ${prefix}tpele <tipo>
• ${prefix}testilo <tipo>
• ${prefix}tsfinalizar
• ${prefix}tscancelar

⚡ *Criação rápida*
• ${prefix}tscriarfast            — ver modelo
• ${prefix}tscriarfast Nome=...; Sexo=...; Aspiracao=...; Tracos=...; Corpo=...; Pele=...; Estilo=...
• ${prefix}tsaleatorio            — criar aleatório

🏡 *Casa*
• ${prefix}tscasa
• ${prefix}tscomprarterreno
• ${prefix}tsconstruir <opção>    — basico|paredes|piso|janelas|portas|piscina|nivel
• ${prefix}tsdecorar <tema>       — moderno|classico|urbano|gamer|elegante|simples
• ${prefix}tssujeira
• ${prefix}tslimparcasa
• ${prefix}tscontas

💼 *Trabalho*
• ${prefix}tsemprego              — listar / escolher
• ${prefix}tsemprego <nome>       — escolher
• ${prefix}tstrabalhar
• ${prefix}tsdemitir

📚 *Skills*
• ${prefix}tsskills
• ${prefix}tsestudar <skill>      — culinaria|logica|criatividade|fitness|carisma
• ${prefix}tspraticar <skill>     — culinaria|logica|criatividade|fitness|carisma

🎲 *Eventos*
• ${prefix}tsevento

🙂 *Necessidades*
• ${prefix}tsdormir
• ${prefix}tsbanho
• ${prefix}tsdiversao
• ${prefix}tscomer [leve|pesado]

💪 *Físico*
• ${prefix}tsexercicio
• ${prefix}tscorrida
• ${prefix}tsacademia
• ${prefix}tspularcorda
• ${prefix}tsdieta
• ${prefix}tsfritura



${LINE}
`.trim();
}

// =============================================================
// MENU ADMINISTRAÇÃO (admin.js)
// =============================================================
function buildAdminMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    const norm = (v) => String(v || '').trim().toLowerCase();
    const arg0 = Array.isArray(context?.args) && context.args.length > 0 ? context.args[0] : (context?.section || '');
    const section = norm(arg0);

    const hub = `
${header}

🛡️ *MENU ADMINISTRAÇÃO*
(apenas ADM do grupo)

Abra um submenu:
• 👮 Moderação: *${prefix}menuadm moderacao*
• 🔐 Grupo: *${prefix}menuadm grupo*
• 📢 Regras/Boas-vindas: *${prefix}menuadm boasvindas*
• 🔒 Proteções: *${prefix}menuadm protecoes*
• ✨ Atividade: *${prefix}menuadm atividade*
• 🔔 Marcações/Status: *${prefix}menuadm status*

Dica: *${prefix}menuadm tudo*

${LINE}
`.trim();

    const full = `
${header}

🛡️ *MENU ADMINISTRAÇÃO*
(apenas ADM do grupo)

👮 *Moderação básica*
• ${prefix}promover @marcar    — tornar ADM
• ${prefix}rebaixar @marcar    — remover ADM
• ${prefix}ban @marcar         — banir do grupo
• ${prefix}listanegra @marcar  — banir e impedir retorno
• ${prefix}verlistanegra      — ver lista negra
• ${prefix}removerlistanegra  — remover da lista
• ${prefix}deletarmsg /${prefix}d — apagar msg (responda a mensagem)
• ${prefix}limparghost <min>   — remover membros com poucas mensagens (dono bot/grupo)
• ${prefix}mute <min>          — mutar por X minutos
• ${prefix}desmute             — retirar mute

🔐 *Grupo*
• ${prefix}fechargrp / ${prefix}abrirgrp
• ${prefix}revogarlink
• ${prefix}agendagrp
• ${prefix}arquivargrupo
• desligarbot / ligarbot
• ${prefix}ativarrp on/off     — ativar/desativar RP e Cassino

📢 *Regras / Boas vindas*
• ${prefix}regras              — mostrar regras
• ${prefix}setregras <texto>   — definir regras
• ${prefix}boasvindas on/off   — ativar/desativar boas vindas
• ${prefix}setwelcome <texto>  — texto de boas vindas

🔒 *Proteções*
• ${prefix}antilink on/off            — proteção contra links
• ${prefix}antilinkentrada on/off     — bloquear links de entrada
• ${prefix}antilinkadm on/off         — bloquear links enviados por ADMs
• ${prefix}antilinkacoes on/off       — ações automáticas do anti-link

• ${prefix}antifake on/off            — bloquear números suspeitos
• ${prefix}antifakeconfig <55|...>    — configurar países/DDDs permitidos
• ${prefix}antiflood on/off           — limitar flood de mensagens
• ${prefix}autobanstatus on/off      — banir quem postar status

✨ *Atividade*
• ${prefix}upmsg on/off           — avisos de level por msg
• ${prefix}ativos [min]           — listar membros acima do limite
• ${prefix}inativos <min>         — listar membros abaixo do limite

🔔 *Marcações / status*
• ${prefix}marcar / ${prefix}tagall
• ${prefix}marcartodos
• ${prefix}tagadm
• ${prefix}statusgrp
• ${prefix}linkgrp



${LINE}
`.trim();

    const menus = {
        moderacao: `
${header}

👮 *ADMIN — MODERAÇÃO*
(apenas ADM do grupo)

• ${prefix}promover @marcar
• ${prefix}rebaixar @marcar
• ${prefix}ban @marcar
• ${prefix}listanegra @marcar
• ${prefix}verlistanegra
• ${prefix}removerlistanegra
• ${prefix}deletarmsg / ${prefix}d   (responda a mensagem)
• ${prefix}mute <min>
• ${prefix}desmute
• ${prefix}limparghost <min>

${LINE}
`.trim(),

        grupo: `
${header}

🔐 *ADMIN — GRUPO*
(apenas ADM do grupo)

• ${prefix}fechargrp / ${prefix}abrirgrp
• ${prefix}revogarlink
• ${prefix}linkgrp
• ${prefix}agendagrp
• ${prefix}arquivargrupo
• desligarbot / ligarbot
• ${prefix}ativarrp on/off

${LINE}
`.trim(),

        boasvindas: `
${header}

📢 *ADMIN — REGRAS / BOAS-VINDAS*
(apenas ADM do grupo)

• ${prefix}regras
• ${prefix}setregras <texto>
• ${prefix}boasvindas on/off
• ${prefix}setwelcome <texto>

${LINE}
`.trim(),

        protecoes: `
${header}

🔒 *ADMIN — PROTEÇÕES*
(apenas ADM do grupo)

• ${prefix}antilink on/off
• ${prefix}antilinkentrada on/off
• ${prefix}antilinkadm on/off
• ${prefix}antilinkacoes on/off
• ${prefix}antifake on/off
• ${prefix}antifakeconfig <55|...>
• ${prefix}antiflood on/off
• ${prefix}autobanstatus on/off

${LINE}
`.trim(),

        atividade: `
${header}

✨ *ADMIN — ATIVIDADE*
(apenas ADM do grupo)

• ${prefix}upmsg on/off
• ${prefix}ativos [min]
• ${prefix}inativos <min>

${LINE}
`.trim(),

        status: `
${header}

🔔 *ADMIN — MARCAÇÕES / STATUS*
(apenas ADM do grupo)

• ${prefix}marcar / ${prefix}tagall
• ${prefix}marcartodos
• ${prefix}tagadm
• ${prefix}statusgrp
• ${prefix}linkgrp

${LINE}
`.trim(),
    };

    const alias = {
        mod: 'moderacao',
        moderar: 'moderacao',
        grupo: 'grupo',
        regras: 'boasvindas',
        welcome: 'boasvindas',
        boas: 'boasvindas',
        protecao: 'protecoes',
        protecoes: 'protecoes',
        anti: 'protecoes',
        atividade: 'atividade',
        up: 'atividade',
        status: 'status',
        tag: 'status',
    };

    if (!section) return hub;
    const resolved = alias[section] || section;
    if (resolved === 'tudo' || resolved === 'all' || resolved === 'completo') return full;
    if (menus[resolved]) return menus[resolved];
    return hub;
}

// =============================================================
// MENU RP

function buildRpMenu(context, sectionRaw) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    const norm = (v) => String(v || '').trim().toLowerCase();
    const section = norm(sectionRaw);

    const fullMenu = `
${header}

🎭 *RP – Hub principal*

📌 *Seu painel*
• ${prefix}meurp                — pronto agora / próximos tempos

👤 *Perfil & progresso*
• ${prefix}perfil / ${prefix}ficha
• ${prefix}inventario            — ver itens comprados
• ${prefix}meuperfil
• ${prefix}rankmenu / ${prefix}rank / ${prefix}top
• ${prefix}missao  (atalhos: ${prefix}missaodiaria, ${prefix}diaria)

💼 *Profissões & trabalho*
• ${prefix}profissoes             — listar profissões
• ${prefix}profissao <id/nome>    — escolher profissão
• ${prefix}trabalhar              — ganhar salário e XP

🏦 *Banco & dinheiro*
• ${prefix}saldo / ${prefix}banco
• ${prefix}meubanco               — detalhes do banco
• ${prefix}coletarrenda           — coletar renda passiva
• ${prefix}resgatar               — resgatar (RP)
• ${prefix}menuinvestimo          — investimentos
• ${prefix}pix @marcar <valor>

💳 *Empréstimo*
• ${prefix}emprestimo <valor>     — solicitar
• ${prefix}quitar / ${prefix}quitemprestimo
• ${prefix}pagarparcela <n|1,2,3|ultimas n>

💣 *Crimes & invasões*
• ${prefix}roubar @marcar
• ${prefix}menuhacker            — painel do Hacker
• ${prefix}invadirbanco          — roubar banco de alguém
• ${prefix}hackerloja            — upgrades (PC/VPN/Servidor/Host)
• ${prefix}invadircasadamoeda    — endgame do Hacker

🌑 *Submundo (dinheiro sujo)*
• ${prefix}menusujo               — bunker, lavagem e heat
• ${prefix}escondersujo <valor>
• ${prefix}sacarsujo <valor>
• ${prefix}lavarsujo <valor> <id_imovel>
• ${prefix}doleiro <valor>
• ${prefix}suborno <valor> @policial  — reduz heat (ou use ${prefix}suborno preso)
• ${prefix}bunker                — detalhes do bunker
• ${prefix}aumentarbunker        — aumentar capacidade
• ${prefix}melhorarbunker        — melhorar segurança

👮 *Polícia*
• ${prefix}menupm
• ${prefix}delegacia
• ${prefix}prender, ${prefix}soltar
• ${prefix}fugir, ${prefix}suborno
• ${prefix}pagarfianca <valor> / ${prefix}liberarfianca
• ${prefix}menuprisao, ${prefix}pagarmulta
• ${prefix}advogado, ${prefix}audiencia

🏥 *Hospital (Médico)*
• ${prefix}hospital          — painel do hospital
• ${prefix}plantao           — fazer plantão (depósito no hospital)
• ${prefix}missaomedico      — hub de missões do hospital
• ${prefix}lojasaude / ${prefix}comprarsaude — upgrades


🌾 *Agro / fazenda*
• ${prefix}menuagro
• ${prefix}agro / ${prefix}fazenda — painel (status)
• ${prefix}agromodo, ${prefix}plantar, ${prefix}colher
• ${prefix}agrovender, ${prefix}agrocoletar
• ${prefix}agrodescarregar, ${prefix}agrosilo
• ${prefix}agrobichos, ${prefix}animais

🏪 *Lojas do RP*
• ${prefix}menuloja               — menu geral das lojas
• ${prefix}colecionaveis      — colecionáveis únicos
• ${prefix}vendercolecionavel   — vender colecionável (oferta)
• ${prefix}menuitem, ${prefix}menuauto, ${prefix}menucasa
• ${prefix}menurenda,${prefix}menuilegal

🛒 *Mercado entre jogadores*
• ${prefix}menumercado            — menu do mercado
• ${prefix}criarloja, ${prefix}minhaloja
• ${prefix}vender
• ${prefix}listarvendas, ${prefix}comprarjogador



${LINE}
`.trim();

    const hub = `
${header}

🎭 *RP – Hub principal*

Abra um submenu:
• 👤 Perfil: *${prefix}menurp perfil*
• 💼 Profissões: *${prefix}menurp profissoes*
• 🏦 Banco: *${prefix}menurp banco*
• 💳 Empréstimo: *${prefix}menurp emprestimo*
• 💣 Crimes: *${prefix}menurp crimes*
• 🌑 Submundo: *${prefix}menurp sujo*
• 👮 Polícia: *${prefix}menurp policia*
• 🏥 Hospital: *${prefix}menurp hospital*
• 🌾 Agro: *${prefix}menurp agro*
• 🏪 Lojas: *${prefix}menurp lojas*
• 🛒 Mercado: *${prefix}menurp mercado*

Dica: *${prefix}menurp tudo* (menu completo)


${LINE}
`.trim();

    const menus = {
        perfil: `
${header}

👤 *Perfil & progresso*
• ${prefix}perfil / ${prefix}ficha
• ${prefix}inventario
• ${prefix}meuperfil
• ${prefix}rankmenu / ${prefix}rank / ${prefix}top
• ${prefix}missao  (atalhos: ${prefix}missaodiaria, ${prefix}diaria)

${LINE}
`.trim(),

        profissoes: `
${header}

💼 *Profissões & trabalho*
• ${prefix}profissoes
• ${prefix}profissao <id/nome>
• ${prefix}trabalhar

${LINE}
`.trim(),

        banco: `
${header}

🏦 *Banco & dinheiro*
• ${prefix}saldo / ${prefix}banco
• ${prefix}meubanco
• ${prefix}coletarrenda
• ${prefix}menuinvestimo
• ${prefix}pix @marcar <valor>

${LINE}
`.trim(),

        emprestimo: `
${header}

💳 *Empréstimo*
• ${prefix}emprestimo <valor>
• ${prefix}quitar / ${prefix}quitemprestimo
• ${prefix}pagarparcela <n|1,2,3|ultimas n>

${LINE}
`.trim(),

        crimes: `
${header}

💣 *Crimes & invasões*
• ${prefix}roubar @marcar
• ${prefix}menuhacker
• ${prefix}invadirbanco
• ${prefix}hackerloja
• ${prefix}invadircasadamoeda

${LINE}
`.trim(),

        sujo: `
${header}

🌑 *Submundo (dinheiro sujo)*
• ${prefix}menusujo
• ${prefix}escondersujo <valor>
• ${prefix}sacarsujo <valor>
• ${prefix}lavarsujo <valor> <id_imovel>
• ${prefix}doleiro <valor>
• ${prefix}suborno <valor> @policial  (ou use ${prefix}suborno preso)
• ${prefix}bunker
• ${prefix}aumentarbunker
• ${prefix}melhorarbunker

${LINE}
`.trim(),

        policia: `
${header}

👮 *Polícia*
• ${prefix}menupm
• ${prefix}delegacia
• ${prefix}prender, ${prefix}soltar
• ${prefix}fugir, ${prefix}suborno
• ${prefix}pagarfianca <valor> / ${prefix}liberarfianca
• ${prefix}menuprisao, ${prefix}pagarmulta
• ${prefix}advogado, ${prefix}audiencia

${LINE}
`.trim(),

        hospital: `
${header}

🏥 *Hospital (Médico)*
• ${prefix}hospital
• ${prefix}plantao
• ${prefix}missaomedico
• ${prefix}lojasaude / ${prefix}comprarsaude

${LINE}
`.trim(),

        agro: `
${header}

🌾 *Agro / fazenda*
• ${prefix}agro / ${prefix}fazenda
• ${prefix}agromodo, ${prefix}plantar, ${prefix}colher
• ${prefix}agrotempo, ${prefix}agrobonus
• ${prefix}agroconstruir, ${prefix}comprarterra
• ${prefix}sementes, ${prefix}fertilizante
• ${prefix}agrobichos, ${prefix}animais

${LINE}
`.trim(),

        lojas: `
${header}

🏪 *Lojas do RP*
• ${prefix}menuloja
• ${prefix}menuitem, ${prefix}menuauto, ${prefix}menucasa
• ${prefix}menurenda, ${prefix}menuagro, ${prefix}menuilegal

${LINE}
`.trim(),

        mercado: `
${header}

🛒 *Mercado entre jogadores*
• ${prefix}menumercado
• ${prefix}criarloja, ${prefix}minhaloja
• ${prefix}vender
• ${prefix}listarvendas, ${prefix}comprarjogador



${LINE}
`.trim(),
    };

    // aliases curtos (sem criar comando novo)
    const alias = {
        prof: 'profissoes',
        profs: 'profissoes',
        job: 'profissoes',
        jobs: 'profissoes',
        work: 'profissoes',
        trabalho: 'profissoes',
        bank: 'banco',
        grana: 'banco',
        money: 'banco',
        loan: 'emprestimo',
        emprestimos: 'emprestimo',
        crime: 'crimes',
        hack: 'crimes',
        hacker: 'crimes',
        sujo: 'sujo',
        pm: 'policia',
        police: 'policia',
        med: 'hospital',
        medico: 'hospital',
        farm: 'agro',
        fazenda: 'agro',
        store: 'lojas',
        loja: 'lojas',
        market: 'mercado',
    };

    const resolved = alias[section] || section;

    if (!resolved) return hub;
    if (resolved === 'tudo' || resolved === 'all' || resolved === 'completo') return fullMenu;
    if (menus[resolved]) return menus[resolved];

    // parâmetro inválido -> hub
    return hub;
}

// =============================================================
// MENU MERCADO ENTRE JOGADORES (jogadorloja.js)
// =============================================================
function buildRpMercadoMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    return `
${header}

🛒 *MERCADO ENTRE JOGADORES*
${LINE}

📌 *Loja do jogador*
• ${prefix}criarloja <nome>
• ${prefix}minhaloja
• ${prefix}loja                  — painel de gestão

📦 *Anunciar / vender*
• ${prefix}vender <item> <preço>
• ${prefix}listarvendas [@vendedor]

🛍️ *Comprar*
• ${prefix}comprarjogador @vendedor <item|número>

ℹ️ *Gestão (via ${prefix}loja)*
• ${prefix}loja saldo
• ${prefix}loja sacar
• ${prefix}loja reabastecer <id> <qtd>
• ${prefix}loja retirar <id|nome>
• ${prefix}loja editarnome <novo nome>
• ${prefix}loja deletar confirmar

${LINE}
`.trim();
}


// =============================================================
// MENU PRISÃO (rp.js → buildRpPrisaoMenu)
// =============================================================
function buildRpPrisaoMenu(context, data) {
    const prefix = getPrimaryPrefix(context);

    const remaining = (data && data.remainingText) || '—';
    const motivo = (data && data.reasonText) || '—';
    const multa = (data && data.fineText) || '—';
    const fianca = (data && data.bailText) || '—';
    const chance = (data && data.earlyChanceText) || '—';

    return `
⛓️ *PRISÃO*
⏳ Restante: ${remaining}
🧾 Motivo: ${motivo}
💰 Multa: ${multa}
💸 Fiança: ${fianca}
⚖️ Liberdade: ${chance}

✅ Opções
• ${prefix}trabalhar
• ${prefix}pagarmulta
• ${prefix}advogado
• ${prefix}audiencia
`.trim();
}


// =============================================================
// MENU PROFISSÕES (rp.js → buildRpProfissoesMenu)
// =============================================================
function buildRpProfissoesMenu(context, PROFESSIONS) {
    const prefix = getPrimaryPrefix(context);

    // Ordem oficial do menu (não mostra "chave:" e mantém o painel limpo)
    const orderKeys = [
        'pedreiro',
        'agricultor',
        'motoboy',
        'empresario',
        'hacker',
        'medico',
        'advogado',
        'policial',
        'ladrao',
        'politico',
        'mecanico',
    ];

    const byKey = new Map((PROFESSIONS || []).map(p => [p.key, p]));
    const ordered = orderKeys.map(k => byKey.get(k)).filter(Boolean);

    const lines = [];
    lines.push('💼 *ESCOLHA SUA PROFISSÃO*');
    lines.push('');
    lines.push('🔰 *Iniciais*');
    if (ordered[0]) lines.push(`• 1. ${ordered[0].name}`);
    if (ordered[1]) lines.push(`• 2. ${ordered[1].name}`);
    if (ordered[2]) lines.push(`• 3. ${ordered[2].name}`);
    if (ordered[10]) lines.push(`• 11. ${ordered[10].name}`);
    lines.push('');
    lines.push('📈 *Intermediárias*');
    if (ordered[3]) lines.push(`• 4. ${ordered[3].name}`);
    if (ordered[4]) lines.push(`• 5. ${ordered[4].name}`);
    if (ordered[5]) lines.push(`• 6. ${ordered[5].name}`);
    if (ordered[6]) lines.push(`• 7. ${ordered[6].name}`);
    lines.push('');
    lines.push('🔥 *Alta Influência*');
    if (ordered[7]) lines.push(`• 8. ${ordered[7].name}`);
    if (ordered[8]) lines.push(`• 9. ${ordered[8].name}`);
    if (ordered[9]) lines.push(`• 10. ${ordered[9].name}`);
    lines.push('');
    lines.push(LINE);
    lines.push(`📌 Use: ${prefix}profissao <número> ou ${prefix}profissao <nome>`);

    return `${lines.join('\n')}`.trim();
}


// =============================================================
// MENU BANCO – OPÇÕES RÁPIDAS
// =============================================================
function buildRpBancoOpcaoMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    return `
${header}

🏦 *BANCO & FINANÇAS*

📑 *Banco*
• ${prefix}escolherbanco <nome>   — definir banco
• ${prefix}meubanco               — ver banco 

💰 *Saldos*
• ${prefix}saldo                  — carteira + banco
• ${prefix}banco                  — atalho de saldo
• ${prefix}coletarrenda           — coletar renda passiva
• ${prefix}menuinvestimo          — menu investimentos
• ${prefix}investir <id/tipo> <valor>

💸 *Movimentações*
• ${prefix}depositar <valor|tudo>
• ${prefix}sacar <valor|tudo>
• ${prefix}pix @marcar <valor>

💳 *Empréstimo*
• ${prefix}emprestimo <valor>     — solicitar
• ${prefix}quitar / ${prefix}quitemprestimo

⛓ *Fiança*
• ${prefix}pagarfianca <valor>    — pagar fiança
• ${prefix}liberarfianca          — liberar preso

${LINE}
`.trim();
}

// =============================================================
// MENU CASSINO (cassino.js)
// =============================================================
function buildCassinoMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    const cs = (context && context.casinoStatus) || null;

    const statusBlock = cs
        ? (
            `📦 Status do Cassino\n` +
            `• Caixa: ${cs.bankText || '—'}\n` +
            `• Situação: ${cs.isClosed ? 'FECHADO' : 'ABERTO'}\n` +
            `• Estado: ${cs.stateEmoji || ''} ${cs.stateLabel || '—'}\n` +
            `${LINE}`
        )
        : (
            `📦 Status do Cassino\n` +
            `• Caixa: —\n` +
            `• Situação: —\n` +
            `• Estado: —\n` +
            `${LINE}`
        );

    return `
${header}

🎰 CASSINO — VISÃO GERAL

${statusBlock}

📌 Menus disponíveis
• ${prefix}menucassino — lista geral de comandos
• ${prefix}cassinojogos — jogos e apostas
• ${prefix}cassinoinfo — regras, limites e funcionamento



${LINE}
`.trim();
}

function buildCassinoJogosMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    const cs = (context && context.casinoStatus) || null;

    const statusBlock = cs
        ? (
            `📦 Status do Cassino\n` +
            `• Caixa: ${cs.bankText || '—'}\n` +
            `• Situação: ${cs.isClosed ? 'FECHADO' : 'ABERTO'}\n` +
            `• Estado: ${cs.stateEmoji || ''} ${cs.stateLabel || '—'}\n` +
            `${LINE}`
        )
        : (
            `📦 Status do Cassino\n` +
            `• Caixa: —\n` +
            `• Situação: —\n` +
            `• Estado: —\n` +
            `${LINE}`
        );

    return `
${header}

🎮 CASSINO — JOGOS & APOSTAS

${statusBlock}

🎰 Jogos disponíveis
🪙 Cara ou Coroa
• ${prefix}caracoroa <cara|coroa> <valor|tudo|metade>
• ${prefix}cc <cara|coroa> <valor|tudo|metade>

🎡 Roleta
• ${prefix}roleta <numero|vermelho|preto|verde> <valor|tudo|metade>

🎰 Slot
• ${prefix}slot <valor|tudo|metade>

🎲 Dados
• ${prefix}dado <valor|tudo|metade>

🐾 Jogo do Bicho
• ${prefix}bicho <id> <valor|tudo|metade>

🃏 Blackjack (21)
• ${prefix}blackjack <valor|tudo|metade>
• ${prefix}21 <valor|tudo|metade>

🃏 Blackjack — Mesa (multijogador)
• ${prefix}blackjack mesa <entrada>
 (durante a mesa: ${prefix}entrar | ${prefix}comprar | ${prefix}parar)
 (alias p/ comprar: ${prefix}bjcomprar)
 (cancelar mesa: ${prefix}blackjack cancelar)

🚀 Crash
• ${prefix}crash <valor|tudo|metade> [mult]
Ex: ${prefix}crash 1000 2.5 seguro

➗ Par / Ímpar
• ${prefix}parimpar <par|impar> <valor|tudo|metade>

🤝 Jogos em dupla
• ${prefix}parperfeito @user <valor|tudo|metade>
 (durante: ${prefix}numero <1–10>)
• ${prefix}cofreduplo @user <valor|tudo|metade>
 (durante: ${prefix}codigo <1–5>)
• ${prefix}caratraidor @user <valor|tudo|metade>
 (durante: ${prefix}escolha coop | ${prefix}escolha trair)

🎁 Extras
• ${prefix}dupla — após vitória: dupla ou nada
• ${prefix}duplanada — alias de ${prefix}dupla
• (seguro) — opcional: recupera metade se perder

💰 Jackpot do Cassino
• ${prefix}jackpot — ver pote / seus bilhetes
• ${prefix}jackpot <valor|tudo|metade> — entrar no jackpot
• ${prefix}jackpot sortear — sortear o pote

🤝 Apostas entre jogadores
(ou responda a mensagem do alvo e use: ${prefix}apostar <valor|tudo|metade>)

📌 Atalhos
• ${prefix}cassino — visão geral / status
• ${prefix}menucassino — lista geral de comandos
• ${prefix}cassinoinfo — regras, limites e funcionamento

${LINE}
`.trim();
}

// =============================================================
// MENU CASSINO (Completo) — atalhos sem status e sem lista de jogos
// =============================================================
function buildMenuCassinoCompleto(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    return `
${header}

🎰 MENU CASSINO 
📌 Para ver jogos + status: ${prefix}cassinojogos
${LINE}

📌 Menus / Info
• ${prefix}menucassino — este menu completo
• ${prefix}cassino — jogos + status
• ${prefix}cassinoinfo — como funciona (caixa, limites, fechamento)

📊 Histórico / Rank
• ${prefix}cassinohoje
• ${prefix}cassinorank
• ${prefix}meucassino
• ${prefix}cassinoconquistas
• ${prefix}cassinobonus

💰 Jackpot do Cassino
• ${prefix}jackpot
• ${prefix}jackpot <valor|tudo|metade>
• ${prefix}jackpot sortear

🤝 Apostas entre jogadores
• ${prefix}apostar <valor|tudo|metade> (respondendo o alvo)

👑 Comandos do dono (cassino)
• ${prefix}donocassino <quantidade>
• ${prefix}auditoriacassino
• ${prefix}cassinotema <...>
• ${prefix}cassinomodo <...>
• ${prefix}cassinoevento

${LINE}
`.trim();
}

// =============================================================
// MENU BRINCADEIRAS (brincadeiras.js)
// =============================================================
function buildBrincadeirasMenu(context) {
  const prefix = getPrimaryPrefix(context);
  const header = buildHeader(context);

  const norm = (v) => String(v || '').trim().toLowerCase();
  const arg0 = Array.isArray(context?.args) && context.args.length > 0 ? context.args[0] : (context?.section || '');
  const section = norm(arg0);

  const hub = `
${header}

🎉 *MENU BRINCADEIRAS / INTERAÇÕES*

Abra um submenu:
• 👊 Interações: *${prefix}brincadeiras interacoes*
• 🤝 Carinho: *${prefix}brincadeiras carinho*
• 🎮 Jogos: *${prefix}brincadeiras jogos*
• 👨‍👩‍👧‍👦 Família: *${prefix}brincadeiras familia*
• 📊 Ranks: *${prefix}brincadeiras ranks*
• 🔊 Áudios: *${prefix}brincadeiras audios*

Dica: *${prefix}brincadeiras tudo*

${LINE}
`.trim();

  const full = `
${header}

🎉 *MENU BRINCADEIRAS / INTERAÇÕES*

👊 *Interações*
• ${prefix}tapa @marcar
• ${prefix}morder @marcar
• ${prefix}chutar @marcar
• ${prefix}soco @marcar
• ${prefix}comer @marcar
• ${prefix}matar @marcar
• ${prefix}zuar @marcar
• ${prefix}corno @marcar
• ${prefix}gado @marcar

🤝 *Carinho / amizade*
• ${prefix}abraco @marcar
• ${prefix}beijo @marcar
• ${prefix}amizade @marcar
• ${prefix}elogio @marcar

👨‍👩‍👧‍👦 *Família / Casamento*
• ${prefix}familia
• ${prefix}meusfilhos
• ${prefix}desadotar @marcar
• ${prefix}emancipar
• ${prefix}casados

📊 *Ranks TOP 5 (grupo)*
• ${prefix}rankgado / ${prefix}rankgados
• ${prefix}rankcorno / ${prefix}rankcornos
• ${prefix}rankgay / ${prefix}rankgays
• ${prefix}rankgostoso / ${prefix}rankgostosos
• ${prefix}rankgostosa / ${prefix}rankgostosas
• ${prefix}rankotaku / ${prefix}rankotakus
• ${prefix}ranksigma / ${prefix}ranksigmas
• ${prefix}rankbeta / ${prefix}rankbetas
• ${prefix}rankcarioca / ${prefix}rankcariocas
• ${prefix}rankbaiano / ${prefix}rankbaianos
• ${prefix}ranksafado / ${prefix}ranksafados
• ${prefix}ranksafada / ${prefix}ranksafadas
• ${prefix}ranklouco / ${prefix}rankloucos
• ${prefix}ranklouca / ${prefix}rankloucas
• ${prefix}ranknazista / ${prefix}ranknazistas
• ${prefix}rankcomunista / ${prefix}rankcomunistas
• ${prefix}rankpau / ${prefix}rankpaus
• ${prefix}rankbuceta / ${prefix}rankbucetas
• ${prefix}rankcapitalista / ${prefix}rankcapitalistas

🔊 *Áudios da vitória*
• ${prefix}vitoriabolsonaro
• ${prefix}vitoriacanta
• ${prefix}pitu
• ${prefix}vitoriaadm
• ${prefix}vitoriaconta1

🔊 *Áudios*
• ${prefix}yamete
• ${prefix}lolimusic
• ${prefix}cha
• ${prefix}ferias
• ${prefix}maconha
• ${prefix}criatura
• ${prefix}ara
• ${prefix}fight
• ${prefix}risadinha
• ${prefix}bandido
• ${prefix}bucetacional
• ${prefix}pipoquinha
• ${prefix}pipoquinha18
• ${prefix}solinguica
• ${prefix}chora
• ${prefix}bomdia

${LINE}
`.trim();

  const menus = {
    interacoes: `
${header}

👊 *BRINCADEIRAS — INTERAÇÕES*
• ${prefix}tapa @marcar
• ${prefix}morder @marcar
• ${prefix}chutar @marcar
• ${prefix}matar @marcar
• ${prefix}zuar @marcar
• ${prefix}corno @marcar
• ${prefix}gado @marcar

${LINE}
`.trim(),

    carinho: `
${header}

🤝 *BRINCADEIRAS — CARINHO*
• ${prefix}abraco @marcar
• ${prefix}beijo @marcar
• ${prefix}amizade @marcar
• ${prefix}elogio @marcar

${LINE}
`.trim(),

    jogos: `
${header}

🎮 *BRINCADEIRAS — JOGOS*
• ${prefix}duelo @marcar

${LINE}
`.trim(),

    familia: `
${header}

👨‍👩‍👧‍👦 *BRINCADEIRAS — FAMÍLIA / CASAMENTO*
• ${prefix}familia
• ${prefix}meusfilhos
• ${prefix}desadotar @marcar
• ${prefix}emancipar
• ${prefix}casados

${LINE}
`.trim(),

    ranks: `
${header}

📊 *BRINCADEIRAS — RANKS (TOP 5 do grupo)*
• ${prefix}rankgado / ${prefix}rankgados
• ${prefix}rankcorno / ${prefix}rankcornos
• ${prefix}rankgay / ${prefix}rankgays
• ${prefix}rankgostoso / ${prefix}rankgostosos
• ${prefix}rankgostosa / ${prefix}rankgostosas
• ${prefix}rankotaku / ${prefix}rankotakus
• ${prefix}ranksigma / ${prefix}ranksigmas
• ${prefix}rankbeta / ${prefix}rankbetas
• ${prefix}rankcarioca / ${prefix}rankcariocas
• ${prefix}rankbaiano / ${prefix}rankbaianos
• ${prefix}ranksafado / ${prefix}ranksafados
• ${prefix}ranksafada / ${prefix}ranksafadas
• ${prefix}ranklouco / ${prefix}rankloucos
• ${prefix}ranklouca / ${prefix}rankloucas
• ${prefix}ranknazista / ${prefix}ranknazistas
• ${prefix}rankcomunista / ${prefix}rankcomunistas
• ${prefix}rankpau / ${prefix}rankpaus
• ${prefix}rankbuceta / ${prefix}rankbucetas
• ${prefix}rankcapitalista / ${prefix}rankcapitalistas

${LINE}
`.trim(),

    audios: `
${header}

🔊 *BRINCADEIRAS — ÁUDIOS*

🏆 *Vitória*
• ${prefix}vitoriabolsonaro
• ${prefix}vitoriacanta
• ${prefix}pitu
• ${prefix}vitoriaadm
• ${prefix}vitoriaconta1

🎧 *Gerais*
• ${prefix}yamete
• ${prefix}lolimusic
• ${prefix}cha
• ${prefix}ferias
• ${prefix}maconha
• ${prefix}criatura
• ${prefix}ara
• ${prefix}fight
• ${prefix}risadinha
• ${prefix}bandido
• ${prefix}bucetacional
• ${prefix}pipoquinha
• ${prefix}pipoquinha18
• ${prefix}solinguica
• ${prefix}chora
• ${prefix}bomdia
• ${prefix}quieto



${LINE}
`.trim(),
  };

  const alias = {
    interacao: 'interacoes',
    interacoes: 'interacoes',
    acoes: 'interacoes',
    carinho: 'carinho',
    amizade: 'carinho',
    jogos: 'jogos',
    game: 'jogos',
    familia: 'familia',
    casamento: 'familia',
    ranks: 'ranks',
    rank: 'ranks',
    top: 'ranks',
    audios: 'audios',
    audio: 'audios',
    sons: 'audios',
  };

  if (!section) return hub;
  const resolved = alias[section] || section;
  if (resolved === 'tudo' || resolved === 'all' || resolved === 'completo') return full;
  if (menus[resolved]) return menus[resolved];
  return hub;
}
// =============================================================
// MENU DONO DO BOT (owner + vantagens RP)
// =============================================================
function buildDonoMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    return `
${header}

👑 *MENU DONO (RP)*

🎮 *Vantagens do dono (RP)*
• ${prefix}donotrabalhar            — trabalhar sem cooldown
• ${prefix}donoemprestimo <valor>   — criar empréstimo especial
• ${prefix}donosacar <valor>        — sacar mesmo sem saldo
• ${prefix}donopix @marcar <valor>  — enviar PIX como dono
• ${prefix}jobxpdono <xp>           — ajustar XP de profissão
• ${prefix}giveitem <id> <qtd>      — pegar item da loja (sem pagar)

⏱ *Balanceamento / tempos*
• ${prefix}donotempos 0             — zera todos os cooldowns do RP
• ${prefix}donotempos normal        — restaura tempos padrão
• ${prefix}donostatus               — lista tempos e custos atuais
• ${prefix}donomult <x>             — muda multiplicador global de salário

🧨 *Resetes de RP*
• ${prefix}resetmoney               — zera carteira + banco do grupo
• ${prefix}resetargrupo             — resetar RP do grupo atual
• ${prefix}resetarall               — resetar TODO RP (todos os grupos)

🛠 *Painel do bot*
• ${prefix}menubot                  — abrir menu técnico do bot



${LINE}
`.trim();
}

// =============================================================
// MENU BOT (painel técnico – owner.js)
// =============================================================
function buildBotMenu(context) {
    const prefix = getPrimaryPrefix(context);
    const header = buildHeader(context);

    return `
${header}

🧰 *MENU DO BOT (DONO)*

🔄 *Controle*
• ${prefix}ligarbot
• ${prefix}desligarbot
• ${prefix}resetarbot          — reset leve de estado
• ${prefix}reiniciarbot        — reiniciar processo
• ${prefix}pausabot / ${prefix}pausarbot  — pausar comandos
• ${prefix}voltabot  — voltar ao normal

📊 *Status / Logs*
• ${prefix}statusbot
• ${prefix}logs
• ${prefix}limparlogs

💾 *Backup*
• ${prefix}backupdb

⚙️ *Config / Reload*
• ${prefix}recarregarconfig
• ${prefix}reloadcomandos
• ${prefix}resetarperfil

🚫 *Bloqueios*
• ${prefix}bloquearcomando <cmd>
• ${prefix}desbloquearcomando <cmd>
• ${prefix}bloquearcomandocategoria <cat>
• ${prefix}desbloquearcomandocategoria <cat>

🐞 *Debug / Sync*
• ${prefix}debugmode on/off
• ${prefix}atualizarwhats
• ${prefix}limparchat pv|grupos|tudo

📢 *Grupos / Anúncios*
• ${prefix}anunciar <texto>
• ${prefix}listagrupos [filtro]
• ${prefix}sairgrupo
• ${prefix}sairgrupos
• ${prefix}confirmar <código>

👥 *Owners*
• ${prefix}addowner <num>
• ${prefix}delowner <num>

💡 *Feedback / Ideias*
• ${prefix}sugestao <texto>
• ${prefix}dica <texto>
• ${prefix}ideia <texto>
• ${prefix}listsugestoes
• ${prefix}listarideias



${LINE}
`.trim();
}

// =============================================================
// MENU AVENTURA (AVENTURA — sistema novo separado)
// =============================================================
function buildAventuraMenu(context) {
  const prefix = getPrimaryPrefix(context);
  const header = buildHeader(context);

  return `
${header}

🧭 *MENU — AVENTURA NOCTHARIA*
━━━━━━━━━━━━━━

🗺️ *Comece por aqui*
• ${prefix}meuav
  - bússola (o que fazer agora)
• ${prefix}avperfil
  - seu perfil na aventura
• ${prefix}avregiao
  - escolher região e ver contrato da região

━━━━━━━━━━━━━━

⚔️ *Combate (Aventura)*
• ${prefix}avcacar
  - iniciar uma caça
• ${prefix}avatacar
  - atacar no encontro atual
• ${prefix}avfugir
  - fugir do encontro
• ${prefix}avusar <item|nome>
  - usar poção no encontro

🎲 *Exploração / Arena*
• ${prefix}explorar
  - explorar (padrão)
• ${prefix}arena lutar
  - duelo na arena
• ${prefix}arena status
  - seu status na arena

👹 *Boss*
• ${prefix}boss
  - painel do boss
• ${prefix}matarboss
  - atacar o boss ativo (atalho: ${prefix}matarboos)

━━━━━━━━━━━━━━

🌑 *NOCTHARIA (Dark)*
• ${prefix}avexp
  - exploração sombria
• ${prefix}avatacar
  - atacar no encontro
• ${prefix}avskill <nome>
  - usar skill (ex: sombra)
• ${prefix}avfugir
  - fugir do encontro

🏰 *Dungeons*
• ${prefix}avdg
  - listar dungeons
• ${prefix}avdg entrar <id>
  - entrar
• ${prefix}avdg go
  - avançar
• ${prefix}avdg sair
  - sair

🎒 *Inventário (Dark)*
• ${prefix}avinv
  - ver inventário dark
• ${prefix}avequip <slotId>
  - equipar por slot
• ${prefix}avusar <item|n>
  - usar item por nome ou número

━━━━━━━━━━━━━━

🛠️ *Forja / Craft*
• ${prefix}craft
  - receitas e forja
• ${prefix}craft dark
  - receitas e forja dark

🏪 *Empório*
• ${prefix}emporio
  - loja principal
• ${prefix}emporio geral
• ${prefix}emporio rotativo
• ${prefix}emporio especial
• ${prefix}adquirir <id> <qtd>
  - comprar
• ${prefix}liquidar <itemId> <qtd>
  - vender

🔁 *Troca segura*
• ${prefix}trocaritem @user
  - iniciar troca
• ${prefix}trocaritem add <tradeId> <itemId> <qtd>
• ${prefix}trocaritem gold <tradeId> <valor>
• ${prefix}trocaritem ver <tradeId>
• ${prefix}trocaritem ok <tradeId>
• ${prefix}trocaritem cancelar <tradeId>

━━━━━━━━━━━━━━

🏆 *Rankings / Corrupção*
• ${prefix}avrank
• ${prefix}avrank poder
• ${prefix}avrank abismo
• ${prefix}avcorr
• ${prefix}avpurificar

🏛️ *Ouro / Proteção*
• ${prefix}guardargold <valor|tudo|metade>
  - guarda no cofre e protege do roubo
• ${prefix}roubargold @user
  - tenta roubar o ouro da bolsa
• ${prefix}enviargold @user <valor>
  - dono do bot envia gold

🎭 *Classes*
• ${prefix}classe
  - ver / escolher / trocar
• ${prefix}classe dark
  - ver / escolher / trocar
`.trim();
}



module.exports = {
    buildAventuraMenu,
    buildHeader,
    buildPrefixesReply,
    getAllPrefixesText,
    buildMainMenu,
    buildJogosMenu,
    buildStickerMenu,
    buildAudioMenu,
    buildTheSimsMenu,
    buildAdminMenu,
    buildRpMenu,
    buildRpMercadoMenu,
    buildRpProfissoesMenu,
    buildRpBancoOpcaoMenu,
    buildRpPrisaoMenu,
    buildCassinoMenu,
    buildCassinoJogosMenu,
    buildMenuCassinoCompleto,
    buildBrincadeirasMenu,
    buildDonoMenu,
    buildBotMenu,
    buildMenu18,
    buildUtilidadesMenu,
};